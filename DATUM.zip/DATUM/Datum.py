#-*-coding: utf-8 -*-

#Import des paramètres
from param_form import *

class FenPrincipale(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.zoneCentrale = QMdiArea()
        self.zoneCentrale.setViewMode(QMdiArea.TabbedView)

        form0 = FormAccueil()
        form1 = FormSde()
        form2 = FormMeta()
        form3 = FormLyr()
        form4 = FormService()

        sousFenetre0 = QMdiSubWindow()
        sousFenetre0 = self.zoneCentrale.addSubWindow(form0)
        self.zoneCentrale.setActiveSubWindow(sousFenetre0)

        sousFenetre1 = QMdiSubWindow()
        sousFenetre1 = self.zoneCentrale.addSubWindow(form1)
        self.zoneCentrale.setActiveSubWindow(sousFenetre1)

        sousFenetre2 = QMdiSubWindow()
        sousFenetre2 = self.zoneCentrale.addSubWindow(form2)
        self.zoneCentrale.setActiveSubWindow(sousFenetre2)

        sousFenetre3 = QMdiSubWindow()
        sousFenetre3 = self.zoneCentrale.addSubWindow(form3)
        self.zoneCentrale.setActiveSubWindow(sousFenetre3)

        sousFenetre4 = QMdiSubWindow()
        sousFenetre4 = self.zoneCentrale.addSubWindow(form4)
        self.zoneCentrale.setActiveSubWindow(sousFenetre4)

        self.setCentralWidget(self.zoneCentrale)

        self.zoneCentrale.setActivationOrder(QtGui.QMdiArea.StackingOrder)

        #Activation du premier onglet
        self.zoneCentrale.setActiveSubWindow(sousFenetre0)



class FormAccueil(QWidget, Ui_FormAccueil):
    fermePlugin = pyqtSignal()

    def __init__(self):
        QWidget.__init__(self)
        self.setupUi(self)

        #<chargement des données
        self.loadDataHisto()
        self.loadDataScan()
        self.loadDataDonuts()

        #logo DATUM
        self.logo.setPixmap(QtGui.QPixmap(os.getcwd() + "/icons/logo_big.png"))

        #définition des connecteurs
        self.connect(self.btn_debug, SIGNAL("clicked()"), self.logDebug)

        #définition donuts sur les jeux de données
        color = ['#FFCBB5', '#9BA3FF', '#89CC68', '#DDB1D3' ]

        layout = QHBoxLayout(self.widget_Jeu)
        layout.addWidget(self.make_pie([self.pctJeu_Maj,1-self.pctJeu_Maj], u'{}%'.format(int(self.pctJeu_Maj*100)), \
                                       u'Données\nà jour ('+ str(self.jeu_Maj)+')', color[0]))
        layout.addWidget(self.make_pie([self.pctJeu_Lyr,1-self.pctJeu_Lyr], u'{}%'.format(int(self.pctJeu_Lyr*100)), \
                                       u'Lyr\nexistant ('+ str(self.jeu_Lyr)+')', color[0]))
        layout.addWidget(self.make_pie([self.pctJeu_Meta,1-self.pctJeu_Meta], u'{}%'.format(int(self.pctJeu_Meta*100)), \
                                       u'Métadonnées\nprésentes ('+ str(self.jeu_Meta)+')', color[0]))
        self.setLayout(layout)

        #définition donuts sur les métadonnées
        layout = QHBoxLayout(self.widget_Meta)
        layout.addWidget(self.make_pie([self.ptcMeta_Jeu,1-self.ptcMeta_Jeu], u'{}%'.format(int(self.ptcMeta_Jeu*100)), \
                                       u'Données\nprésentes ('+str(self.meta_Jeu)+')', color[1]))
        layout.addWidget(self.make_pie([self.ptcMeta_Rg,1-self.ptcMeta_Rg], u'{}%'.format(int(self.ptcMeta_Rg*100)), \
                                       u'Renseignements\ncomplets ('+ str(self.meta_Rg)+')', color[1]))
        layout.addWidget(self.make_pie([self.ptcMeta_Freq,1-self.ptcMeta_Freq], u'{}%'.format(int(self.ptcMeta_Freq*100)), \
                                       u'Fréquence MàJ\ndéfinie ('+ str(self.meta_Freq)+')', color[1]))
        self.setLayout(layout)

        #définition donuts sur les fichiers lyr
        layout = QHBoxLayout(self.widget_Lyr)
        layout.addWidget(self.make_pie([self.ptcLyr_Srce,1-self.ptcLyr_Srce], u'{}%'.format(int(self.ptcLyr_Srce*100)), \
                                       u'Source\naccessible ('+str(self.lyr_Srce)+')', color[2]))
        layout.addWidget(self.make_pie([self.ptcLyr_Priv,1-self.ptcLyr_Priv], u'{}%'.format(int(self.ptcLyr_Priv*100)), \
                                       u'Privilège\ncohérent ('+str(self.lyr_Priv)+')', color[2]))
        layout.addWidget(self.make_pie([self.ptcLyr_Sym,1-self.ptcLyr_Sym], u'{}%'.format(int(self.ptcLyr_Sym*100)), \
                                       u'Symbologie\ncorrecte ('+str(self.lyr_Sym)+')', color[2]))
        self.setLayout(layout)

        # définition donuts sur les services web
        layout = QHBoxLayout(self.widget_Service)
        layout.addWidget(
            self.make_pie([self.ptcSw_actif, 1 - self.ptcSw_actif], u'{}%'.format(int(self.ptcSw_actif * 100)), \
                          u'Services\nactifs (' + str(self.sw_actif) + ')', color[3]))
        layout.addWidget(
            self.make_pie([self.ptcSw_public, 1 - self.ptcSw_public], u'{}%'.format(int(self.ptcSw_public * 100)), \
                          u'Services\npublics (' + str(self.sw_public) + ')', color[3]))
        layout.addWidget(
            self.make_pie([self.ptcSw_Jeu, 1 - self.ptcSw_Jeu], u'{}%'.format(int(self.ptcSw_Jeu * 100)), \
                          u'Jeux de données\npubliés (' + str(self.sw_Jeu) + ')', color[3]))

        #Titres
        self.txt_jeux.setText(str(self.totalJeu)+ u' jeux de données')
        self.txt_meta.setText(str(self.totalMeta)+ u' fiches de métadonnées')
        self.txt_lyr.setText(str(self.totalLyr)+ u' fichiers lyr')
        self.txt_service.setText(str(self.totalSw)+ u' services web')

        #définition zone "widGraph1" (cf. form_sde.ui)
        histo = self.graphHisto(color)
        histo.setParent(self.widGraph1)
        layout1 = QVBoxLayout()
        layout1.addWidget(histo)
        self.widGraph1.setLayout(layout1)
        self.widGraph1.baseSize()

    def loadDataDonuts(self):
        dirJson = Glob().dirJson

        # ------- DONUTS JEUX DE DONNEES -----------

        #Ouverture fichier jeux de données
        js =open(dirJson + '//sde_tableau.json')
        dataJeu = json.load(js)
        js.close()

        #Calcul nombre total de jeux de données
        self.totalJeu = len([x for x in dataJeu['TAB_QUALITE']])

        #Calcul pourcentage "Lyr existant"
        jeu_without_NA = self.totalJeu - len([x for x in dataJeu['FIC_LYR'] if x == 'n/a']) #on retire du total les 'n/a'
        self.jeu_Lyr = len([x for x in dataJeu['FIC_LYR'] if x != ''])
        self.pctJeu_Lyr = float(self.jeu_Lyr)/float(jeu_without_NA)

        #Calcul pourcentage "Métadonnées présentes"
        lstNoNone = [x for x in dataJeu['TAB_QUALITE'] if x != None] #filtre les champs nuls
        self.jeu_Meta = self.totalJeu - len([x for x in lstNoNone if x.find('J06')!=-1]) #Métadonnées présentes
        self.pctJeu_Meta = float(self.jeu_Meta)/float(self.totalJeu)

        # Calcul pourcentage "Données à jour" selon le nombre de MD avec féquence màj définie
        a = len([x for x in dataJeu['TAB_MAJ_STATUT'] if x == u'Mise \xe0 jour \xe0 faire'])
        self.jeu_Maj = len([x for x in dataJeu['TAB_MAJ_STATUT'] if x == u'-' or x == u'Figée'])
        c = len([x for x in dataJeu['TAB_MAJ_STATUT'] if x == u'Non planifi\xe9e'])
        self.pctJeu_Maj = float(self.jeu_Maj) / (float(a) + float(self.jeu_Maj) + float(c))

        # ------- DONUTS METADONNEES -----------

        #Ouverture fichier métadonnées
        js =open(dirJson + '//meta_tableau.json')
        dataMeta = json.load(js)
        js.close()

        #Calcul nombre total de métadonnées
        self.totalMeta = len([x for x in dataMeta['META_QUALITE']])
        lstNoNone = [x for x in dataMeta['META_QUALITE'] if x != None] #filtre les champs nuls

        #Calcul pourcentage "Données présentes"
        self.meta_Jeu = self.totalMeta - len([x for x in lstNoNone if x.find('M01')!=-1])
        self.ptcMeta_Jeu = float(self.meta_Jeu)/float(self.totalMeta)

        #Calcul pourcentage "Renseignements complets"
        self.meta_Rg =self.totalMeta - len([x for x in lstNoNone if x.find('M02')!=-1])
        self.ptcMeta_Rg = float(self.meta_Rg)/float(self.totalMeta)

        #Calcul pourcentage "Fréquence de MàJ définie"
        self.meta_Freq = self.totalMeta - len([x for x in lstNoNone if x.find('M13')!=-1])
        self.ptcMeta_Freq = float(self.meta_Freq)/float(self.totalMeta)

        # ------- DONUTS FICHIERS LYR -----------

        #Ouverture fichier lyr
        js =open(dirJson + '//lyr_tableau.json')
        dataLyr = json.load(js)
        js.close()

        dicoLyr = {}
        listQual = []
        for lyr in dataLyr.keys():
            qualLyr = []
            for couche in dataLyr[lyr]:
                qualLyr.append(dataLyr[lyr][couche][-1].split('|')[1])
            dicoLyr[lyr]=qualLyr

        #Calcul nombre total de lyr
        ficLyr = [','.join(dicoLyr[x]) for x in dicoLyr.keys()]
        self.totalLyr = len(ficLyr)

        #Calcul pourcentage "Source accessible"
        self.lyr_Srce = self.totalLyr - len([x for x in ficLyr if x.find('L01')!=-1])
        self.ptcLyr_Srce = float(self.lyr_Srce)/float(self.totalLyr)

        #Calcul pourcentage "Privilège cohérent"
        self.lyr_Priv = self.totalLyr - len([x for x in ficLyr if x.find('L06')!=-1])
        self.ptcLyr_Priv = float(self.lyr_Priv)/float(self.totalLyr)

        #Calcul pourcentage "Symbologie correcte"
        self.lyr_Sym = self.totalLyr - len([x for x in ficLyr if x.find('L05')!=-1])
        self.ptcLyr_Sym = float(self.lyr_Sym)/float(self.totalLyr)

        # ------- DONUTS SERVICES WEB -----------

        # Ouverture fichier services web
        js = open(dirJson + '//service_tableau.json')
        dataSw = json.load(js)
        js.close()

        js = open(self.dirJson + '//service_dicoJeu_Sw.json')
        self.dicoJeu_Sw = json.load(js)
        js.close()

        # Calcul nombre total de services web
        self.totalSw = len([x for x in dataSw['SW_QUALITE']])

        # Calcul pourcentage "Services actifs"
        self.sw_actif = self.totalSw - len([x for x in dataSw['SW_STATUT'] if x == u'Arrêté'])
        self.ptcSw_actif = float(self.sw_actif) / float(self.totalSw)

        # Calcul pourcentage "Services publics"
        self.sw_public = self.totalSw - len([x for x in dataSw['SW_NOM'] if x.split('|')[1] != 'public'])
        self.ptcSw_public = float(self.sw_public) / float(self.totalSw)

        # Calcul pourcentage "Nombre de jeux de données publiés"
        self.sw_Jeu = len(self.dicoJeu_Sw.keys())
        self.ptcSw_Jeu = float(self.sw_Jeu) / float(self.totalJeu)


    def graphHisto(self, color):
            fig = plt.figure(num=None, figsize=(12, 10), dpi=70, facecolor='white', edgecolor='k')
            ax =  fig.add_subplot(111)

            dicoHisto = {}
            mois = {'01':'Jan','02':'Fev','03':'Mar','04':'Avr','05':'Mai','06':'Juin','07':'Juil','08':'Aou','09':'Sep',
                    '10':'Oct','11':'Nov','12':'Dec'}

            dirJson = Glob().dirJson
            js =open(dirJson + '//histo_global.json')
            dicoHisto = json.load(js)
            js.close()

            totalJeu = []
            histo_Jeu = []
            histo_Meta = []
            histo_Lyr = []
            histo_Service = []
            x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
            xLabel = []

            for i, key in enumerate(sorted(dicoHisto.keys(), reverse = True)):
                if i < 24: # valeurs sur 2 ans
                    if key[-2:] == '01':
                        xLabel.append(key[:4])
                    else:
                        xLabel.append(mois[key[-2:]])
                    histo_Jeu.append(dicoHisto[key][0])
                    histo_Meta.append(dicoHisto[key][1])
                    histo_Lyr.append(dicoHisto[key][2])
                    histo_Service.append(dicoHisto[key][3])

            #remise des valeurs dans le bon ordre
            histo_Jeu.reverse()
            histo_Meta.reverse()
            histo_Lyr.reverse()
            histo_Service.reverse()
            xLabel.reverse()

            plt.xticks(x, xLabel)
            plt.plot(x, histo_Jeu,"-", linewidth=2, color=color[0])
            plt.plot(x, histo_Meta,"-", linewidth=2, color=color[1])
            plt.plot(x, histo_Lyr,"-", linewidth=2, color=color[2])
            plt.plot(x, histo_Service,"-", linewidth=2, color=color[3])

            plt.grid()
            plt.ylabel('-')
            plt.xlabel('-')
            plt.title(u"Historique (Jeux - Métadonnées - Lyr - Services)")

            return FigureCanvas(fig)

    def make_pie(self,sizes,text,titre,couleur):
        col = [couleur, 'white']

        fig = plt.figure(num=None, figsize=(10, 10), dpi=70, facecolor='white', edgecolor='k')
        ax = fig.add_subplot(111)

        ax.axis('equal')
        width = 0.55
        kwargs = dict(colors=col, startangle=90)
        outside, _ = ax.pie(sizes, radius=1.1, pctdistance=0.1, labeldistance=2.1, **kwargs)
        plt.setp( outside, width=width, edgecolor=couleur)
        fig.patch.set_facecolor('white')

        kwargs = dict(size=18, va='center', color='#283838')
        ax.text(0, 0, text, ha='center', **kwargs)
        kwargs = dict(size=13, va='center', color='#283838')
        ax.text(0, -1.6, titre, ha='center', **kwargs)

        return FigureCanvas(fig)

    def logDebug(self):
        log_path = os.path.dirname(os.path.abspath(__file__)) + '\\scan_debug.log'
        fic_log = open(log_path, 'r')
        lines = fic_log.readlines()
        fic_log.close()

        listInfo = []
        i = 0
        for line in lines:
            desc = line.split(',')
            listInfo.append(str(i) +':'+ desc[1])
            listInfo.append(str(i+1) +':'+ ','.join(desc[2:]))
            i += 2

        fenetreListe = FormListe(u'Description des erreurs', listInfo , '') # envoi nomJeu, liste
        fenetreListe.exec_()

    def loadDataScan(self):
        #Affichage dernière date de scan
        fic = self.dirJson + '\sde_tableau.json'
        creaDate = datetime.fromtimestamp(os.stat(fic).st_mtime).strftime("%d/%m/%Y")
        self.txt_datescan.setText(u'Etat au ' + creaDate)

        #Affichage rapport des scans
        log_path = os.path.dirname(os.path.abspath(__file__)) + '\\scan.log'
        fic_log = open(log_path, 'r')
        lines = fic_log.readlines()
        fic_log.close()

        table = self.tbl_scan
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setRowCount(len(lines))
        table.setColumnCount(1)

        listInfo = []
        for i, line in enumerate(lines):
            desc = line.split(' :: ')
            listInfo.append(desc[2])
            texte = desc[1]+' - '+desc[2]+' - '+unicode(desc[3], "utf-8")
            table.setItem(i, 0, QTableWidgetItem(texte))
            table.setRowHeight(i, 20)

        table.setColumnWidth(0,500)

        #affichage de la ligne "Réussi(Tous), Plantage(0), Vigilance(3)"
        dirScanPy = os.path.dirname(os.path.abspath(__file__)) + '/scan/' #Chemin d'accès du répertoire des scans
        listFicPy = os.listdir(dirScanPy) #nombre de fichiers scan

        dicoNiv = {k: listInfo.count(k) for k in listInfo}

        if 'CRITICAL' not in dicoNiv.keys():
            dicoNiv['CRITICAL'] = 0

        if 'WARNING' not in dicoNiv.keys():
            dicoNiv['WARNING'] = 0

        if 'INFO' not in dicoNiv.keys():
            success = 0
        else:
            if dicoNiv['INFO'] - len(listFicPy) == 0:
                success ='Tous'
            else:
                success = str(dicoNiv['INFO'] - len(listFicPy))


        texte = u'Réussi (' + str(success) \
                    + u'), Arrêt (' + str(dicoNiv['CRITICAL']) + '), Vigilance (' + str(dicoNiv['WARNING']) + ')'

        self.txt_scan.setText(texte)


    def loadDataHisto(self):
        self.dirJson = Glob().dirJson
        js =open(self.dirJson + '//histo_jour.json')
        dicoHisto = json.load(js)
        js.close()

        #init variable table
        table = self.tbl_histo
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)

        #Définition de l'entête du tableau
        entete = [u'Date', u'Type', u'Nom', '', '']

        # initialisation de la table
        table.setRowCount(len(dicoHisto.keys()))
        table.setColumnCount(5)

        # définition des labels (entête)
        stylesheet = "::section{Background-color:rgb(72,102,102);border-radius:20px;padding-bottom:5px;padding-top:5px;" \
                     "color:white;}"
        table.horizontalHeader().setStyleSheet(stylesheet)

        table.setHorizontalHeaderLabels(entete)
        new_item = QTableWidgetItem()
        font = QFont("MS Shell Dlg 2", 9)
        font.setUnderline(True)

        #chargement des données
        for i, val in enumerate(sorted(dicoHisto.keys(),reverse=True)):
            table.setItem(i, 0, QTableWidgetItem(dicoHisto[val][0]))
            table.setItem(i, 1, QTableWidgetItem(dicoHisto[val][1]))
            table.setItem(i, 2, QTableWidgetItem(dicoHisto[val][2]))

            if dicoHisto[val][3] == 3:
                table.setCellWidget(i, 3, IcoBad(self))
            elif dicoHisto[val][3] == 2:
                table.setCellWidget(i, 3, IcoMid(self))
            elif dicoHisto[val][3] == 1:
                table.setCellWidget(i, 3, IcoSat(self))
            else:
                table.setCellWidget(i, 3, IcoGood(self))

            if dicoHisto[val][4] == 1:
                table.setCellWidget(i, 4, IcoUp(self))
            else:
                table.setCellWidget(i, 4, IcoDown(self))

            table.setRowHeight(i, 20) #hauteur ligne


        table.setColumnWidth(0,100)
        table.setColumnWidth(1,200)
        table.setColumnWidth(2,450)
        table.setColumnWidth(3,25)
        table.setColumnWidth(4,25)

class FormSde(QWidget, Ui_FormSDE):
    fermePlugin = pyqtSignal()

    def __init__(self):
        QWidget.__init__(self)
        self.setupUi(self)

        #cablage aux fichiers Json
        self.dirJson = Glob().dirJson

        js =open(self.dirJson + '//def_qualite.json')
        self.defQual = json.load(js)
        js.close()

        js =open(self.dirJson + '//sde_dicoJeu_Dom.json')
        self.dicoJeu_Dom = json.load(js)
        js.close()

        js =open(self.dirJson + '//sde_dicoDom_Jeu.json')
        self.dicoDom_Jeu = json.load(js)
        js.close()

        js =open(self.dirJson + "//service_dicoJeu_Sw.json")
        self.dicoJeu_Sw = json.load(js)
        js.close()

        js =open(self.dirJson + '//sde_tableau.json')
        self.tabledata = json.load(js)
        js.close()

        #Définition ordre des colonnes
        self.header = [('TAB_NOM', u'Jeu de données'), ('TAB_QUAL_IND', u''),('TAB_CONTACT',u'Contact'), \
                       ('TAB_TYPE', u'Type'), ('TAB_NUM_ROWS', u'Entités'), ('TAB_DATEMODIF', u'Dernière modification'), \
                       ('TAB_MAJ_STATUT', u'Donnée à jour'), ('TAB_META_ID', u'Méta'),('FIC_LYR', u'Fichiers Lyr'), \
                       ('Domaine', u'Domaine'), ('TAB_PRIV', u'Privilèges'), ('TAB_COORD_PLA', u'Coordonnées plani'), \
                       ('TAB_COORD_ALT', u'Coordonnées alti'), ('TAB_EDIT', u'Editeur'), ('TAB_VERS', u'Versionné'), \
                       ('TAB_INDEX', u'Index'), ('Ind_spa', u'Index spa.'), ('TAB_SQLFROM', u'Requête SQL'), \
                       ('TAB_ATTACH', u'Pièces jointes'), ('TAB_RELATION', u'Relation'), ('Service', u'Service')]

        #initialisation du filtre
        self.listFiltre = []
        self.listFiltre.append('Tous')
        self.cmb_filtre.addItem('Tous')

        for i in self.defQual.keys():
            if self.defQual[i][0] == u'Jeux de données':
                self.listFiltre.append(str(i))
                val = self.defQual[i][1]
                self.cmb_filtre.addItem(val)

        #Chargement des données
        self.loadDataTableau()
        self.loadEnteteTableau()

        #Affichage total des jeux de données dans le label lbl_nbdata
        chaine = '( '+str(len(self.tabledata['OBJECTID'])) + u' jeux)'
        self.lbl_nbdata.setText(chaine)

        #Couleur pour indicateurs généraux
        self.color = ['#9BA3FF','#89CC68', '#FFCBB5', '#486666']

        #définition zone "widGraph3" (cf. form_sde.ui)
        histo = self.graphHisto(self.color)
        histo.setParent(self.widGraph3)
        layout1 = QVBoxLayout()
        layout1.addWidget(histo)
        self.widGraph3.setLayout(layout1)
        self.widGraph3.baseSize()

        # définition zone "widGraph1" (cf. form_sde.ui)
        bar = self.graphBar()
        bar.setParent(self.widGraph1)
        layout1 = QVBoxLayout()
        layout1.addWidget(bar)
        self.widGraph1.setLayout(layout1)
        self.widGraph1.baseSize()

        #définition des connecteurs
        self.connect(self.tbl_sde, SIGNAL("itemSelectionChanged()"), self.hyperlink)
        self.connect(self.btn_ind, SIGNAL("clicked()"), self.indicName)
        self.connect(self.cmb_dom, SIGNAL("activated(int)"), self.domaine)
        self.connect(self.cmb_filtre, SIGNAL("currentIndexChanged(int)"), self.loadDataTableau)
        self.connect(self.txt_filtre, SIGNAL("textChanged(QString)"), self.loadDataTableau)

        #Init liste des domaines
        self.cmb_dom.addItem('-')
        self.cmb_dom.addItems(sorted(self.dicoDom_Jeu.keys()))


    def graphBar(self):
        #data
        dicoHisto = {}
        dirJson = Glob().dirJson
        js =open(dirJson + '//histo_jeu_detail.json')
        dicoHisto = json.load(js)
        js.close()

        lastRec = sorted(dicoHisto.keys(), reverse = True)[0]

        fig = plt.figure(num=None, figsize=(24, 10), dpi=70, facecolor='white', edgecolor='k')
        val = [dicoHisto[lastRec][3],dicoHisto[lastRec][2], dicoHisto[lastRec][1], dicoHisto[lastRec][0]]
        label = [ u'Métadonnées présentes : ',u'Lyr existant : ',u'Donnée à jour : ',u'Total : ']
        pos = [0, 1, 2, 3]
        plt.axis('off')

        bars = plt.barh(pos, val, height=0.75, align='center', edgecolor = 'none')
        bars[0].set_facecolor(self.color[0])
        bars[1].set_facecolor(self.color[1])
        bars[2].set_facecolor(self.color[2])
        bars[3].set_facecolor(self.color[3])

        for i, v in enumerate(val):
            if i == 3:
                plt.text(v / 2, i, label[i] + str(v), color='white', fontweight='bold', ha='center', va='center')
            else:
                plt.text(10, i, label[i] + str(v), color='black', ha='left', va='center')

        return FigureCanvas(fig)


    def domaine(self):
        domSelec = self.cmb_dom.currentText().toUtf8().data()
        if domSelec != '-':
            # envoi nomJeu, liste
            fenetreListe = FormListe(domSelec, self.dicoDom_Jeu[domSelec], u'Jeux de données utilisant le domaine ')
            fenetreListe.exec_()


    def loadEnteteTableau(self):
        table = self.tbl_entete
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setRowCount(4)
        table.setColumnCount(4)
        entete = [u'Etat', u'', u'Description', u'En cours']
        stylesheet = "::section{Background-color:rgb(125,176,176);border-radius:20px;}"
        table.horizontalHeader().setStyleSheet(stylesheet)
        for i, val in enumerate(entete):
            item = QTableWidgetItem(val)
            item.setBackgroundColor(QColor(0,204,255))
            table.setHorizontalHeaderItem(i,item)

        #ligne 1
        table.setRowHeight(0, 40)
        table.setItem(0, 0, QTableWidgetItem('Critique'))
        table.setCellWidget(0, 1, IcoBad(self))
        table.setItem(0, 2, QTableWidgetItem(u"Réparation impérative. Pas utilisable en l'état.\nCause possible : "
                                             u"pas à jour, pas d'accès UIG, vue cassée,..."))
        ind3 = len([x for x in self.tabledata['TAB_QUAL_IND'] if x == 3])
        table.setItem(0, 3, QTableWidgetItem(str(ind3)))

        #ligne 2
        table.setRowHeight(1, 40)
        table.setItem(1, 0, QTableWidgetItem('Moyen'))
        table.setCellWidget(1, 1, IcoMid(self))
        table.setItem(1, 2, QTableWidgetItem(u"Doit être amélioré.\nCause possible : pas de MD, nom SDE incorrect, "
                                             u"pas d'index,..."))
        ind2 = len([x for x in self.tabledata['TAB_QUAL_IND'] if x == 2])
        table.setItem(1, 3, QTableWidgetItem(str(ind2)))

        #ligne 3
        table.setRowHeight(2, 40)
        table.setItem(2, 0, QTableWidgetItem('Convenable'))
        table.setCellWidget(2, 1, IcoSat(self))
        table.setItem(2, 2, QTableWidgetItem(u"Peut être amélioré.\nCause possible : nom champ incorrect,..."))
        ind1 = len([x for x in self.tabledata['TAB_QUAL_IND'] if x == 1])
        table.setItem(2, 3, QTableWidgetItem(str(ind1)))

        #ligne 4
        table.setRowHeight(3, 40)
        table.setItem(3, 0, QTableWidgetItem('Excellent'))
        table.setCellWidget(3, 1, IcoGood(self))
        table.setItem(3, 2, QTableWidgetItem(u"Ce jeu de données répond à toutes nos règles de qualité"))
        ind0 = len([x for x in self.tabledata['TAB_QUAL_IND'] if x == None])
        table.setItem(3, 3, QTableWidgetItem(str(ind0)))

        table.resizeColumnsToContents()


    def loadDataTableau(self):
        """Chargement des données dans le tableau détaillé"""
        #FILTRE sur le nom et règle de qualité
        filtreNom = self.txt_filtre.text().toAscii().data()
        selec = self.cmb_filtre.currentIndex()
        filtreQual = self.listFiltre[selec]

        #init données à charger dans le tableau
        loadData = {}

        #filtre sur le nom
        numListe = []
        for i, val in enumerate(self.tabledata['TAB_NOM']):
            if filtreNom != '':
                if filtreNom in val:
                    if filtreQual != 'Tous':
                        if self.tabledata['TAB_QUALITE'][i]!=None:
                            if filtreQual in self.tabledata['TAB_QUALITE'][i]:
                                numListe.append(i)
                    else:
                        numListe.append(i)
            else:
                if filtreQual != 'Tous':
                    if self.tabledata['TAB_QUALITE'][i]!=None:
                        if filtreQual in self.tabledata['TAB_QUALITE'][i]:
                            numListe.append(i)
                else:
                    numListe.append(i)

        for champ in self.tabledata.keys():
            loadData[champ] = [self.tabledata[champ][x] for x in numListe]

        #Fin du filtre ,données dans loadData

        #init variable table
        table = self.tbl_sde
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSortingEnabled(False)
        table.clear()

        #Définition de l'entête du tableau
        entete = [x[1] for x in self.header]
        champs = [x[0] for x in self.header]

        # initialisation de la table
        table.setRowCount(len(loadData[champs[0]]))
        table.setColumnCount(len(entete))

        # définition des labels (entête)
        stylesheet = "::section{Background-color:rgb(72,102,102);border-radius:20px;padding-bottom:5px;padding-top:5px;" \
                     "color:white;}"
        table.horizontalHeader().setStyleSheet(stylesheet)

        table.setHorizontalHeaderLabels(entete)
        new_item = QTableWidgetItem()
        font = QFont("MS Shell Dlg 2", 9)
        font.setUnderline(True)

        # CHARGEMENT COLONNE

        for a, champ  in enumerate(champs):
            if champ == 'TAB_DATEMODIF':
                for i, val in enumerate(loadData[champ]):
                    date = ''.join(str(e) for e in val)
                    if date == 'None':
                        table.setItem(i, a, QTableWidgetItem(''))
                    else:
                        table.setItem(i, a, QTableWidgetItem(date))

            elif champ == 'TAB_META_ID':
                self.posMeta = a #position dans la table
                for i, val in enumerate(loadData[champ]):
                    if val != None:
                        if val == 'n/a':
                            new_item = QTableWidgetItem('n/a')
                            new_item.setTextColor(QColor(178,174,176,255))
                        else:
                            new_item = QTableWidgetItem('oui')
                            new_item.setTextColor(QColor(0,0,204,255))
                            new_item.setFont(font)
                        table.setItem(i,a, new_item)
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))

            elif champ == 'Domaine':
                self.posDomaine = a #position dans la table
                for i in range(len(loadData[champs[0]])):
                    if loadData['TAB_NOM'][i] in self.dicoJeu_Dom.keys():
                        new_item = QTableWidgetItem('oui')
                        new_item.setTextColor(QColor(0,0,204,255))
                        new_item.setFont(font)
                        table.setItem(i,a, new_item)
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))

            elif champ == 'Service':
                self.posService = a #position dans la table
                self.dicoService = {} #création d'un dico pour lister les services (dans hyperlink)
                for i in range(len(loadData[champs[0]])):
                    if loadData['TAB_NOM'][i] in self.dicoJeu_Sw.keys():
                        new_item = QTableWidgetItem('liste')
                        new_item.setTextColor(QColor(0,0,204,255))
                        new_item.setFont(font)
                        table.setItem(i,a, new_item)
                        self.dicoService[loadData['TAB_NOM'][i]] = self.dicoJeu_Sw[loadData['TAB_NOM'][i]]
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))

            elif champ == 'Ind_spa':
                for i in range(len(loadData[champs[0]])):
                    if loadData['TAB_INDEX'][i] != None:
                        if 'SHAPE' in loadData['TAB_INDEX'][i]:
                            new_item = QTableWidgetItem('oui')
                            table.setItem(i,a, new_item)

                        elif 'FORME' in loadData['TAB_INDEX'][i]:
                            new_item = QTableWidgetItem('oui')
                            table.setItem(i,a, new_item)

                        else:
                            table.setItem(i, a, QTableWidgetItem(''))

                    if loadData['TAB_TYPE'][i] in ['Vue', 'Table', 'Raster']:
                        new_item = QTableWidgetItem('n/a')
                        new_item.setTextColor(QColor(178,174,176,255))
                        table.setItem(i,a, new_item)


            elif champ == 'TAB_NUM_ROWS':
                for i, val in enumerate(loadData[champ]):
                    if val == None:
                        new_item = QTableWidgetItem('n/a')
                        new_item.setTextColor(QColor(178,174,176,255))
                        table.setItem(i,a, new_item)
                    else:
                        new_item = QTableWidgetItem(str(int(val)).zfill(10))
                        table.setItem(i, a, new_item)


            elif champ == 'TAB_INDEX':
                self.posIndex = a #position dans la table
                self.dicoIndex = {} #création dico pour liste (dans hyperlink)
                for i, val in enumerate(loadData[champ]):
                    if val != None:
                        new_item = QTableWidgetItem('liste')
                        new_item.setTextColor(QColor(0,0,204,255))
                        new_item.setFont(font)
                        table.setItem(i,a, new_item)
                        self.dicoIndex[loadData['TAB_NOM'][i]] = loadData['TAB_INDEX'][i]
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))


            elif champ == 'TAB_RELATION':
                self.dicoRel = {}
                self.posRelation = a #position dans la table
                for i, val in enumerate(loadData[champ]):
                    if val != None:
                        new_item = QTableWidgetItem('oui')
                        new_item.setTextColor(QColor(0,0,204,255))
                        new_item.setFont(font)
                        table.setItem(i,a, new_item)
                        self.dicoRel[loadData['TAB_NOM'][i]] = loadData[champ][i] #Création dico Relation
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))

            elif champ == 'TAB_QUAL_IND':
                self.posQualite = a
                for i, val in enumerate(loadData[champ]):
                    if val == 3:
                        table.setCellWidget(i, a, IcoBad(self))
                        table.setItem(i, a, QTableWidgetItem('3'))
                    if val == 2:
                        table.setCellWidget(i, a, IcoMid(self))
                        table.setItem(i, a, QTableWidgetItem('2'))
                    if val == 1:
                        table.setCellWidget(i, a, IcoSat(self))
                        table.setItem(i, a, QTableWidgetItem('1'))
                    if val == None:
                        table.setCellWidget(i, a, IcoGood(self))
                        table.setItem(i, a, QTableWidgetItem('0'))

            elif champ == 'FIC_LYR':
                self.posFicLyr = a #position dans la table
                self.dicoLyr = {} #création dico pour lister les fichiers (dans hyperlink)
                for i, val in enumerate(loadData[champ]):
                    if val != '' and val!= 'n/a':
                        new_item = QTableWidgetItem('liste')
                        new_item.setTextColor(QColor(0,0,204,255))
                        new_item.setFont(font)
                        table.setItem(i,a, new_item)
                        self.dicoLyr[loadData['TAB_NOM'][i]] = loadData['FIC_LYR'][i]
                    elif val=='n/a':
                        new_item = QTableWidgetItem(val)
                        new_item.setTextColor(QColor(178,174,176,255))
                        table.setItem(i, a, new_item)
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))

            elif champ == 'TAB_SQLFROM':
                self.posSql = a #position dans la table
                self.dicoSql = {} #création dico pour liste (dans hyperlink)
                for i, val in enumerate(loadData[champ]):
                    if val != None:
                        new_item = QTableWidgetItem('liste')
                        new_item.setTextColor(QColor(0,0,204,255))
                        new_item.setFont(font)
                        table.setItem(i,a, new_item)
                        self.dicoSql[loadData['TAB_NOM'][i]] = loadData['TAB_SQLFROM'][i]
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))


            else:
                for i, val in enumerate(loadData[champ]):
                    if val == None:
                        table.setItem(i, a, QTableWidgetItem(''))
                    elif type(val) == float:
                        table.setItem(i, a, QTableWidgetItem(QtCore.QString.number(val,'g',10)))
                    elif val == 'n/a':
                        new_item = QTableWidgetItem('n/a')
                        new_item.setTextColor(QColor(178,174,176,255))
                        table.setItem(i, a, new_item)
                    else:
                        table.setItem(i, a, QTableWidgetItem(val))
                    table.setRowHeight(i, 18) #hauteur ligne


        #Mise en forme
        table.setSortingEnabled(True)
        table.resizeColumnsToContents()
        table.sortByColumn(0, QtCore.Qt.AscendingOrder)


    def hyperlink(self):
        """Création des hyperliens dans le tableau détaillé"""
        try:
            #définition de l'hyperlien sur les métadonnées
            valCell = self.tbl_sde.selectedItems()[0].text()
            if self.tbl_sde.currentColumn() == self.posMeta:
                if valCell == 'oui':
                    id_meta = self.tbl_sde.item(self.tbl_sde.currentRow(),0).text()[4:]
                    url_meta = 'http://applications001.brest-metropole-oceane.fr/vipdu60/aspx/HTDU502.aspx?TYPE=FICHE&ID=' \
                               + id_meta
                    webbrowser.open(url_meta)

            #définition de l'hyperlien sur les domaines
            if self.tbl_sde.currentColumn() == self.posDomaine:
                if valCell != '-':
                    id_jeu = self.tbl_sde.item(self.tbl_sde.currentRow(),0).text()
                    fenetreDom = FormDomaine(id_jeu, self.dicoJeu_Dom)
                    fenetreDom.exec_()

            # définition de l'hyperlien sur les services
            if self.tbl_sde.currentColumn() == self.posService:
                if valCell == 'liste':
                    id_jeu = self.tbl_sde.item(self.tbl_sde.currentRow(), 0).text()
                    fenetreListe = FormListe(id_jeu, self.dicoService[str(id_jeu)], u'Services web associés au jeu de'
                                                                                  u'données ')  # envoi nomJeu, liste, texte
                    fenetreListe.exec_()

            #définition de l'hyperlien sur les classes de relation
            if self.tbl_sde.currentColumn() == self.posRelation:
                if valCell == 'oui':
                    id_jeu = self.tbl_sde.item(self.tbl_sde.currentRow(),0).text()
                    fenetreListe = FormListe(id_jeu, self.dicoRel[str(id_jeu)].split(','), \
                                             u'Classes de relations définies avec le jeu de données ')
                                             # envoi nomJeu, liste, texte
                    fenetreListe.exec_()

            #définition de l'hyperlien sur le niveau de qualité
            if self.tbl_sde.currentColumn() == self.posQualite:
                id_jeu = self.tbl_sde.item(self.tbl_sde.currentRow(),0).text()
                index = self.tabledata['TAB_NOM'].index(id_jeu)
                nivQual = self.tabledata['TAB_QUALITE'][index]
                if nivQual != None:
                    fenetreListe = FormTree(id_jeu, nivQual, self.defQual ) # envoi nomJeu, liste
                    fenetreListe.exec_()

            #définition de l'hyperlien sur liste des fichiers lyr
            elif self.tbl_sde.currentColumn() == self.posFicLyr:
                    if valCell == 'liste':
                        id_meta = self.tbl_sde.item(self.tbl_sde.currentRow(),0).text()
                        fenetreListe = FormListe(id_meta, self.dicoLyr[str(id_meta)], u'Fichiers lyr associés au jeu de'
                        u'données ') # envoi nomJeu, liste, texte
                        fenetreListe.exec_()

            #définition de l'hyperlien sur la liste des vues/jeu (et liste des jeux/vue)
            elif self.tbl_sde.currentColumn() == self.posSql:
                    if valCell == 'liste':
                        id_meta = self.tbl_sde.item(self.tbl_sde.currentRow(),0).text()
                        fenetreListe = FormListe(id_meta, self.dicoSql[str(id_meta)].split(','), \
                                                 u'Requête SQL - données associées à ') # envoi nomJeu, liste, texte
                        fenetreListe.exec_()

            #définition de l'hyperlien sur la liste des index
            elif self.tbl_sde.currentColumn() == self.posIndex:
                    if valCell == 'liste':
                        id_meta = self.tbl_sde.item(self.tbl_sde.currentRow(),0).text()
                        fenetreListe = FormListe(id_meta, self.dicoIndex[str(id_meta)].split(','), \
                                                 u'Liste des index de ') # envoi nomJeu, liste, texte
                        fenetreListe.exec_()

        except:
            pass


    def graphHisto(self, color):
        fig = plt.figure(num=None, figsize=(12, 10), dpi=70, facecolor='white', edgecolor='k')
        ax =  fig.add_subplot(111)

        dicoHisto = {}
        mois = {'01':'Jan','02':'Fev','03':'Mar','04':'Avr','05':'Mai','06':'Juin','07':'Juil','08':'Aou','09':'Sep', \
                '10':'Oct','11':'Nov','12':'Dec'}

        dirJson = Glob().dirJson
        js =open(dirJson + '//histo_jeu_detail.json')
        dicoHisto = json.load(js)
        js.close()

        totalJeu = []
        jeu_Maj = []
        jeu_Lyr = []
        jeu_Meta = []
        x = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
        xLabel = []

        for i, key in enumerate(sorted(dicoHisto.keys(), reverse = True)):
            if i < 12: # valeurs sur 1 an
                if key[-2:] == '01':
                    xLabel.append(key[:4])
                else:
                    xLabel.append(mois[key[-2:]])
                totalJeu.append(dicoHisto[key][0])
                jeu_Maj.append(dicoHisto[key][1])
                jeu_Lyr.append(dicoHisto[key][2])
                jeu_Meta.append(dicoHisto[key][3])

        #remise des valeurs dans le bon ordre
        totalJeu.reverse()
        jeu_Maj.reverse()
        jeu_Lyr.reverse()
        jeu_Meta.reverse()
        xLabel.reverse()

        plt.xticks(x, xLabel)
        plt.plot(x, totalJeu,"-", linewidth=2, color=color[3])
        plt.plot(x, jeu_Maj,"-", linewidth=2, color=color[2])
        plt.plot(x, jeu_Lyr,"-", linewidth=2, color=color[1])
        plt.plot(x, jeu_Meta,"-", linewidth=2, color=color[0])

        plt.grid()
        plt.ylabel('')
        plt.xlabel('-')

        return FigureCanvas(fig)


    def closeEvent(self, event):
        self.fermePlugin.emit()
        event.accept()

    def indicName(self):
        regles = {k:self.defQual[k] for k in self.defQual.keys() if self.defQual[k][0]==u'Jeux de données'}
        fenetreInd = FormIndicateur(regles)
        fenetreInd.exec_()

class FormMeta(QWidget, Ui_FormMeta):
    def __init__(self):
        QWidget.__init__(self)
        self.setupUi(self)

        #cablage aux fichiers Json
        self.dirJson = Glob().dirJson

        js =open(self.dirJson + '//meta_tableau.json')
        self.tabledata = json.load(js)
        js.close()

        js =open(self.dirJson + '//def_qualite.json')
        self.defQual = json.load(js)
        js.close()

        #Définition ordre des colonnes du tableau
        self.header = [('META_PKB72', u'Nom de la fiche'),('META_QUAL_IND', ''), ('META_SOURCE', 'Source'), \
                       ('MYB72_CONTA', u'Contact'), ('META_TITRE', u'Titre'), \
                       ('META_PB_FLUX', 'Pb. flux'),('META_NUMCOUCHE', u'N° couche'),('META_CHPVIDE', u'Chps obligatoires'), \
                       ('META_JEUDATEMODIF', u'Dernière modification'), ('META_MAJ_FICHE', u'MàJ indiquée'), \
                       ('META_MAJ_FREQ', u'Fréquence MàJ')]

        #initialisation du filtre
        self.listFiltre = []
        self.listFiltre.append('Tous')
        self.cmb_filtre.addItem('Tous')

        for i in self.defQual.keys():
            if self.defQual[i][0] == u'Métadonnées':
                self.listFiltre.append(str(i))
                val = self.defQual[i][1]
                self.cmb_filtre.addItem(val)

        #Chargement des données
        self.loadDataTableau()
        self.loadEnteteTableau()

        #Définition des connecteurs
        self.connect(self.tbl_meta, SIGNAL("itemSelectionChanged()"), self.hyperlink)
        self.connect(self.btn_qual, SIGNAL("clicked()"), self.indicName)
        self.connect(self.cmb_filtre, SIGNAL("currentIndexChanged(int)"), self.loadDataTableau)
        self.connect(self.txt_filtre, SIGNAL("textChanged(QString)"), self.loadDataTableau)

        # définition zone "widGraph" (cf. form_meta.ui)
        bar = self.graphBar()
        bar.setParent(self.widGraph)
        layout1 = QVBoxLayout()
        layout1.addWidget(bar)
        self.widGraph.setLayout(layout1)
        self.widGraph.baseSize()

        #titre
        self.txt_nb.setText('( ' + str(len([x for x in self.tabledata['META_QUALITE']])) + u' fiches )')

    def indicName(self):
        regles = {k:self.defQual[k] for k in self.defQual.keys() if self.defQual[k][0]==u'Métadonnées'}
        fenetreInd = FormIndicateur(regles)
        fenetreInd.exec_()

    def loadEnteteTableau(self):
        table = self.tbl_recap
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setRowCount(4)
        table.setColumnCount(4)
        entete = [u'Etat', u'', u'Description', u'En cours']
        stylesheet = "::section{Background-color:rgb(125,176,176);border-radius:20px;}"
        table.horizontalHeader().setStyleSheet(stylesheet)
        for i, val in enumerate(entete):
            item = QTableWidgetItem(val)
            item.setBackgroundColor(QColor(0,204,255))
            table.setHorizontalHeaderItem(i,item)

        #ligne 1
        table.setRowHeight(0, 40)
        table.setItem(0, 0, QTableWidgetItem('Critique'))
        table.setCellWidget(0, 1, IcoBad(self))
        table.setItem(0, 2, QTableWidgetItem(u"Réparation impérative. Pas utilisable en l'état.\nCause possible : "
                                             u"Le jeu de donnée n'existe plus, renseignements incomplets..."))
        ind3 = len([x for x in self.tabledata['META_QUAL_IND'] if x == 3])
        table.setItem(0, 3, QTableWidgetItem(str(ind3)))

        #ligne 2
        table.setRowHeight(1, 40)
        table.setItem(1, 0, QTableWidgetItem('Moyen'))
        table.setCellWidget(1, 1, IcoMid(self))
        table.setItem(1, 2, QTableWidgetItem(u"Doit être amélioré.\nCause possible : Fréquence de mise à jour "
                                             u"incorrecte,..."))
        ind2 = len([x for x in self.tabledata['META_QUAL_IND'] if x == 2])
        table.setItem(1, 3, QTableWidgetItem(str(ind2)))

        #ligne 3
        table.setRowHeight(2, 40)
        table.setItem(2, 0, QTableWidgetItem('Convenable'))
        table.setCellWidget(2, 1, IcoSat(self))
        table.setItem(2, 2, QTableWidgetItem(u"Peut être amélioré.\nCause possible : Pas de vignette graphique, "
                                             u"abscence de mots-clés..."))
        ind1 = len([x for x in self.tabledata['META_QUAL_IND'] if x == 1])
        table.setItem(2, 3, QTableWidgetItem(str(ind1)))

        #ligne 4
        table.setRowHeight(3, 40)
        table.setItem(3, 0, QTableWidgetItem('Excellent'))
        table.setCellWidget(3, 1, IcoGood(self))
        table.setItem(3, 2, QTableWidgetItem(u"Cette métadonnée répond à toutes nos règles de qualité"))
        ind0 = len([x for x in self.tabledata['META_QUAL_IND'] if x == None])
        table.setItem(3, 3, QTableWidgetItem(str(ind0)))

        table.resizeColumnsToContents()

    def graphBar(self):
        #data
        lstNoNone = [x for x in self.tabledata['META_QUALITE'] if x != None] #filtre les champs nuls
        Nb = len([x for x in self.tabledata['META_QUALITE']]) #total
        M1 = len([x for x in lstNoNone if x.find('M01')!=-1]) #Donnée présente
        M2 = len([x for x in lstNoNone if x.find('M02')!=-1]) #Renseignements complets
        M13 = len([x for x in lstNoNone if x.find('M13')!=-1]) #Fréquence définie

        fig = plt.figure(num=None, figsize=(24, 10), dpi=70, facecolor='white', edgecolor='k')
        val = [Nb-M13,Nb-M2, Nb-M1, Nb]
        label = [ u'Fréquence MàJ définie : ',u'Renseignements complets : ',u'Donnée présente : ',u'Total : ']
        pos = [0, 1, 2, 3]
        plt.axis('off')

        bars = plt.barh(pos, val, height=0.75, align='center', edgecolor = 'none')
        bars[0].set_facecolor('#9BA3FF')
        bars[1].set_facecolor('#9BA3FF')
        bars[2].set_facecolor('#9BA3FF')
        bars[3].set_facecolor('#2D4040')

        for i, v in enumerate(val):
            if i == 3:
                plt.text(v / 2, i, label[i] + str(v), color='white', fontweight='bold', ha='center', va='center')
            else:
                plt.text(10, i, label[i] + str(v), color='black', ha='left', va='center')

        #fig.subplots_adjust(left=0.1, bottom=0.2,
        #                    right=0.9, top=0.5, wspace=0.25, hspace=0.1)

        return FigureCanvas(fig)


    def loadDataTableau(self):
        """Chargement des données dans le tableau """
        #FILTRE sur le nom et règle de qualité
        filtreNom = self.txt_filtre.text().toAscii().data()
        selec = self.cmb_filtre.currentIndex()
        filtreQual = self.listFiltre[selec]

        #init données à charger dans le tableau
        loadData = {}

        #filtre sur le nom
        numListe = []
        for i, val in enumerate(self.tabledata['META_PKB72']):
            if filtreNom != '':
                if filtreNom in val:
                    if filtreQual != 'Tous':
                        if self.tabledata['META_QUALITE'][i]!=None:
                            if filtreQual in self.tabledata['META_QUALITE'][i]:
                                numListe.append(i)
                    else:
                        numListe.append(i)
            else:
                if filtreQual != 'Tous':
                    if self.tabledata['META_QUALITE'][i]!=None:
                        if filtreQual in self.tabledata['META_QUALITE'][i]:
                            numListe.append(i)
                else:
                    numListe.append(i)

        for champ in self.tabledata.keys():
            loadData[champ] = [self.tabledata[champ][x] for x in numListe]

        #Fin du filtre ,données dans loadData

        #init variable table
        table = self.tbl_meta
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSortingEnabled(False)
        table.clear()

        self.header

        #Définition de l'entête du tableau
        entete = [x[1] for x in self.header]
        champs = [x[0] for x in self.header]

        # initialisation de la table
        table.setRowCount(len(loadData[champs[0]]))
        table.setColumnCount(len(entete))

        # définition des labels (entête)
        stylesheet = "::section{Background-color:rgb(72,102,102);border-radius:20px;padding-bottom:5px;padding-top:5px;" \
                     "color:white;}"
        table.horizontalHeader().setStyleSheet(stylesheet)

        table.setHorizontalHeaderLabels(entete)
        new_item = QTableWidgetItem()
        font = QFont("MS Shell Dlg 2", 9)
        font.setUnderline(True)

        # CHARGEMENT COLONNE
        for a, champ  in enumerate(champs):
            if champ == 'META_PKB72':
                self.posFiche = a
                for i, val in enumerate(loadData[champ]):
                    new_item = QTableWidgetItem(val)
                    new_item.setTextColor(QColor(0,0,204,255))
                    new_item.setFont(font)
                    table.setItem(i,a, new_item)

            elif champ == 'META_MAJ_FICHE':
                mois = {'01':u'janvier','02':u'février','03':u'mars','04':u'avril','05':u'mai','06':u'juin','07':u'juillet', \
                        '08':u'août','09':u'septembre','10':u'octobre','11':u'novembre','12':u'décembre'}
                for i, val in enumerate(loadData[champ]):
                    if val != None:
                        table.setItem(i, a, QTableWidgetItem(val[:4] + ' ' + mois[val[4:]]))
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))

            elif champ == 'META_QUAL_IND':
                self.posQual = a
                for i, val in enumerate(loadData[champ]):
                    if val == 3:
                        table.setCellWidget(i, a, IcoBad(self))
                        table.setItem(i, a, QTableWidgetItem('3'))
                    if val == 2:
                        table.setCellWidget(i, a, IcoMid(self))
                        table.setItem(i, a, QTableWidgetItem('2'))
                    if val == 1:
                        table.setCellWidget(i, a, IcoSat(self))
                        table.setItem(i, a, QTableWidgetItem('1'))
                    if val == None:
                        table.setCellWidget(i, a, IcoGood(self))
                        table.setItem(i, a, QTableWidgetItem('0'))

            elif champ == 'META_CHPVIDE':
                self.dicoChap = {}
                self.posChVide = a #position dans la table
                for i, val in enumerate(loadData[champ]):
                    if val != None:
                        new_item = QTableWidgetItem('manquants')
                        new_item.setTextColor(QColor(0,0,204,255))
                        new_item.setFont(font)
                        table.setItem(i,a, new_item)
                        self.dicoChap[loadData['META_PKB72'][i]] = loadData[champ][i] #Création dico
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))

            elif champ == 'META_JEUDATEMODIF':
                for i, val in enumerate(loadData[champ]):
                    date = ''.join(str(e) for e in val)
                    if date == 'None':
                        table.setItem(i, a, QTableWidgetItem(''))
                    else:
                        table.setItem(i, a, QTableWidgetItem(date))

            else:
                for i, val in enumerate(loadData[champ]):
                    if val == None:
                        table.setItem(i, a, QTableWidgetItem(''))
                    elif type(val) == float:
                        table.setItem(i, a, QTableWidgetItem(QtCore.QString.number(val,'g',10)))
                    elif val == 'n/a':
                        new_item = QTableWidgetItem('n/a')
                        new_item.setTextColor(QColor(178,174,176,255))
                        table.setItem(i, a, new_item)
                    else:
                        table.setItem(i, a, QTableWidgetItem(val))
                    table.setRowHeight(i, 18) #hauteur ligne


        #Mise en forme
        table.setSortingEnabled(True)
        table.resizeColumnsToContents()
        table.sortByColumn(0, QtCore.Qt.AscendingOrder)


    def hyperlink(self):
        try:
            valCell = self.tbl_meta.selectedItems()[0].text()

            #définition de l'hyperlien sur les métadonnées
            if self.tbl_meta.currentColumn() == self.posFiche:
                id_meta = self.tbl_meta.item(self.tbl_meta.currentRow(),0).text()
                url_meta = 'http://applications001.brest-metropole-oceane.fr/vipdu60/aspx/HTDU502.aspx?TYPE=FICHE&ID=' \
                           + id_meta
                webbrowser.open(url_meta)

            #définition de l'hyperlien sur le niveau de qualité
            elif self.tbl_meta.currentColumn() == self.posQual:
                id_meta = self.tbl_meta.item(self.tbl_meta.currentRow(),0).text()
                index = self.tabledata['META_PKB72'].index(id_meta)
                nivQual = self.tabledata['META_QUALITE'][index]
                if nivQual != None:
                    fenetreListe = FormTree(id_meta, nivQual, self.defQual ) # envoi nomJeu, liste
                    fenetreListe.exec_()

            #définition de l'hyperlien sur liste des champs vides
            elif self.tbl_meta.currentColumn() == self.posChVide:
                    if valCell == 'manquants':
                        id_meta = self.tbl_meta.item(self.tbl_meta.currentRow(),0).text()
                        fenetreListe = FormListe(id_meta, self.dicoChap[str(id_meta)].split('|'), \
                                                 u'Champs non renseignés de la fiche ') # envoi nomJeu, liste
                        fenetreListe.exec_()
        except:
            pass

class FormLyr(QWidget, Ui_FormLyr):
    def __init__(self):
        QWidget.__init__(self)
        self.setupUi(self)

        #cablage aux fichiers Json
        self.dirJson = Glob().dirJson

        js =open(self.dirJson + '//lyr_tableau.json')
        self.tabledata = json.load(js)
        js.close()

        js =open(self.dirJson + '//def_qualite.json')
        self.defQual = json.load(js)
        js.close()

        #Init liste des lyr
        self.listLyr = self.tabledata.keys()

        #Icone du dossier
        iconDos = QtGui.QPixmap(os.path.dirname(os.path.abspath(__file__)) + '\icons\dossier.png')
        self.btn_dossier.setIcon(QtGui.QIcon(iconDos))

        #initialisation de la combo box "cmb_ind"
        self.listFiltre = []
        self.listFiltre.append('Tous')
        self.cmb_ind.addItem('Tous')

        for i in self.defQual.keys():
            if self.defQual[i][0] == u'Fichiers lyr':
                self.listFiltre.append(str(i))
                val = self.defQual[i][1]
                self.cmb_ind.addItem(val)

        self.listDossier = ['Tous', 'J:', 'H:']
        self.cmb_filtre.addItems(self.listDossier)

        #Définition ordre des colonnes
        self.header = [('LYR_FIC', u'Fichier Lyr'), ('LYR_COUCHE', u'Nom de la couche'), ('LYR_QUAL_IND', u''), \
                       ('LYR_SOURCE', u'Nom de la source'), ('LYR_BASESDE', u'Nom de la base (ou couche)'), \
                       ('LYR_PATH', 'Chemin du fichier lyr')   ]

        #Chargement des données
        self.loadWidget()
        self.loadRecapTableau()
        self.loadDataTableau()
        self.loadListeLyr()

        #Définition des connecteurs
        self.connect(self.lst_lyr, SIGNAL("itemSelectionChanged()"), self.affInfo)
        self.connect(self.btn_dossier, SIGNAL("clicked()"), self.affDossier)
        self.connect(self.lineEdit, SIGNAL("textChanged(QString)"), self.loadListeLyr)
        self.connect(self.tbl_lyr, SIGNAL("itemSelectionChanged()"), self.hyperlink)
        self.connect(self.cmb_ind, SIGNAL("currentIndexChanged(int)"), self.loadDataTableau)
        self.connect(self.cmb_filtre, SIGNAL("currentIndexChanged(int)"), self.filtreDossier)
        self.connect(self.btn_qual, SIGNAL("clicked()"), self.indicName)


    def loadWidget(self):
        #Compteur sur le nombre lyr sur H et J
        lyrs = self.tabledata.keys()
        countJ, countH = 0, 0
        for lyr in lyrs:
            infos = self.tabledata[lyr].values()[0]
            dicInfo = {k.split('|')[0]:k.split('|')[1] for k in infos}
            if dicInfo['LYR_PATH'][0] == 'J':
                countJ += 1
            if dicInfo['LYR_PATH'][0] == 'H':
                countH += 1
        self.txt_j.setText(u'Accessibles usagers sur J: ' + str(countJ))
        self.txt_h.setText(u'Internes SIG sur H: ' + str(countH))

    def filtreDossier(self):
        selec = self.cmb_filtre.currentIndex()
        dossier = self.listDossier[selec]

        self.listLyr = []
        if dossier == 'Tous':
            self.listLyr = self.tabledata.keys()
        else:
            for lyr in self.tabledata.keys():
                couche0 = self.tabledata[lyr].keys()[0]
                for j in self.tabledata[lyr][couche0]:
                    if j.split('|')[0]=='LYR_PATH':
                        if j.split('|')[1][0:2]==dossier:
                            self.listLyr.append(lyr)

        self.loadListeLyr() #chargement de la liste

    def loadListeLyr(self):
        #suppression tree_lyr
        try:
            self.model.removeColumn(0)
            self.model.setHorizontalHeaderLabels([''])
        except:
            pass

        self.lst_lyr.clear()

        #application du filtre
        if self.lineEdit.text()!='':
            filtre =self.lineEdit.text().toAscii().data()
            for lyr in self.listLyr:
                if unicode(filtre.decode('latin1')).lower() in lyr.lower():
                    self.lst_lyr.addItem(lyr)
        else:
            self.lst_lyr.addItems(self.listLyr)


        #trie de la sélection
        self.lst_lyr.sortItems()

        if len(self.lst_lyr) > 1:
            chaine = '(' + str(len(self.lst_lyr)) + ' fichiers lyr)'
        else:
            chaine = '(' + str(len(self.lst_lyr)) + ' fichier lyr)'

        self.lbl_nblyr.setText(chaine)

        if self.lst_lyr.currentItem() == None:
            self.btn_dossier.setEnabled(False)
        else:
            self.btn_dossier.setEnabled(True)

    def affDossier(self):
        import subprocess
        lyr = self.lst_lyr.currentItem().text().toAscii().data()
        nomLyr = unicode(lyr.decode('latin1'))
        couche0 = self.tabledata[nomLyr].keys()[0]

        for j in self.tabledata[nomLyr][couche0]:
            if j.split('|')[0]=='LYR_PATH':
                dossier = j.split('|')[1].encode('latin1') + '\\'
                try:
                    subprocess.Popen(r'explorer /open,"' + dossier +'"')
                except:
                    pass

    def affInfo(self):
        t_lyr = QStandardItem(u'Couches de données :')
        #Si aucun lyr sélectionné...
        if self.lst_lyr.currentItem() == None:
            self.btn_dossier.setEnabled(False)
        else:
            self.btn_dossier.setEnabled(True)

        # définiton de QTreeView "tree_lyr"
        lyr = self.lst_lyr.currentItem().text().toAscii().data()
        nomLyr = unicode(lyr.decode('latin1'))
        infos = self.tabledata[nomLyr]

        view = self.tree_lyr
        view.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.model = QStandardItemModel()
        self.model.setHorizontalHeaderLabels(['Infos de ' + lyr + ' :'])
        view.setModel(self.model)
        view.setUniformRowHeights(True)

        # Chargement infos couches
        for i in infos.keys():
            t_couche = QStandardItem(i)
            t_lyr.appendRow([t_couche])
            for j in infos[i]:
                if j.split('|')[0]=='LYR_BASESDE':
                    t_info = QStandardItem('Base : ' + j.split('|')[1])
                    t_couche.appendRow(t_info)

                if j.split('|')[0]=='LYR_SOURCE':
                    t_info = QStandardItem('Source : ' + j.split('|')[1])
                    t_couche.appendRow(t_info)

                if j.split('|')[0]=='LYR_JOIN':
                    if j.split('|')[1]!='':
                        t_info = QStandardItem('Jointure : ' + j.split('|')[1])
                        t_couche.appendRow(t_info)

        self.model.appendRow(t_lyr)
        view.setFirstColumnSpanned(3, view.rootIndex(), True)
        view.expandAll()


    def loadDataTableau(self):
        """Chargement des données dans le tableau détaillé"""
        #choix du filtre (par défaut : 'Tous')
        selec = self.cmb_ind.currentIndex()
        filtre = self.listFiltre[selec]

        #init variable table
        table = self.tbl_lyr
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSortingEnabled(False)
        table.clear()

        #Définition de l'entête du tableau
        entete = [x[1] for x in self.header]
        champs = [x[0] for x in self.header]

        # initialisation de la table
        table.setRowCount(self.sum)
        table.setColumnCount(len(entete))

        # définition des labels (entête)
        stylesheet = "::section{Background-color:rgb(72,102,102);border-radius:20px;padding-bottom:5px;padding-top:5px;" \
                     "color:white;}"
        table.horizontalHeader().setStyleSheet(stylesheet)

        table.setHorizontalHeaderLabels(entete)
        table.horizontalHeader().setToolTip(u"Autant de lignes que de couches dans le fichier lyr") #info-bulle

        new_item = QTableWidgetItem()
        font = QFont("MS Shell Dlg 2", 9)
        font.setUnderline(True)

        # CHARGEMENT COLONNE
        #Création tuple (lyr, couche)
        champs = [x[0] for x in self.header]
        liste_lyr = sorted(self.tabledata.keys())
        tulple_couche = []

        for i, lyr in enumerate(liste_lyr):
            for j in self.tabledata[lyr].keys():
                tulple_couche.append((lyr, j))

        row = 0
        for lyr, couche in tulple_couche:
            infos = self.tabledata[lyr][couche]
            dicInfo = {k.split('|')[0]:k.split('|')[1] for k in infos}
            for info in infos:
                if info.split('|')[0]=='LYR_QUALITE':
                    if filtre == 'Tous': #sans filtre
                        table.setRowHeight(row, 18)
                        table.setItem(row, 0, QTableWidgetItem(lyr)) #Colonne fichier lyr
                        table.setItem(row, 1, QTableWidgetItem(couche)) #Colonne nom couche
                        #Colonne icone qualité
                        if dicInfo['LYR_QUAL_IND']== '':
                            table.setCellWidget(row, 2, IcoGood(self))
                            table.setItem(row, 2, QTableWidgetItem('0'))
                        if dicInfo['LYR_QUAL_IND'] == '3':
                            table.setCellWidget(row, 2, IcoBad(self))
                            table.setItem(row, 2, QTableWidgetItem('3'))
                        if dicInfo['LYR_QUAL_IND'] == '2':
                            table.setCellWidget(row, 2, IcoMid(self))
                            table.setItem(row, 2, QTableWidgetItem('2'))
                        if dicInfo['LYR_QUAL_IND'] == '1':
                            table.setCellWidget(row, 2, IcoSat(self))
                            table.setItem(row, 2, QTableWidgetItem('1'))


                        table.setItem(row, 3, QTableWidgetItem(dicInfo['LYR_SOURCE'])) #Colonne nom source
                        table.setItem(row, 4, QTableWidgetItem(dicInfo['LYR_BASESDE'])) #Colonne nom source
                        table.setItem(row, 5, QTableWidgetItem(dicInfo['LYR_PATH'])) #Colonne nom source
                        row += 1

                    else: #avec filtre
                        if filtre in info.split('|')[1]:
                            table.setRowHeight(row, 18)
                            table.setItem(row, 0, QTableWidgetItem(lyr)) #Colonne fichier lyr
                            table.setItem(row, 1, QTableWidgetItem(couche)) #Colonne nom couche

                            #Colonne icone qualité
                            if int(dicInfo['LYR_QUAL_IND']) == 3:
                                table.setCellWidget(row, 2, IcoBad(self))
                                table.setItem(row, 2, QTableWidgetItem('3'))
                            if int(dicInfo['LYR_QUAL_IND']) == 2:
                                table.setCellWidget(row, 2, IcoMid(self))
                                table.setItem(row, 2, QTableWidgetItem('2'))
                            if int(dicInfo['LYR_QUAL_IND']) == 1:
                                table.setCellWidget(row, 2, IcoSat(self))
                                table.setItem(row, 2, QTableWidgetItem('1'))
                            if int(dicInfo['LYR_QUAL_IND']) == None:
                                table.setCellWidget(row, 2, IcoGood(self))
                                table.setItem(row, 2, QTableWidgetItem('0'))

                            table.setItem(row, 3, QTableWidgetItem(dicInfo['LYR_SOURCE'])) #Colonne nom source
                            table.setItem(row, 4, QTableWidgetItem(dicInfo['LYR_BASESDE'])) #Colonne nom source
                            table.setItem(row, 5, QTableWidgetItem(dicInfo['LYR_PATH'])) #Colonne nom source
                            row += 1


        table.setRowCount(row)


        #Mise en forme
        table.setSortingEnabled(True)
        table.resizeColumnsToContents()

    def loadRecapTableau(self):
        #Compteur suivant niveau de qualité (3,2,1,0)
        lyrs = self.tabledata.keys()
        niv3,niv2,niv1,niv0 = 0,0,0,0
        for lyr in lyrs:
            couches = self.tabledata[lyr].keys()
            for couche in couches:
                dicInfo = {k.split('|')[0]:k.split('|')[1] for k in self.tabledata[lyr][couche]}
                if dicInfo['LYR_QUAL_IND'] == '3':
                    niv3 += 1
                if dicInfo['LYR_QUAL_IND'] == '2':
                    niv2 += 1
                if dicInfo['LYR_QUAL_IND'] == '1':
                    niv1 += 1
                if dicInfo['LYR_QUAL_IND'] == '':
                    niv0 += 1
        self.sum = niv0+niv1+niv2+niv3
        self.txt_sum.setText('TOTAL COUCHES : ' + str(self.sum))

        #Affichage du tableau
        table = self.tbl_recap
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setRowCount(4)
        table.setColumnCount(4)
        entete = [u'Etat', u'', u'Description', u'En cours']
        stylesheet = "::section{Background-color:rgb(125,176,176);border-radius:20px;}"
        table.horizontalHeader().setStyleSheet(stylesheet)
        for i, val in enumerate(entete):
            item = QTableWidgetItem(val)
            item.setBackgroundColor(QColor(0,204,255))
            table.setHorizontalHeaderItem(i,item)


        #ligne 1
        table.setRowHeight(0, 40)
        table.setItem(0, 0, QTableWidgetItem('Critique'))
        table.setCellWidget(0, 1, IcoBad(self))
        table.setItem(0, 2, QTableWidgetItem(u"Réparation impérative. Pas utilisable en l'état.\nCause possible : "
                                             u"source cassée, erreur symbologie,..."))
        table.setItem(0, 3, QTableWidgetItem(str(niv3)))

        #ligne 2
        table.setRowHeight(1, 40)
        table.setItem(1, 0, QTableWidgetItem('Moyen'))
        table.setCellWidget(1, 1, IcoMid(self))
        table.setItem(1, 2, QTableWidgetItem(u"Doit être amélioré.\nCause possible : compte utilisateur dans chemin "
                                             u"d'accès aux source de données,..."))
        table.setItem(1, 3, QTableWidgetItem(str(niv2)))

        #ligne 3
        table.setRowHeight(2, 40)
        table.setItem(2, 0, QTableWidgetItem('Convenable'))
        table.setCellWidget(2, 1, IcoSat(self))
        table.setItem(2, 2, QTableWidgetItem(u"Peut être amélioré.\nCause possible : erreur dans l'étiquetage,..."))
        table.setItem(2, 3, QTableWidgetItem(str(niv1)))

        #ligne 4
        table.setRowHeight(3, 40)
        table.setItem(3, 0, QTableWidgetItem('Excellent'))
        table.setCellWidget(3, 1, IcoGood(self))
        table.setItem(3, 2, QTableWidgetItem(u"Cette couche de données répond à toutes nos règles de qualité"))
        table.setItem(3, 3, QTableWidgetItem(str(niv0)))

        table.resizeColumnsToContents()

    def hyperlink(self):
        #définition de l'hyperlien sur le niveau de qualité
            if self.tbl_lyr.currentColumn() == 2:
                lyr = self.tbl_lyr.item(self.tbl_lyr.currentRow(),0).text().toAscii().data()
                couche = self.tbl_lyr.item(self.tbl_lyr.currentRow(),1).text().toAscii().data()
                infos = self.tabledata[unicode(lyr.decode('latin1'))][unicode(couche.decode('latin1'))]
                dicInfo = {k.split('|')[0]:k.split('|')[1] for k in infos}

                nivQual = dicInfo['LYR_QUALITE']
                if nivQual != None:
                    fenetreListe = FormTree(lyr, nivQual, self.defQual ) # envoi nomJeu, liste
                    fenetreListe.exec_()

    def indicName(self):
        regles = {k:self.defQual[k] for k in self.defQual.keys() if self.defQual[k][0]==u'Fichiers lyr'}
        fenetreInd = FormIndicateur(regles)
        fenetreInd.exec_()

class FormService(QWidget, Ui_FormService):
    def __init__(self):
        QWidget.__init__(self)
        self.setupUi(self)

        #cablage aux fichiers Json
        self.dirJson = Glob().dirJson

        js =open(self.dirJson + '//service_tableau.json')
        self.tabledata = json.load(js)
        js.close()

        js = open(self.dirJson + '//service_dicoSw_Couche.json')
        self.dicoSw_Couche = json.load(js)
        js.close()

        js = open(self.dirJson + '//service_dicoSw_Jeu.json')
        self.dicoSw_Jeu = json.load(js)
        js.close()

        js = open(self.dirJson + '//service_dicoRole_Sw.json')
        self.dicoRole_Sw = json.load(js)
        js.close()

        js = open(self.dirJson + '//service_dicoSw_Role.json')
        self.dicoSw_Role = json.load(js)
        js.close()

        js =open(self.dirJson + '//def_qualite.json')
        self.defQual = json.load(js)
        js.close()

        #Init liste des services
        self.listeSw = self.tabledata['SW_NOM']

        #Icone du dossier
        iconDos = QtGui.QPixmap(os.path.dirname(os.path.abspath(__file__)) + '\icons\dossier.png')
        self.btn_dossier.setIcon(QtGui.QIcon(iconDos))

        #initialisation de la combo box "cmb_filtre"
        self.listFiltre = []
        self.listFiltre.append('Tous')
        self.cmb_filtre.addItem('Tous')

        for i in self.defQual.keys():
            if self.defQual[i][0] == u'Services Web':
                self.listFiltre.append(str(i))
                val = self.defQual[i][1]
                self.cmb_filtre.addItem(val)

        # Récupération de la liste des dossiers de services web
        self.listDossier = ['Tous']
        for service in self.tabledata['SW_NOM']:
            dossier = service.split('|')[1]
            if dossier not in self.listDossier :
                    self.listDossier.append(dossier)
        self.cmb_dossier.addItems(self.listDossier)

        #Définition ordre des colonnes
        self.header = [('SW_NOM', u'Nom'), ('SW_NOM', u'Dossier'), ('SW_STATUT', u'Statut'),('SW_QUAL_IND', u''), \
                       ('SW_TITRE', u'Titre du service'), ('SW_SRC_PRESENTE', u'Présence Source'), \
                       ('SW_SOURCE', u'Nom de la source'), ('SW_NB_LIEN_ABS', u'Couches sans lien'), \
                       ('SW_DROIT', u'Droits'), ('SW_SRC_CREATION', u'Création Source'), ('SW_SRC_MAJ', u'MàJ Source'), \
                       ('SW_PROCESSUS', u'Liste des processus'), ('Roles-Users', u'Roles-Users')]

        #Chargement des données
        self.loadWidget()
        self.loadEnteteTableau()
        self.loadDataTableau()
        self.loadListeService()

        #Définition des connecteurs
        self.connect(self.cmb_dossier, SIGNAL("currentIndexChanged(int)"), self.filtreDossier)
        self.connect(self.lineEdit, SIGNAL("textChanged(QString)"), self.loadListeService)
        self.connect(self.btn_dossier, SIGNAL("clicked()"), self.affDossier)
        self.connect(self.btn_qual, SIGNAL("clicked()"), self.indicName)
        self.connect(self.lst_service, SIGNAL("itemSelectionChanged()"), self.affInfo)
        self.connect(self.cmb_role, SIGNAL("activated(int)"), self.role)
        self.connect(self.cmb_filtre, SIGNAL("currentIndexChanged(int)"), self.loadDataTableau)
        self.connect(self.txt_filtre, SIGNAL("textChanged(QString)"), self.loadDataTableau)
        self.connect(self.tbl_service, SIGNAL("itemSelectionChanged()"), self.hyperlink)

        #Init liste des rôles
        self.cmb_role.addItem('-')
        self.cmb_role.addItems(sorted(self.dicoRole_Sw.keys()))


    def loadWidget(self):
        #Compteur sur le nombre services dans dossier Public et Secure
        countPublic, countSecure = 0, 0
        for i, service in enumerate(self.tabledata['SW_NOM']):
            if service.split('|')[1] == 'public':
                countPublic += 1
            if service.split('|')[1] == 'secure':
                countSecure += 1
        self.txt_public.setText(u'Publiés dans Public ' + str(countPublic))
        self.txt_secure.setText(u'Publiés dans Secure ' + str(countSecure))

    def filtreDossier(self):
        selec = self.cmb_dossier.currentIndex()
        dossier = self.listDossier[selec]
        self.listeSw = []

        if dossier == 'Tous':
            self.listeSw = self.tabledata['SW_NOM']
        else:
            for service in self.tabledata['SW_NOM']:
                dir = service.split('|')[1]
                if dir == dossier :
                    self.listeSw.append(service)

        self.loadListeService() #chargement de la liste

    def loadListeService(self):
        #suppression tree_service
        try:
            self.model.removeColumn(0)
            self.model.setHorizontalHeaderLabels([''])
        except:
            pass

        self.lst_service.clear()

        #application du filtre
        if self.lineEdit.text()!='':
            filtre =self.lineEdit.text().toAscii().data()
            for service in self.listeSw:
                if unicode(filtre.decode('latin1')).lower() in service.lower():
                    self.lst_service.addItem(service)
        else:
            self.lst_service.addItems(self.listeSw)


        #tri de la sélection
        self.lst_service.sortItems()

        if len(self.lst_service) > 1:
            chaine = '(' + str(len(self.lst_service)) + ' services web)'
        else:
            chaine = '(' + str(len(self.lst_service)) + ' services web)'

        self.lbl_nb_service.setText(chaine)

        if self.lst_service.currentItem() == None:
            self.btn_dossier.setEnabled(False)
        else:
            self.btn_dossier.setEnabled(True)

    def affDossier(self):
        import subprocess
        nomTech = self.lst_service.currentItem().text().toAscii().data()
        service = unicode(nomTech.decode('latin1'))
        path = r'\\hcu234.dit.cb\v235\arcgisserver\config-store\services'
        nom = service.split('|')[0].encode('latin1')
        dossier = service.split('|')[1].encode('latin1')
        listeDir = os.listdir(path + '\\' + dossier)

        for dir in listeDir:
            if dir.startswith(nom + "."):
                rootSw = path + '\\' + dossier + '\\' + dir
                try:
                    subprocess.Popen(r'explorer /open,"' + rootSw +'"')
                except:
                    pass

    def affInfo(self):
        t_coucheSw = QStandardItem(u'Couches de données :')
        t_jeuSw = QStandardItem(u'Jeux de données :')

        #Si aucun service sélectionné...
        if self.lst_service.currentItem() == None:
            self.btn_dossier.setEnabled(False)
        else:
            self.btn_dossier.setEnabled(True)

        # définiton de QTreeView "tree_service"
        selec = self.lst_service.currentItem().text().toAscii().data()
        service = unicode(selec.decode('latin1'))

        # Si le service séléctionné a une source avec des couches
        if service in self.dicoSw_Couche.keys() or service in self.dicoSw_Jeu.keys():
            couches = self.dicoSw_Couche[service]
            jeux = self.dicoSw_Jeu[service]

            view = self.tree_service
            view.setSelectionBehavior(QAbstractItemView.SelectRows)
            self.model = QStandardItemModel()
            self.model.setHorizontalHeaderLabels([u'Liste des couches et jeux de données de : \n' + selec])
            view.setModel(self.model)
            view.setUniformRowHeights(True)

            # Chargement de la liste des couches
            for i in couches:
                t_couche = QStandardItem(i)
                t_coucheSw.appendRow([t_couche])

            # Chargement de la liste des jeux de données
            for j in jeux:
                t_jeu = QStandardItem(j)
                t_jeuSw.appendRow([t_jeu])

            self.model.appendRow(t_coucheSw)
            self.model.appendRow(t_jeuSw)
            view.setFirstColumnSpanned(3, view.rootIndex(), True)
            view.expandAll()

        # Sinon
        else:
            view = self.tree_service
            view.setSelectionBehavior(QAbstractItemView.SelectRows)
            self.model = QStandardItemModel()
            self.model.setHorizontalHeaderLabels([selec + '\nn\'a pas de couches.'])
            view.setModel(self.model)
            view.setUniformRowHeights(True)

    def role(self):
        roleSelec = self.cmb_role.currentText().toUtf8().data()
        if roleSelec != '-':
            # envoi Service web, liste
            fenetreListe = FormListe(roleSelec, self.dicoRole_Sw[roleSelec], u'Services web soumis au rôle ')
            fenetreListe.exec_()

    def loadEnteteTableau(self):
        table = self.tbl_entete
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setRowCount(4)
        table.setColumnCount(4)
        entete = [u'Etat', u'', u'Description', u'En cours']
        stylesheet = "::section{Background-color:rgb(125,176,176);border-radius:20px;}"
        table.horizontalHeader().setStyleSheet(stylesheet)
        for i, val in enumerate(entete):
            item = QTableWidgetItem(val)
            item.setBackgroundColor(QColor(0,204,255))
            table.setHorizontalHeaderItem(i,item)

        #ligne 1
        table.setRowHeight(0, 40)
        table.setItem(0, 0, QTableWidgetItem('Critique'))
        table.setCellWidget(0, 1, IcoBad(self))
        table.setItem(0, 2, QTableWidgetItem(u"Réparation impérative. Pas utilisable en l'état.\nCause possible : "
                                             u"Service inactif sans indication de veille,..."))
        ind3 = len([x for x in self.tabledata['SW_QUAL_IND'] if x == 3])
        table.setItem(0, 3, QTableWidgetItem(str(ind3)))

        #ligne 2
        table.setRowHeight(1, 40)
        table.setItem(1, 0, QTableWidgetItem('Moyen'))
        table.setCellWidget(1, 1, IcoMid(self))
        table.setItem(1, 2, QTableWidgetItem(u"Doit être amélioré.\nCause possible : Source du service manquante, "
                                             u"pas de titre (= description),..."))
        ind2 = len([x for x in self.tabledata['SW_QUAL_IND'] if x == 2])
        table.setItem(1, 3, QTableWidgetItem(str(ind2)))

        #ligne 3
        table.setRowHeight(2, 40)
        table.setItem(2, 0, QTableWidgetItem('Convenable'))
        table.setCellWidget(2, 1, IcoSat(self))
        table.setItem(2, 2, QTableWidgetItem(u"Peut être amélioré.\nCause possible : Service actif avec indication "
                                             u"de veille,..."))
        ind1 = len([x for x in self.tabledata['SW_QUAL_IND'] if x == 1])
        table.setItem(2, 3, QTableWidgetItem(str(ind1)))

        #ligne 4
        table.setRowHeight(3, 40)
        table.setItem(3, 0, QTableWidgetItem('Excellent'))
        table.setCellWidget(3, 1, IcoGood(self))
        table.setItem(3, 2, QTableWidgetItem(u"Ce service web répond à toutes nos règles de qualité"))
        ind0 = len([x for x in self.tabledata['SW_QUAL_IND'] if x == None])
        table.setItem(3, 3, QTableWidgetItem(str(ind0)))

        table.resizeColumnsToContents()

    def loadDataTableau(self):
        """Chargement des données dans le tableau """
        #FILTRE sur le nom et règle de qualité
        filtreNom = self.txt_filtre.text().toAscii().data()
        selec = self.cmb_filtre.currentIndex()
        filtreQual = self.listFiltre[selec]

        #init données à charger dans le tableau
        loadData = {}

        #filtre sur le nom en fonction de la qualité sélectionnée
        numListe = []
        for i, service in enumerate(self.tabledata['SW_NOM']):
            if filtreNom != '':
                if filtreNom in service:
                    if filtreQual != 'Tous':
                        if self.tabledata['SW_QUALITE'][i]!=None:
                            if filtreQual in self.tabledata['SW_QUALITE'][i]:
                                numListe.append(i)
                    else:
                        numListe.append(i)
            else:
                if filtreQual != 'Tous':
                    if self.tabledata['SW_QUALITE'][i]!=None:
                        if filtreQual in self.tabledata['SW_QUALITE'][i]:
                            numListe.append(i)
                else:
                    numListe.append(i)

        for champ in self.tabledata.keys():
            loadData[champ] = [self.tabledata[champ][x] for x in numListe]

        #Fin du filtre, données dans dictionnaire loadData

        #init variable table
        table = self.tbl_service
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSortingEnabled(False)
        table.clear()

        #Définition de l'entête du tableau
        entete = [x[1] for x in self.header]
        champs = [x[0] for x in self.header]

        # initialisation de la table
        table.setRowCount(len(loadData[champs[0]]))
        table.setColumnCount(len(entete))

        # définition des labels (entête)
        stylesheet = "::section{Background-color:rgb(72,102,102);border-radius:20px;padding-bottom:5px;padding-top:5px;" \
                     "color:white;}"
        table.horizontalHeader().setStyleSheet(stylesheet)

        table.setHorizontalHeaderLabels(entete)
        new_item = QTableWidgetItem()
        font = QFont("MS Shell Dlg 2", 9)
        font.setUnderline(True)

        # CHARGEMENT COLONNE
        for a, champ  in enumerate(champs):

            if champ == 'SW_NOM':
                for b, alias in enumerate(entete):
                    if alias == 'Nom':
                        for i, val in enumerate(loadData[champ]):
                            nom = val.split('|')[0]
                            new_item = QTableWidgetItem(nom)
                            table.setItem(i,b, new_item)

                    elif alias == 'Dossier':
                        for i, val in enumerate(loadData[champ]):
                            dossier = val.split('|')[1]
                            new_item = QTableWidgetItem(dossier)
                            table.setItem(i,b, new_item)

            elif champ == 'SW_QUAL_IND':
                self.posQual = a
                for i, val in enumerate(loadData[champ]):
                    if val == 3:
                        table.setCellWidget(i, a, IcoBad(self))
                        table.setItem(i, a, QTableWidgetItem('3'))
                    if val == 2:
                        table.setCellWidget(i, a, IcoMid(self))
                        table.setItem(i, a, QTableWidgetItem('2'))
                    if val == 1:
                        table.setCellWidget(i, a, IcoSat(self))
                        table.setItem(i, a, QTableWidgetItem('1'))
                    if val == None:
                        table.setCellWidget(i, a, IcoGood(self))
                        table.setItem(i, a, QTableWidgetItem('0'))

            elif champ == 'SW_SRC_MAJ':
                for i, val in enumerate(loadData[champ]):
                    date = ''.join(str(e) for e in val)
                    if date == 'None':
                        table.setItem(i, a, QTableWidgetItem(''))
                    else:
                        table.setItem(i, a, QTableWidgetItem(date))

            elif champ == 'SW_SRC_CREATION':
                for i, val in enumerate(loadData[champ]):
                    date = ''.join(str(e) for e in val)
                    if date == 'None':
                        table.setItem(i, a, QTableWidgetItem(''))
                    else:
                        table.setItem(i, a, QTableWidgetItem(date))

            elif champ == 'SW_NB_LIEN_ABS':
                for i, val in enumerate(loadData[champ]):
                    if val == None:
                        new_item = QTableWidgetItem('')
                        table.setItem(i,a, new_item)
                    else:
                        new_item = QTableWidgetItem(str(int(val)))
                        table.setItem(i, a, new_item)

            elif champ == 'Roles-Users':
                self.posRoleUser = a  # position dans la table
                for i in range(len(loadData[champs[0]])):
                    if loadData['SW_NOM'][i] in self.dicoSw_Role.keys():
                        new_item = QTableWidgetItem('oui')
                        new_item.setTextColor(QColor(0, 0, 204, 255))
                        new_item.setFont(font)
                        table.setItem(i, a, new_item)
                    else:
                        table.setItem(i, a, QTableWidgetItem(''))

            else:
                for i, val in enumerate(loadData[champ]):
                    if val == None:
                        table.setItem(i, a, QTableWidgetItem(''))
                    elif type(val) == float:
                        table.setItem(i, a, QTableWidgetItem(QtCore.QString.number(val,'g',10)))
                    elif val == 'n/a':
                        new_item = QTableWidgetItem('n/a')
                        new_item.setTextColor(QColor(178,174,176,255))
                        table.setItem(i, a, new_item)
                    else:
                        table.setItem(i, a, QTableWidgetItem(val))
                    table.setRowHeight(i, 18) #hauteur ligne

        #Mise en forme
        table.setSortingEnabled(True)
        table.resizeColumnsToContents()
        table.sortByColumn(0, QtCore.Qt.AscendingOrder)

    def hyperlink(self):
        """Création des hyperliens dans le tableau détaillé"""
        try:
            valCell = self.tbl_service.selectedItems()[0].text()
            # définition de l'hyperlien sur les Roles-Users
            if self.tbl_service.currentColumn() == self.posRoleUser:
                if valCell == 'oui':
                    nom_service = self.tbl_service.item(self.tbl_service.currentRow(), 0).text()
                    dossier_service = self.tbl_service.item(self.tbl_service.currentRow(), 1).text()
                    id_service = nom_service + '|' + dossier_service
                    fenetreRole = FormRoleUser(id_service, self.dicoSw_Role)
                    fenetreRole.exec_()

            #définition de l'hyperlien sur le niveau de qualité
            elif self.tbl_service.currentColumn() == self.posQual:
                nom_service = self.tbl_service.item(self.tbl_service.currentRow(), 0).text()
                dossier_service = self.tbl_service.item(self.tbl_service.currentRow(), 1).text()
                id_service = nom_service + '|' + dossier_service
                index = self.tabledata['SW_NOM'].index(id_service)
                nivQual = self.tabledata['SW_QUALITE'][index]
                if nivQual != None:
                    fenetreListe = FormTree(id_service, nivQual, self.defQual ) # envoi service, liste
                    fenetreListe.exec_()
        except:
            pass

    def indicName(self):
        regles = {k:self.defQual[k] for k in self.defQual.keys() if self.defQual[k][0]==u'Services Web'}
        fenetreInd = FormIndicateur(regles)
        fenetreInd.exec_()

class FormDomaine(QDialog, Ui_FormDomaine):
    def __init__(self, nomDom, dicoDataDom):
        QDialog.__init__(self)
        self.setupUi(self)

        #Initialisation
        self.dirJson = Glob().dirJson

        #Chargement de la liste des domaines
        liste = sorted(list(set(dicoDataDom[str(nomDom)]))) #avec suppression doublon, triage
        self.lst_domaine.addItems(liste)
        self.lbl_domaine.setText(u'Nom des domaines associés à la donnée ' + str(nomDom))


        #lecture des données suivant les domaines
        js =open(self.dirJson + '\sde_dicoDom_Jeu.json')
        self.dicoDom_Jeu = json.load(js)
        js.close()


        #Définition des connecteurs
        self.connect(self.lst_domaine, SIGNAL("currentRowChanged(int)"), self.loadListData)
        self.connect(self.btn_quitter, SIGNAL("clicked()"), self, SLOT("close()"))


    def loadListData(self):
        self.lst_data.clear()
        domSelec = self.lst_domaine.currentItem().text()
        liste = sorted(list(set(self.dicoDom_Jeu[str(domSelec)])))  #avec suppression doublon, triage
        self.lst_data.addItems(liste)
        self.lbl_data.setText(u'Nom des données utilisant le domaine ' + str(domSelec))

class FormRoleUser(QDialog, Ui_FormRoleUser):
    def __init__(self, nomRole, dicoRoleUser):
        QDialog.__init__(self)
        self.setupUi(self)

        #Initialisation
        self.dirJson = Glob().dirJson

        #Chargement de la liste des rôles
        liste = sorted(list(set(dicoRoleUser[str(nomRole)]))) #avec suppression doublon, triage
        self.lst_role.addItems(liste)
        self.lbl_role.setText(u'Nom des rôles associés au service ' + str(nomRole))


        #lecture des utilisateurs suivant les rôles
        js =open(self.dirJson + '\service_dicoRole_User.json')
        self.dicoRole_User = json.load(js)
        js.close()


        #Définition des connecteurs
        self.connect(self.lst_role, SIGNAL("currentRowChanged(int)"), self.loadListUser)
        self.connect(self.btn_quitter, SIGNAL("clicked()"), self, SLOT("close()"))


    def loadListUser(self):
        self.lst_user.clear()
        roleSelec = self.lst_role.currentItem().text()
        liste = sorted(list(set(self.dicoRole_User[str(roleSelec)])))  #avec suppression doublon, triage
        self.lst_user.addItems(liste)
        self.lbl_user.setText(u'Nom des utilisateurs associés au rôle ' + str(roleSelec))

class FormListe(QDialog, Ui_FormListe):
    def __init__(self, nomJeu, liste, txt):
        QDialog.__init__(self)
        self.setupUi(self)

        #Chargement de la liste
        liste = sorted(liste)
        self.lst_liste.addItems(liste)
        self.txt_liste.setText(txt + str(nomJeu))

class FormIndicateur(QDialog, Ui_FormTree):
    def __init__(self, defQual):
        QDialog.__init__(self)
        self.setupUi(self)

        self.txt_liste.setText(u' ')
        view = self.lst_tree
        view.setSelectionBehavior(QAbstractItemView.SelectRows)
        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([u'Définition des niveaux de qualité :'])
        view.setModel(model)
        view.setUniformRowHeights(True)

        # Chargement infos
        parent3 = QStandardItem(u'Etat critique')
        parent2 = QStandardItem(u'Etat moyen')
        parent1 = QStandardItem(u'Etat convenable')

        for i in defQual.keys():
            if defQual[i][2] == 3:
                child = QStandardItem(defQual[i][1])
                parent3.appendRow([child])
            if defQual[i][2] == 2:
                child = QStandardItem(defQual[i][1])
                parent2.appendRow([child])
            if defQual[i][2] == 1:
                child = QStandardItem(defQual[i][1])
                parent1.appendRow([child])

        model.appendRow(parent3)
        view.setFirstColumnSpanned(1, view.rootIndex(), True)
        model.appendRow(parent2)
        view.setFirstColumnSpanned(2, view.rootIndex(), True)
        model.appendRow(parent1)
        view.setFirstColumnSpanned(3, view.rootIndex(), True)

        view.expandAll()


class FormTree(QDialog, Ui_FormTree):
    def __init__(self, id_jeu, nivQual, defQual):
        QDialog.__init__(self)
        self.setupUi(self)

        # init widgets
        self.txt_liste.setText(id_jeu)
        view = self.lst_tree
        view.setSelectionBehavior(QAbstractItemView.SelectRows)
        model = QStandardItemModel()
        model.setHorizontalHeaderLabels([u'Actions à réaliser :'])
        view.setModel(model)
        view.setUniformRowHeights(True)

        # Chargement infos
        parent3 = QStandardItem(u'Etat critique')
        parent2 = QStandardItem(u'Etat moyen')
        parent1 = QStandardItem(u'Etat convenable')
        p3,p2,p1 = 0,0,0
        for i in nivQual.split(','):
            if defQual[i][2] == 3:
                child = QStandardItem(defQual[i][1])
                parent3.appendRow([child])
                p3 = 1
            if defQual[i][2] == 2:
                child = QStandardItem(defQual[i][1])
                parent2.appendRow([child])
                p2 = 1
            if defQual[i][2] == 1:
                child = QStandardItem(defQual[i][1])
                parent1.appendRow([child])
                p1 = 1

        if p3 == 1:
            model.appendRow(parent3)
            view.setFirstColumnSpanned(1, view.rootIndex(), True)

        if p2 == 1:
            model.appendRow(parent2)
            view.setFirstColumnSpanned(2, view.rootIndex(), True)

        if p1 == 1:
            model.appendRow(parent1)
            view.setFirstColumnSpanned(3, view.rootIndex(), True)

        view.expandAll()


def main(args):
    a = QApplication(args)
    fenetre = FenPrincipale()
    fenetre.show()
    r = a.exec_()
    return r

if __name__ == "__main__":
    main(sys.argv)