# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form_domaine.ui'
#
# Created: Fri Aug 03 14:35:36 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_FormDomaine(object):
    def setupUi(self, FormDomaine):
        FormDomaine.setObjectName(_fromUtf8("FormDomaine"))
        FormDomaine.resize(400, 700)
        FormDomaine.setMinimumSize(QtCore.QSize(400, 700))
        self.verticalLayout = QtGui.QVBoxLayout(FormDomaine)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.lbl_domaine = QtGui.QLabel(FormDomaine)
        self.lbl_domaine.setObjectName(_fromUtf8("lbl_domaine"))
        self.verticalLayout.addWidget(self.lbl_domaine)
        self.lst_domaine = QtGui.QListWidget(FormDomaine)
        self.lst_domaine.setMaximumSize(QtCore.QSize(16777215, 200))
        self.lst_domaine.setObjectName(_fromUtf8("lst_domaine"))
        self.verticalLayout.addWidget(self.lst_domaine)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.verticalLayout.addItem(spacerItem)
        self.lbl_data = QtGui.QLabel(FormDomaine)
        self.lbl_data.setObjectName(_fromUtf8("lbl_data"))
        self.verticalLayout.addWidget(self.lbl_data)
        self.lst_data = QtGui.QListWidget(FormDomaine)
        self.lst_data.setObjectName(_fromUtf8("lst_data"))
        self.verticalLayout.addWidget(self.lst_data)
        self.btn_quitter = QtGui.QPushButton(FormDomaine)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.btn_quitter.sizePolicy().hasHeightForWidth())
        self.btn_quitter.setSizePolicy(sizePolicy)
        self.btn_quitter.setMaximumSize(QtCore.QSize(100, 16777215))
        self.btn_quitter.setObjectName(_fromUtf8("btn_quitter"))
        self.verticalLayout.addWidget(self.btn_quitter)

        self.retranslateUi(FormDomaine)
        QtCore.QMetaObject.connectSlotsByName(FormDomaine)

    def retranslateUi(self, FormDomaine):
        FormDomaine.setWindowTitle(_translate("FormDomaine", "Domaine", None))
        self.lbl_domaine.setText(_translate("FormDomaine", "Nom des domaines associés à la donnée...", None))
        self.lbl_data.setText(_translate("FormDomaine", "Nom des données utilisant le domaine...", None))
        self.btn_quitter.setText(_translate("FormDomaine", "Quitter", None))

