# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form_liste.ui'
#
# Created: Fri Aug 03 14:35:37 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_FormListe(object):
    def setupUi(self, FormListe):
        FormListe.setObjectName(_fromUtf8("FormListe"))
        FormListe.resize(400, 300)
        self.verticalLayout = QtGui.QVBoxLayout(FormListe)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.txt_liste = QtGui.QLabel(FormListe)
        self.txt_liste.setObjectName(_fromUtf8("txt_liste"))
        self.verticalLayout.addWidget(self.txt_liste)
        self.lst_liste = QtGui.QListWidget(FormListe)
        self.lst_liste.setObjectName(_fromUtf8("lst_liste"))
        self.verticalLayout.addWidget(self.lst_liste)

        self.retranslateUi(FormListe)
        QtCore.QMetaObject.connectSlotsByName(FormListe)

    def retranslateUi(self, FormListe):
        FormListe.setWindowTitle(_translate("FormListe", "Liste", None))
        self.txt_liste.setText(_translate("FormListe", "TextLabel", None))

