# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form_role_user.ui'
#
# Created: Fri Aug 03 14:35:38 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_FormRoleUser(object):
    def setupUi(self, FormRoleUser):
        FormRoleUser.setObjectName(_fromUtf8("FormRoleUser"))
        FormRoleUser.resize(400, 700)
        FormRoleUser.setMinimumSize(QtCore.QSize(400, 700))
        self.verticalLayout = QtGui.QVBoxLayout(FormRoleUser)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.lbl_role = QtGui.QLabel(FormRoleUser)
        self.lbl_role.setObjectName(_fromUtf8("lbl_role"))
        self.verticalLayout.addWidget(self.lbl_role)
        self.lst_role = QtGui.QListWidget(FormRoleUser)
        self.lst_role.setMaximumSize(QtCore.QSize(16777215, 200))
        self.lst_role.setObjectName(_fromUtf8("lst_role"))
        self.verticalLayout.addWidget(self.lst_role)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.verticalLayout.addItem(spacerItem)
        self.lbl_user = QtGui.QLabel(FormRoleUser)
        self.lbl_user.setObjectName(_fromUtf8("lbl_user"))
        self.verticalLayout.addWidget(self.lbl_user)
        self.lst_user = QtGui.QListWidget(FormRoleUser)
        self.lst_user.setObjectName(_fromUtf8("lst_user"))
        self.verticalLayout.addWidget(self.lst_user)
        self.btn_quitter = QtGui.QPushButton(FormRoleUser)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.btn_quitter.sizePolicy().hasHeightForWidth())
        self.btn_quitter.setSizePolicy(sizePolicy)
        self.btn_quitter.setMaximumSize(QtCore.QSize(100, 16777215))
        self.btn_quitter.setObjectName(_fromUtf8("btn_quitter"))
        self.verticalLayout.addWidget(self.btn_quitter)

        self.retranslateUi(FormRoleUser)
        QtCore.QMetaObject.connectSlotsByName(FormRoleUser)

    def retranslateUi(self, FormRoleUser):
        FormRoleUser.setWindowTitle(_translate("FormRoleUser", "Rôles et Utilisateurs", None))
        self.lbl_role.setText(_translate("FormRoleUser", "Nom des rôles associés au service...", None))
        self.lbl_user.setText(_translate("FormRoleUser", "Nom des utilisateurs associés au rôle...", None))
        self.btn_quitter.setText(_translate("FormRoleUser", "Quitter", None))

