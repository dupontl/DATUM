# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'form_tree.ui'
#
# Created: Fri Aug 03 14:35:40 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_FormTree(object):
    def setupUi(self, FormTree):
        FormTree.setObjectName(_fromUtf8("FormTree"))
        FormTree.resize(400, 300)
        self.verticalLayout = QtGui.QVBoxLayout(FormTree)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.txt_liste = QtGui.QLabel(FormTree)
        self.txt_liste.setObjectName(_fromUtf8("txt_liste"))
        self.verticalLayout.addWidget(self.txt_liste)
        self.lst_tree = QtGui.QTreeView(FormTree)
        self.lst_tree.setObjectName(_fromUtf8("lst_tree"))
        self.verticalLayout.addWidget(self.lst_tree)

        self.retranslateUi(FormTree)
        QtCore.QMetaObject.connectSlotsByName(FormTree)

    def retranslateUi(self, FormTree):
        FormTree.setWindowTitle(_translate("FormTree", "Niveau de qualité", None))
        self.txt_liste.setText(_translate("FormTree", "TextLabel", None))

