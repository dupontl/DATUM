#-*- coding: utf-8 -*-
#!/usr/bin/env python

#Paramètres
from PyQt4 import QtCore, QtGui
import os

pathBad = os.path.dirname(os.path.abspath(__file__))  + '/nivBad.png'
pathMid = os.path.dirname(os.path.abspath(__file__))  + '/nivMid.png'
pathSat = os.path.dirname(os.path.abspath(__file__))  + '/nivSat.png'
pathGood = os.path.dirname(os.path.abspath(__file__)) + '/nivGood.png'
pathDown = os.path.dirname(os.path.abspath(__file__)) + '/fleche_bas.png'
pathUp = os.path.dirname(os.path.abspath(__file__)) + '/fleche_haut.png'



class IcoBad(QtGui.QLabel):
    def __init__(self, parent=None):
        super(IcoBad, self).__init__(parent)
        pic = QtGui.QPixmap(pathBad)
        pic.scaled(1, 1, QtCore.Qt.KeepAspectRatio)
        self.setPixmap(pic)

class IcoMid(QtGui.QLabel):
    def __init__(self, parent=None):
        super(IcoMid, self).__init__(parent)
        pic = QtGui.QPixmap(pathMid)
        self.setPixmap(pic)

class IcoSat(QtGui.QLabel):
    def __init__(self, parent=None):
        super(IcoSat, self).__init__(parent)
        pic = QtGui.QPixmap(pathSat)
        self.setPixmap(pic)

class IcoGood(QtGui.QLabel):
    def __init__(self, parent=None):
        super(IcoGood, self).__init__(parent)
        pic = QtGui.QPixmap(pathGood)
        self.setPixmap(pic)

class IcoDown(QtGui.QLabel):
    def __init__(self, parent=None):
        super(IcoDown, self).__init__(parent)
        pic = QtGui.QPixmap(pathDown)
        self.setPixmap(pic)

class IcoUp(QtGui.QLabel):
    def __init__(self, parent=None):
        super(IcoUp, self).__init__(parent)
        pic = QtGui.QPixmap(pathUp)
        self.setPixmap(pic)

