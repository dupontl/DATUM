#-*- coding: utf-8 -*-
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         mailing.py
# Objectif:    Composition de mail avec .txt de référence (corps) associé aux
#              rapports des référents (pièce-jointe) au format .xls
#
# Auteur:      Anthony Vergne / Université de La Rochelle - LUPSIG
#
# Création:    17/08/2018
# Développement python / arcpy
#-------------------------------------------------------------------------------

import smtplib
import codecs
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders

from param_scan import *

dirJson = Glob().dirJson
msgMail = Glob().msgMail
envoi_mails = Glob().envoi_mails
archive = Glob().dirArchive

s1 = datetime.now()

try:
    # Récupération mail+contact:
    js = open(dirJson + '//contact_mail.json')
    dicoContact = json.load(js)
    js.close

    # Création du dossier d'archivage daté:
    envoi_mails_archive = archive + '/' + datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + '_envoyes'
    if not os.path.exists(envoi_mails_archive):
        os.makedirs(envoi_mails_archive)

    #Production et envoi des mails:
    listFic = os.listdir(envoi_mails)

    for key in sorted(dicoContact.keys()):

        if isinstance(listFic, list):
            for fic in listFic:
                if fic[-3:] == 'xls':
                    contact = fic.split('_')[1]
                    if contact == dicoContact[key][0]:
                        rapport = fic

                        sujet = u"Rapport sur vos données SIG"
                        mail_from = u'laurent.dupont@brest-metropole.fr'
                        mail_to = dicoContact[key][1] # Récupération mail OK

                        msg = MIMEMultipart()
                        msg['From'] = mail_from
                        msg['To'] = mail_to
                        msg['Date'] = formatdate(localtime=True)
                        msg['Subject'] = sujet

                        msgFic = codecs.open(msgMail).read()
                        msgFic.decode("latin-1")
                        # encoding='utf-8')
                        msg.attach(MIMEText(msgFic, _charset = "latin-1"))
                        # msgFic.close()

                        part = MIMEBase('application', "octet-stream")
                        part.set_payload(open(envoi_mails+'/'+rapport, "rb").read())
                        Encoders.encode_base64(part)
                        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(rapport))
                        msg.attach(part)

                        smtp = smtplib.SMTP('fwmailsrv.dit.cb', 25)
                        smtp.ehlo()
                        smtp.starttls()
                        smtp.ehlo()
                        smtp.sendmail(mail_from, mail_to, msg.as_string())
                        smtp.quit()
                        print(u'Le mail a bien été envoyé a ' + contact)

                    # Archivage du rapport envoyé
                        shutil.copyfile(envoi_mails+'/'+fic, envoi_mails_archive+'/'+fic)

    # Archivage du sous-dossier 'exclus' et copie du .txt du mail:
    exclus = envoi_mails + '/Exclus'
    exclus_archive = envoi_mails_archive + '/Exclus'

    if os.path.isdir(exclus):
        shutil.copytree(exclus, exclus_archive, symlinks=False, ignore=None)

    if os.path.isdir(envoi_mails_archive):
        shutil.copyfile(msgMail, envoi_mails_archive+'/mail_referents.txt')

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree / 60)
    seconde = int(duree - minute * 60)
    log.info(u'traitement réussi (' + str(minute) + 'min ' + str(seconde) + 's)')

    input(u'Appuyez sur \'ENTREE\' pour quitter')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass