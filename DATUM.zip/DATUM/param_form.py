#-*-coding: utf-8 -*-

#Importation des modules
import os
import sys
import json
import webbrowser
from datetime import datetime

#déclaration des chemins d'accès pour les fichiers python
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/form')
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/icons')

#Chargement des modules PyQt et Sip
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + "/modules")
import sip

#Fichiers de l'interface de DATUM
from form_accueil import *
from form_liste import *
from form_domaine import *
from form_sde import *
from form_meta import *
from form_lyr import *
from form_service import *
from form_role_user import *
from form_tree import *
from icone import *

from PyQt4.QtCore import *
from PyQt4.QtGui import *

#Importation du module matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
##from matplotlib.figure import Figure

class Glob():
    """"Espace de noms pour les variables et fonctions <pseudo-globales>"""
    #Accès aux fichiers Json
    dirJson = os.path.dirname(os.path.abspath(__file__)) + '/json'






