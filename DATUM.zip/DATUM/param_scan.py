#-*-coding: utf-8 -*-

# pour épingler dans 'Accès rapide' : coller le chemin dans barre de recherche de l'explorateur windows et appuyer sur 'entrée'
# clic droit sur 'Accès rapide' > 'épingler le dossier actuel à 'Accès rapide'

#---------------IMPORTATION DES MODULES-----------------------------------------------------

import os
import sys
import arcpy
import logging
import re
import json
import xml.etree.ElementTree as ET
import webbrowser
import traceback
import urllib2
import shutil #pour copier fichier
import xlrd #lire fichier excel
from xlwt import Workbook, easyxf #écrire fichier excel
from datetime import datetime, timedelta

#déclaration des chemins d'accès pour les fichiers python
sys.path.append(os.path.dirname(os.path.abspath(__file__)) + '/scan')


#---------------DEFINITION DES VARIABLES GLOBALES--------------------------------------------
class Glob():
    def __init__(self):
        # Variable pour l'alerte sur le délai de mise à jour des données en màj 'continue'
        self.delai_maj_str = '30'

        #Accès aux fichiers Json
        self.dirJson = os.path.dirname(os.path.abspath(__file__)) + '/json'

        # Accès aux icônes d'alerte:
        self.dirIcons = os.path.dirname(os.path.abspath(__file__)) + '/icons'

        #Bases ArcSDE
        self.connexSDE = r'H:\etu\Base sde\Connexions_bases'
        self.baseSDEqualif= r'H:\etu\sde\Connexions_bases\SIG_qualif_SIG.sde'
        self.baseSDEprod  = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde'
        self.baseDSIT = r'H:\Scripts\Python\TableauBord_v2\Bases_DSIT.sde'

        #Tables DSIT
        self.tableDSITMeta = r'H:\Scripts\Python\TableauBord_v2\Bases_DSIT.sde\UDU.MYB72'
        self.tableDSITVign = r'H:\Scripts\Python\TableauBord_v2\Bases_DSIT.sde\UDU.MYB81'

        #Table de gestion des vues
        self.ZZZ_VUES_SDE = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_VUES_SDE'

        #Tables de DATUM
        self.ZZZ_TDB_tablesde = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\ZZZ_TDB_tablesde'
        self.ZZZ_TDB_metadonnees = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\ZZZ_TDB_metadonnees'
        self.ZZZ_TDB_tabledomaine = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\ZZZ_TDB_tabledomaine'
        self.ZZZ_TDB_domaine =  r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\ZZZ_TDB_domaine'
        self.ZZZ_TDB_defvues = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_TDB_DEFVUES'
        self.ZZZ_TDB_archive = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_TDB_archive'
        self.ZZZ_TDB_fichierlyr = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_TDB_fichierlyr'
        self.ZZZ_TDB_serviceweb = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_TDB_serviceweb'
        self.ZZZ_TDB_couche = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_TDB_couche'
        self.ZZZ_TDB_coucheservice = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_TDB_coucheservice'
        self.ZZZ_TDB_user_role = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_TDB_user_role'
        self.ZZZ_TDB_roleservice = r'H:\etu\sde\Connexions_bases\SIG_prod_SIG.sde\SIG.ZZZ_TDB_roleservice'

        #Exportation des tables DATUM vers fichiers XLS
        self.exportXls = r'H:\Outils\DATUM\export.xls'

        #Dossier d'archivage des dossiers de rapports xls individualisés et rapports + txt envoyés:
        self.dirRapports = os.path.dirname(os.path.realpath(__file__)) + '/../rapports_referents'
        self.dirArchive = os.path.dirname(os.path.abspath(__file__)) + '/../rapports_referents'

        #Dossier de stockage des rapports à envoyer
        self.envoi_mails = os.path.dirname(os.path.abspath(__file__)) + '/envoi_mails'

        #Niveaux de qualité des données pour les référents
        self.NivQualData = os.path.dirname(os.path.abspath(__file__)) + '/data/Niveaux_qualite_donnees.xlsx'

        #Corps de l'e-mail envoyé avec les rapports individualisés
        self.msgMail = os.path.dirname(os.path.abspath(__file__)) + '/data/mail_referents.txt'

        # Vers l'Intranet de Brest Métropole
        self.Nomenclature = r'\\espcol001.brest-metropole-oceane.fr@SSL\DavWWWRoot\sites\WSS00230\SIG_interne\SIGtech\Documents partages\Nomenclature PaysdeBrest.xlsx'  # à épingler dans 'Accès rapide'

        # Niveaux de qualité
        self.NivQual = os.path.dirname(os.path.abspath(__file__)) + '/data/Niveaux_qualite.xlsx'

        # Chemin d'accès aux services web et aux rôles // utilisateurs par réseau interne
        self.dirServices = r'\\hcu234.dit.cb\v235\arcgisserver\config-store\services'
        self.dirRoles = r'\\hcu234.dit.cb\v235\arcgisserver\config-store\security'


#---------------GESTION DES ERREURS SUR LES SCANS-------------------------------------------

#définition des loggers
def setup_logger(logger_name, log_file, formatter, level=logging.DEBUG):
    l = logging.getLogger(logger_name)
    fileHandler = logging.FileHandler(log_file, mode='w')
    fileHandler.setFormatter(formatter)
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)

    l.setLevel(level)
    l.addHandler(fileHandler)
    l.addHandler(streamHandler)


#fichier log avec chemin relatif
fic_log =  os.path.dirname(os.path.abspath(__file__)) + '/scan.log'
fic_deb =  os.path.dirname(os.path.abspath(__file__)) + '/scan_debug.log'

#formatage du texte
formatter = logging.Formatter('%(asctime)s :: %(filename)s :: %(levelname)s :: %(message)s')
setup_logger('log', fic_log, formatter)
formatter = logging.Formatter('%(message)s')
setup_logger('debug', fic_deb, formatter)

#création des 2 loggers
log = logging.getLogger('log')
debug = logging.getLogger('debug')

#Déf. écriture dans log et debug en cas de plantage du scan
def writeLogs():
    exc_type, exc_value, exc_traceback = sys.exc_info()
    debug.critical(repr(traceback.format_exception(exc_type, exc_value,
                                                   exc_traceback))) #dans debug






