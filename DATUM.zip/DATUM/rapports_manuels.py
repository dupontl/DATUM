#-*- coding: utf-8 -*-
#!/usr/bin/env python
from __future__ import absolute_import, print_function, unicode_literals

#-------------------------------------------------------------------------------
# Nom:         rapports_manuels.py
# Objectif:    Lancement manuel de création des rapports par référent sur les
#              alertes en cours des jeux de données et des fiches de métadonnées.
#              Récupération des titres de chaque jeu de données par référent
#              pour produire un résumé personnalisé.
#
# Auteur:      Anthony Vergne / Université de La Rochelle - LUPSIG
#
# Création:    17/08/2018
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

JeuxSDE = Glob().ZZZ_TDB_tablesde
baseSDE = Glob().baseSDEprod
dirJson = Glob().dirJson
nivQualData = Glob().NivQualData
icons = Glob().dirIcons
dirRapports = Glob().dirArchive
envoi_mails = Glob().envoi_mails

try:
    s1 = datetime.now()

    #Création des dossiers de rapports datés par type de référent:
    rapportsBM = dirRapports + '/'+datetime.now().strftime("%Y-%m-%d_%H-%M-%S")+'_BM'
    if not os.path.exists(rapportsBM):
        os.makedirs(rapportsBM)
    rapportsSIG = dirRapports + '/'+datetime.now().strftime("%Y-%m-%d_%H-%M-%S")+'_SIG'
    if not os.path.exists(rapportsSIG):
        os.makedirs(rapportsSIG)
    rapportsExt = dirRapports + '/'+datetime.now().strftime("%Y-%m-%d_%H-%M-%S")+'_Exterieurs'
    if not os.path.exists(rapportsExt):
        os.makedirs(rapportsExt)
    rapportsInc = dirRapports + '/' + datetime.now().strftime("%Y-%m-%d_%H-%M-%S") + '_Inconnus'
    if not os.path.exists(rapportsInc):
        os.makedirs(rapportsInc)

    # Création de variables, récupération de "Niveaux_qualite_donnees.xlsx"
    dicoNivQualData = {}
    dicoEvent = {}
    dicoInfo = {}
    classeur = xlrd.open_workbook(nivQualData)
    nom_des_feuille = classeur.sheet_names()
    feuille = classeur.sheet_by_name(nom_des_feuille[0])

    for l in range (feuille.nrows):
        dicoNivQualData[feuille.cell_value(l, 0)] = [feuille.cell_value(l, 1), feuille.cell_value(l, 2),
                                                    feuille.cell_value(l, 3),  feuille.cell_value(l, 4),
                                                    feuille.cell_value(l, 5)]

    #Connexion à la base de données ArcSDE
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

    #Infos sur la qualité des jeux de données
    rows = arcpy.SearchCursor(JeuxSDE)
    for row in rows:
        sql = "SELECT TAB_NOM, META_TITRE, TAB_CONTACT, TAB_QUALITE, META_MAJ_FREQ,to_char((META_JEUDATEMODIF), \
         'YYYY/MM/DD'), to_date(META_MAJ_FICHE, 'YYYY-MM'), META_CHPVIDE, META_EMAIL FROM SIG.ZZZ_TDB_tablesde, \
          SIG.ZZZ_TDB_metadonnees WHERE TAB_META_ID=META_PKB72 AND TAB_NOM='{}'".format(row.getValue('TAB_NOM'))

        listInfo = egdb_conn.execute(sql)

        if isinstance(listInfo, __builtins__.list):
            if listInfo[0][2] != None:
                # sup. chr pour éviter plantage dans nom fichier
                list_sc = ['/', '\\', '*', '?', '"', '>', '>', '|']
                accents = {'a': [u'à', u'ã', u'á', u'â'],
                           'e': [u'é', u'è', u'ê', u'ë'],
                           'i': [u'î', u'ï'],
                           'u': [u'ù', u'ü', u'û'],
                           'o': [u'ô', u'ö'],
                           'c': [u'ç']}
                nomContact = ''.join([i if i not in list_sc else '' for i in listInfo[0][2]])
                for (char, accented_chars) in accents.iteritems():
                    for accented_char in accented_chars:
                        nomContact = nomContact.replace(accented_char, char)
                i = 0
            if listInfo[0][3] != None:
                regles = []
                regles = listInfo[0][3].split(',')
                for regle in regles:
                    if regle in dicoNivQualData.keys():
                        dicoEvent[row.getValue('TAB_NOM') + '|' + regle] = \
                            (nomContact, listInfo[0][1], dicoNivQualData[regle][0]+' - '+dicoNivQualData[regle][1],
                             dicoNivQualData[regle][2], dicoNivQualData[regle][3], dicoNivQualData[regle][4],
                             listInfo[0][4], listInfo[0][5], listInfo[0][6], listInfo[0][7], listInfo[0][8])
                    else:
                        dicoInfo[row.getValue('TAB_NOM')+'|'+ 'JD'] = \
                            (nomContact, listInfo[0][1], listInfo[0][8], u"Jeu de données")
            else:
                dicoInfo[row.getValue('TAB_NOM') +'|'+ 'JD'] = \
                    (nomContact, listInfo[0][1], listInfo[0][8], u"Jeu de données")

    del row, rows

    # Infos sur la qualité des métadonnées
    rows = arcpy.SearchCursor(JeuxSDE)
    for row in rows:
        sql = "SELECT TAB_NOM, META_TITRE, TAB_CONTACT, META_QUALITE, META_MAJ_FREQ, to_char((META_JEUDATEMODIF),\
         'YYYY/MM/DD'), META_MAJ_FICHE, META_CHPVIDE, META_EMAIL FROM SIG.ZZZ_TDB_tablesde, SIG.ZZZ_TDB_metadonnees \
         WHERE TAB_META_ID=META_PKB72 AND TAB_NOM='{}'".format(row.getValue('TAB_NOM'))

        listInfo = egdb_conn.execute(sql)

        if isinstance(listInfo, __builtins__.list):
            for info in listInfo:
                if info[2] != None:
                    # sup. chr pour éviter plantage dans nom fichier
                    list_sc = ['/', '\\', '*', '?', '"', '>', '>', '|']
                    accents = {'a': [u'à', u'ã', u'á', u'â'],
                               'e': [u'é', u'è', u'ê', u'ë'],
                               'i': [u'î', u'ï'],
                               'u': [u'ù', u'ü', u'û'],
                               'o': [u'ô', u'ö'],
                               'c': [u'ç']}
                    nomContact = ''.join([i if i not in list_sc else '' for i in info[2]])  # nom contact nettoyé
                    for (char, accented_chars) in accents.iteritems():
                        for accented_char in accented_chars:
                            nomContact = nomContact.replace(accented_char, char)
                    i = 0
                if info[3] != None:
                    regle = []
                    regles = info[3].split(',')
                    for regle in regles:
                        if regle in dicoNivQualData.keys():
                            dicoEvent[row.getValue('TAB_NOM') + '|' + regle] = \
                                (nomContact, info[1], dicoNivQualData[regle][0]+' - '+dicoNivQualData[regle][1],
                                dicoNivQualData[regle][2], dicoNivQualData[regle][3], dicoNivQualData[regle][4],
                                 info[4], info[5], info[6], info[7], info[8])
                        else:
                            dicoInfo[row.getValue('TAB_NOM') + '|' + 'MD'] = (nomContact, info[1], info[8], u"Métadonnées")
                else:
                    dicoInfo[row.getValue('TAB_NOM') + '|' + 'MD'] = (nomContact, info[1], info[8], u"Métadonnées")

    del row, rows

    # Suppression de clés 'MD' dans dicoInfo si présentes dans dicoEvent:
    clesDoubles = list()
    for key in dicoEvent.keys():
        if key.split('|')[1] in dicoNivQualData.keys():
            for cle in dicoInfo.keys():
                if dicoInfo[cle][1] == dicoEvent[key][1] and cle.split('|')[1] != 'JD':
                    clesDoubles.append(cle)
    for cle in clesDoubles:
        if cle in dicoInfo:
            del dicoInfo[cle]

    # Création d'un dictionnaire contact//mail pour script 'mailing.py'
    listContact = []

    for key in dicoEvent.keys(): # création liste contact
        if dicoEvent[key][0] != None:
            listContact.append(dicoEvent[key][0])
    listContact =  __builtins__.list(set(listContact)) # sup. doublon contact

    dicoContact = {}
    for key in dicoEvent.keys():
        dicoContact[dicoEvent[key][0]] = (dicoEvent[key][0], dicoEvent[key][10])

    # Création du rapport par contact dans dossiers d'archivage
    for contact in listContact:
        if contact != None:

            # Mise en page
            classeur = Workbook()
            feuilleAlerte = classeur.add_sheet('Alertes')
            feuilleSati = classeur.add_sheet('Satisfaisantes')

                # Feuille 1 / Alertes
            style = easyxf('pattern: pattern solid, fore_color dark_green;' 'font: colour white, bold True, height 280;'
                           'align: horiz left;')
            texte = u'Rapport sur vos données SIG du ' + datetime.now().strftime("%d/%m/%Y")
            feuilleAlerte.write_merge(0, 0, 0, 2, texte , style)
            texte = u'Liste de vos données à améliorer'
            feuilleAlerte.write_merge(0, 0, 3, 6, texte , style)

            style = easyxf('pattern: pattern solid, fore_color dark_green;' 'font: colour white, italic True, \
            height 280;' 'align: horiz center;')
            texte = u'La liste de vos données satisfaisantes est consultable en feuille 2'
            feuilleAlerte.write_merge(1, 1, 0, 6, texte , style)

            style = easyxf('pattern: pattern solid, fore_color sea_green;' 'font: colour white, bold True, height 200;'
                           'align: horiz center;' 'border: left thin, right thin, top thin, bottom thin, left_color '
                           'light_green, right_color light_green, top_color light_green, bottom_color light_green;')

            feuilleAlerte.write(2, 0, u'Titre du jeu de données', style)
            feuilleAlerte.write(2, 1, u'Action', style)
            feuilleAlerte.write(2, 2, u'Description de l\'anomalie', style)
            feuilleAlerte.write(2, 3, u'Niveau d\'alerte', style)
            feuilleAlerte.write(2, 4, u'Explication méthode', style)
            feuilleAlerte.write(2, 5, u'Informations complémentaires', style)
            feuilleAlerte.write(2, 6, u'Nom du jeu de données', style)

            col = feuilleAlerte.col(0); col.width = 10000
            col = feuilleAlerte.col(1); col.width = 8000
            col = feuilleAlerte.col(2); col.width = 10000
            col = feuilleAlerte.col(3); col.width = 4000
            col = feuilleAlerte.col(4); col.width = 18000
            col = feuilleAlerte.col(5); col.width = 8500
            col = feuilleAlerte.col(6); col.width = 10000

                # Feuille 2 / Satisfaisantes
            style = easyxf('pattern: pattern solid, fore_color dark_green;' 'font: colour white, bold True, height 280;'
                           'align: horiz center;')
            texte = 'Résumé de l\'ensemble de vos données satisfaisantes au ' + datetime.now().strftime("%d/%m/%Y")
            feuilleSati.write_merge(0, 0, 0, 5, texte, style)

            style = easyxf('pattern: pattern solid, fore_color sea_green;' 'font: colour white, bold True, height 200;'
                           'align: horiz center;' 'border: left thin, right thin, top thin, bottom thin, left_color '
                           'light_green, right_color light_green, top_color light_green, bottom_color light_green;')

            feuilleSati.write_merge(1, 1, 0, 1, u'Titre du jeu de données', style)
            feuilleSati.write_merge(1, 1, 2, 4, u'Partie concernée', style)
            feuilleSati.write(1,5, u'', style)

            col = feuilleSati.col(0); col.width = 10000
            col = feuilleSati.col(1); col.width = 5000
            col = feuilleSati.col(2); col.width = 500
            # Fin mise en page

            # Init création de rapport
            rowF1 = 3
            rowF2 = 2
            style = easyxf('font: name Century Gothic;' 'align: horiz left, vert center, wrap True;'
                           'border: left thin, right thin, top thin, bottom thin;')
            styleBold = easyxf('font: name Century Gothic, bold True;' 'align: horiz left, vert center, wrap True;'
                            'border: left thin, right thin, top thin, bottom thin;')

                # Liste des données 'satisfaisantes' pour Feuille 2 :
            for cle in sorted(dicoInfo.keys()):
                if dicoInfo[cle][0] == contact:
                    if dicoInfo[cle][1] not in dicoEvent.values():
                        feuilleSati.write_merge(rowF2, rowF2, 0, 1, dicoInfo[cle][1], styleBold)
                        feuilleSati.write_merge(rowF2, rowF2, 2, 4, dicoInfo[cle][3], style)
                        feuilleSati.insert_bitmap(icons + '/niv0.bmp', rowF2, 5, 25, 0, 1, 1)
                        feuilleSati.write(rowF2, 5, u'', style)
                        rowF2 += 1


                # Listes des données avec alertes pour Feuille 1 :
            for key in sorted(dicoEvent.keys()):
                if dicoEvent[key][0] == contact:

                # Informations pour Alertes / feuille 1
                    feuilleAlerte.write(rowF1, 0, dicoEvent[key][1], styleBold)
                    feuilleAlerte.write(rowF1, 1, dicoEvent[key][2], styleBold)
                    feuilleAlerte.write(rowF1, 2, dicoEvent[key][3], style)
                    feuilleAlerte.write(rowF1, 3, dicoEvent[key][4], style)

                    # Application des images .bmp correspondantes aux niveaux d'alerte
                    if dicoEvent[key][4] == 1:
                        feuilleAlerte.insert_bitmap(icons+'/niv1.bmp', rowF1, 3, 50, 5, 1.5, 0.5)
                    elif dicoEvent[key][4] == 2:
                        feuilleAlerte.insert_bitmap(icons+'/niv2.bmp', rowF1, 3, 50, 5, 1.5, 0.5)
                    else:
                        feuilleAlerte.insert_bitmap(icons+'/niv3.bmp', rowF1, 3, 50, 5, 1.5, 0.5)

                    feuilleAlerte.write(rowF1, 4, dicoEvent[key][5], style)

                    # Ajout d'informations complémentaires :
                    if key.split('|')[1] == 'J07':
                        infos = u'Fréquence de mise à jour :\n', dicoEvent[key][6],\
                        u'\nDate de dernière modification :\n', dicoEvent[key][7]
                        feuilleAlerte.write(rowF1, 5, infos, style)
                    elif key.split('|')[1] == 'M02':
                        infos = u'Champs obligatoires manquants :\n', dicoEvent[key][9]
                        feuilleAlerte.write(rowF1, 5, infos, style)
                    elif key.split('|')[1] == 'M03':
                        if dicoEvent[key][8] != None:
                            infos = u'Date de dernière intervention :\n', dicoEvent[key][7], \
                            u'\nDate dans Fiche Métadonnées :\n', dicoEvent[key][8][0:4]+'-'+dicoEvent[key][8][4:6]
                        else:
                            infos = u'Date de dernière intervention :\n', dicoEvent[key][7], \
                                    u'\nDate dans Fiche Métadonnées :\nAbsente',
                        feuilleAlerte.write(rowF1, 5, infos, style)
                    elif key.split('|')[1] == 'M13':
                        if dicoEvent[key][6] != None:
                            infos = u'Fréquence de mise à jour :\n', dicoEvent[key][6]
                        else:
                            infos = u'Fréquence de mise à jour :\nAbsente'
                        feuilleAlerte.write(rowF1, 5, infos, style)
                    elif dicoEvent[key][10] == None:
                        infos = u"Absence d'adresse e-mail"
                        feuilleAlerte.write(rowF1, 5, infos, style)

                    feuilleAlerte.write(rowF1, 6, key.split('|')[0], style)

                    rowF1 += 1

                # Répartition dans dossiers selon e-mail contact:
                    if dicoEvent[key][10] != None:
                        mail = dicoEvent[key][10]
                        if "@" in mail: # On exclut les adresses non conformes
                            if(mail == 'sig@brest-metropole.fr' or mail == 'sig@pays-de-brest.fr'):
                                nomRapport = rapportsSIG + '\\RapportSIG_' + contact + '_' + datetime.now().strftime\
                                        ("%Y-%m-%d") + '.xls'
                            elif(mail.split('@')[0] != 'sig' and mail.split('@')[1] == 'brest-metropole.fr'
                                 or mail.split('@')[1] == 'mairie-brest.fr'):
                                nomRapport = rapportsBM + '\\RapportSIG_' + contact + '_' + datetime.now().strftime\
                                        ("%Y-%m-%d") + '.xls'
                                # Ajout contact//mail pour JSON
                                dicoContact[contact] = (contact, dicoEvent[key][10])
                            else:
                                nomRapport = rapportsExt + '\\RapportSIG_' + contact + '_' + datetime.now().strftime\
                                        ("%Y-%m-%d") + '.xls'
                        else:
                            nomRapport = rapportsExt + '\\RapportSIG_' + contact + '_' + datetime.now().strftime\
                                    ("%Y-%m-%d") + '.xls'
                    else:
                        nomRapport = rapportsInc + '\\RapportSIG_' + contact + '_' + datetime.now().strftime\
                                ("%Y-%m-%d") + '.xls'

                    classeur.save(nomRapport)
            del classeur
            # Fin création de rapport

    # Copie des rapports BM dans dossier de rapports à envoyer par script 'mailing.py'
        #Suppression du dossier si déjà existant
    if os.path.exists(envoi_mails):
        shutil.rmtree(envoi_mails)

        #Création par copie de l'arborescence et de son contenu
    source = rapportsBM
    destination = envoi_mails

    if os.path.isdir(rapportsBM):
        shutil.copytree(rapportsBM, envoi_mails)
        os.makedirs(envoi_mails + '/Exclus')

    # Export JSON du dicoContact
    with open(dirJson + '\\contact_mail.json', 'w') as outfile:
        json.dump(dicoContact, outfile)
        outfile.close

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree / 60)
    seconde = int(duree - minute * 60)
    log.info(u'traitement réussi (' + str(minute) + 'min ' + str(seconde) + 's)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass