#-*- coding: utf-8 -*-
#!/usr/bin/env python

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from param_scan import *

# TEST SUR LES VARIABLES DE PARAM_SCAN
def testSDE(table):
    try:
        rows = arcpy.SearchCursor(table)
        del rows
        return True
    except:
        return False

def testBase(base):
    try:
        egdb_conn = arcpy.ArcSDESQLExecute(base)
        return True
    except:
        return False

dicoVar = vars(Glob()) #dictionnaire sur les variables de la class Glob
start = True
pbVar = []
for var in dicoVar.keys():
    if var[0:2] != '__':
        if os.path.isdir(dicoVar[var]) != True: #test si dossier existe
            if os.path.isfile(dicoVar[var]) != True: #test si fichier existe
                if testSDE(dicoVar[var]) != True:#test si table SDE existe
                    if testBase(dicoVar[var]) != True: #test si base SDE existe
                        if not dicoVar[var].isalnum():
                            pbVar.append(dicoVar[var])
                            start = False

# FIN DE TEST SUR LES VARIABLES : si start = False (pas de scan)

if start == True:
    #Temps scan
    s1 = datetime.now()

    #Chemin d'accès du répertoire des scans
    dirScanPy = os.path.dirname(os.path.abspath(__file__)) + '/scan/'
    listFicPy = os.listdir(dirScanPy)

    #Exécution des scripts
    for ficPy in listFicPy:
        if ficPy[-2:] == 'py':
            filePy = dirScanPy + ficPy
            execfile(filePy)

else: #start = False ---> écriture dans log
    log.critical(u"Problème d'accès aux variables du fichier 'param_scan', aucun scan lancé le " + datetime.now().strftime('%d-%m-%Y'))
    for nom in pbVar:
        log.info(u"Variable non accessible : {}".format(nom))


#PARTIE ENVOI MAIL
mail_from = 'sig@brest-metropole.fr'
mail_to = 'laurent.dupont@brest-metropole.fr'
# mail_to = 'anthony.vergne@brest-metropole.fr'

msg = MIMEMultipart()
msg['From'] = mail_from
msg['To'] = mail_to

fic = open(fic_log, 'r')
lignes  = fic.readlines()
fic.close()

listInfo = []
message = ''
for ligne in lignes:
    listInfo.append(ligne.split(' :: ')[2])
    message = message + unicode(ligne, "utf-8")

dicoNiv = {k: listInfo.count(k) for k in listInfo}

if 'CRITICAL' not in dicoNiv.keys():
    dicoNiv['CRITICAL'] = 0

if 'WARNING' not in dicoNiv.keys():
    dicoNiv['WARNING'] = 0

if 'INFO' not in dicoNiv.keys():
    success = 0
else:
    if dicoNiv['INFO'] - len(listFicPy) == 0:
        success ='Tous'
    else:
        success = str(dicoNiv['INFO'] - len(listFicPy))

if start == True:
    sujetTxt = 'DATUM SCAN du ' + datetime.now().strftime('%d-%m-%Y') + u' : Réussi(' + str(success) \
                + '), Plantage(' + str(dicoNiv['CRITICAL']) + '), Vigilance(' + str(dicoNiv['WARNING']) + ')'
else:
    sujetTxt = 'DATUM SCAN du ' + datetime.now().strftime('%d-%m-%Y') + u' : Aucun scan lancé'

msg['Subject'] = sujetTxt

msg.attach(MIMEText(message, _charset = "utf-8"))

mailserver = smtplib.SMTP('fwmailsrv.dit.cb', 25)
mailserver.ehlo()
mailserver.starttls()
mailserver.ehlo()
mailserver.sendmail(mail_from, mail_to, msg.as_string())
mailserver.quit()

#FIN MAIL

print "Fin exe"
##sys.exit()

