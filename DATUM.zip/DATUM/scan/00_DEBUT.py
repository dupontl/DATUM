#-*- coding: utf-8 -*-
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         00_DEBUT.py
# Objectif:    Copie des fichiers Json pour connaître l'évolution journalière
#              des niveaux de qualité
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

from param_scan import *

try:
#Temps scan
    s1 = datetime.now()

    shutil.copyfile(Glob().dirJson + '\sde_tableau.json', Glob().dirJson + '\sde_tableau_old.json')
    shutil.copyfile(Glob().dirJson + '\meta_tableau.json', Glob().dirJson + '\meta_tableau_old.json')
    shutil.copyfile(Glob().dirJson + '\lyr_tableau.json', Glob().dirJson + '\lyr_tableau_old.json')
    shutil.copyfile(Glob().dirJson + '\service_tableau.json', Glob().dirJson + '\service_tableau_old.json')


    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass