#-*- coding: utf-8 -*-
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         01_JeuxDonnees_Titre.py
# Objectif:    Propriété sur le nom des jeux de données
#              Le scan met à jour la table ZZZ_TDB_tablesde en supprimant les
#              jeux inexistants et en ajoutant les nouveaux jeux de données
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    #paramètres d'entrée
    arcpy.env.workspace = Glob().baseSDEprod
    tableSDE = Glob().ZZZ_TDB_tablesde
    domaine = Glob().ZZZ_TDB_domaine
    tabledomaine = Glob().ZZZ_TDB_tabledomaine
    baseSDE = Glob().baseSDEprod

    #Temps scan
    s1 = datetime.now()

    #Création d'une liste des jeux de données
    fc_raster = arcpy.ListRasters()
    fc_table = arcpy.ListTables()
    fc_feature = arcpy.ListFeatureClasses()

    listJeuSDE = []
    listJeuSDE = fc_raster + fc_table + fc_feature
    listJeuSDE = sorted(listJeuSDE)


    #Suppression des lignes dans DATUM sur les jeux de données inexsitantes
    rows = arcpy.SearchCursor(tableSDE)
    listDelete = []
    for row in rows:
        if row.getValue('tab_nom') not in listJeuSDE:
            listDelete.append(row.getValue('tab_nom'))
    del row, rows


    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

    for sup in listDelete:
        # Execution de la requête
        sql = "DELETE FROM ZZZ_TDB_tablesde WHERE tab_nom='{}'".format(sup)
        sql_return = egdb_conn.execute(sql)


    #Enregistrement dans DATUM des nouveaux jeux de données
    listJeuDatum = []
    last_id = 0

    rows = arcpy.SearchCursor(tableSDE)
    for row in rows:
        listJeuDatum.append(row.getValue('tab_nom'))
        if last_id < row.getValue('tab_id'): #récupération du dernier id
            last_id = row.getValue('tab_id')

    del rows

    listAjout = []
    for jeu in listJeuSDE:
        if jeu[4:7] != 'ZZZ': #retirer les "***.ZZZ_***_*****"
            if jeu not in listJeuDatum:
                listAjout.append(jeu)

    rows = arcpy.InsertCursor(tableSDE)
    last_id += 1

    for i, ajout in enumerate(listAjout):
        row = rows.newRow()
        row.setValue('tab_id', i + last_id)
        row.setValue('tab_nom', ajout)
        rows.insertRow(row)

    del rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    writeLogs()
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    pass













