#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         02_JeuxDonnees_Type.py
# Objectif:    Propriété sur le type des jeux de données
#
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    arcpy.env.workspace = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde


    #Temps scan
    s1 = datetime.now()

    #Liste des jeux de données suivant le type
    listRaster = arcpy.ListRasters()
    listFeature = arcpy.ListFeatureClasses() #features et vues confondues"
    listTable = arcpy.ListTables() #tables et vues confondues"

        #liste des vues (de la table "USER_VIEWS")
    sde_conn = arcpy.ArcSDESQLExecute(arcpy.env.workspace)
    sql ="select VIEW_NAME from USER_VIEWS"
    sql_return = sde_conn.execute(sql)
    listView = [x[0] for x in sql_return]

    #Création d'un dictionnaire nom {type}
    dicoJeu = {}
        #Rec. table/vue
    for jeu in listTable:
        table = jeu[4:].upper()
        if table in listView:
            dicoJeu[jeu] = 'Vue'
        else:
            dicoJeu[jeu] = 'Table'

        #Rec. feature/vue
    for jeu in listFeature:
        if jeu[4:].upper() not in listView:
            couchePath = arcpy.env.workspace + '/' + jeu
            desc = arcpy.Describe(couchePath)
            dicoJeu[jeu] = desc.shapeType
        else:
            dicoJeu[jeu] = 'Vue'

        #Rec. raster
    for jeu in listRaster:
        dicoJeu[jeu] = 'Raster'


    #Mise à jour de la table "ZZZ_TDB_tablesde"
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)

    for row in rows:
        if row.getValue('tab_nom') in dicoJeu.keys():
            row.setValue('tab_type', dicoJeu[row.getValue('tab_nom')])
            rows.updateRow(row)
    del rows


    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass



















