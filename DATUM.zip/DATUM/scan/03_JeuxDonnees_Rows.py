#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         03_JeuxDonnees_Rows.py
# Objectif:    Propriété sur le nombre d'entités dans les jeux de données
#              La source des informations se trouve dans la table système
#              Oracle "ALL_TABLES"
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *
try:
    baseSDE = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde


    #Temps scan
    s1 = datetime.now()

    #SQL pour le nombre entité dans table "ALL_TABLES"
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "SELECT table_name, num_rows FROM all_tables WHERE owner='SIG'"
    sql_return = egdb_conn.execute(sql)

    #Création d'un dico jeu = {nombre d'entité}
    if isinstance(sql_return, __builtins__.list):
        dicoSQLJeux = {}
        for row in sql_return:
            dicoSQLJeux[row[0]] = row[1]


    #Mise à jour de la table "SIG.ZZZ_TDB_tablesde"
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)

    for row in rows:
        nomDATUM = row.getValue('tab_nom')[4:].upper()

        if nomDATUM in dicoSQLJeux.keys():
            if dicoSQLJeux[nomDATUM] is None:
                row.setValue('tab_num_rows', None)
            else:
                row.setValue('tab_num_rows', int(dicoSQLJeux[nomDATUM]))
            rows.updateRow(row)

    del rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass






