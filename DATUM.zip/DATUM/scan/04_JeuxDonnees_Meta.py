#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         04_JeuxDonnees_Meta.py
# Objectif:    Association métadonnées - Jeux de données
#              Création de la clé étrangère des métadonnées dans la table
#              des jeux de données
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    arcpy.env.workspace = Glob().baseSDEprod
    table_meta = Glob().tableDSITMeta
    tableSDE = Glob().ZZZ_TDB_tablesde

    #Temps scan
    s1 = datetime.now()

    #Initialisation
    listTable = []
    listMeta = []
    dicoMeta = {} # {champs PKB71 : 'SIG.' + nom_majuscule}

    #Nettoyage des couches virtuelles
    if arcpy.Exists("in_memory/table_meta"):
        arcpy.Delete_management("in_memory/table_meta")

    #Création de la liste des couches d'entités
    fc_raster = arcpy.ListRasters()
    fc_table = arcpy.ListTables()
    fc_feature = arcpy.ListFeatureClasses()

    listTable = fc_raster + fc_table + fc_feature
    listTable = [s.upper() for s in listTable]

    #récupération des noms de couche dans les méta
    arcpy.MakeQueryTable_management(table_meta, "in_memory/table_meta")
    rows = arcpy.SearchCursor("in_memory/table_meta")

    for row in rows:
        dicoMeta[ 'SIG.' + row.PKB72.upper()] = (row.PKB72, row.CONTA)
    del row, rows

    listMeta =  [x for x in dicoMeta.keys()]

    #données sur base ArcSDE sans métadonnées
    errorNoMeta = __builtins__.list(set(listTable).difference(set(listMeta)))

    #Enregistrement données dans la table ZZZ_TDB_tablesde
    rows = arcpy.UpdateCursor(tableSDE)

    for row in rows:
        nomCouche = row.getValue('tab_nom').upper()

        if nomCouche in errorNoMeta:
            if '_ATTACH' in nomCouche:
                row.setValue('tab_meta_id', 'n/a')
            else:
                row.setValue('tab_meta_id', '')
        else:
            if nomCouche in listMeta:
                row.setValue('tab_meta_id', row.getValue('tab_nom')[4:])
                row.setValue('tab_contact', dicoMeta[nomCouche][1])
        rows.updateRow(row)

    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass










