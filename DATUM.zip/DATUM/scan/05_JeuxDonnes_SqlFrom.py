#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         05_JeuxDonnes_SqlFrom.py
# Objectif:    Propriété sur la liste des jeux de données définissant
#              une requête SQL et la liste des requêtes SQL dans lesquelles
#              un jeu de données est utilisé
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde
    tableVues = Glob().ZZZ_TDB_defvues

    #Temps scan
    s1 = datetime.now()

    #Création de la table "ZZZ_TDB_DefVues"
    sde_conn = arcpy.ArcSDESQLExecute(baseSDE)

    sql = "drop table ZZZ_TDB_DefVues"
    sde_return = sde_conn.execute(sql)

    sql = "create table ZZZ_TDB_DefVues as select VIEW_NAME, TEXT_LENGTH, to_lob(TEXT) CMD from USER_VIEWS"
    sde_return = sde_conn.execute(sql)

    dicoVues = {}
    dicoJeux = {}

    #Effacement des valeurs du champ 'tab_sqlfrom' de ZZZ_TDB_tablesde
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        row.setValue('tab_sqlfrom','')
        rows.updateRow(row)
    del rows


    #Création de la liste des tables utilisées dans les requêtes SQL

    cmdSQL = ['WHERE', 'ORDER', 'GROUP', 'HAVING'] #mots pour découper la requête sql
    rows = arcpy.SearchCursor(tableVues)

    for row in rows:
        if row.getValue('VIEW_NAME')[-1] != 'W': #ne prend pas en compte les vues versionnées

            chaineSQL = row.getValue('CMD')

            #Pour supprimer les caractères de contrôle dans chaîne de caractères
            regex = re.compile(r'[\n\r\t]')
            chaineSQL = regex.sub(" ", chaineSQL)

            chaineSQL = chaineSQL.replace(',',' ')
            chaineSQL = chaineSQL.replace('.',' ')
            chaineSQL = chaineSQL.replace('(',' ')
            chaineSQL = chaineSQL.replace(')',' ')

            start = 0
            stop = 0
            refTable = []
            for txt in chaineSQL.split(' '):

                if txt.upper() in cmdSQL:
                    stop = 1
                if start == 1 and stop == 0:
                    if txt != '':
                        refTable.append(txt)
                if 'FROM' in txt.upper():
                    start = 1

            refTable = [x.upper() for x in refTable if '_' in x] #conserve seulement les jeux avec '_'
            refTable = __builtins__.list(set(refTable))

            dicoVues[row.getValue('VIEW_NAME')] = refTable

    del rows

    #Création de la liste des vues par table
    for vue in dicoVues.keys():
        for table in dicoVues[vue]:
            if table not in dicoJeux.keys():
                dicoJeux[table] = vue
            else:
                dicoJeux[table] = dicoJeux[table] +',' + vue



    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        nomJeu = row.getValue('tab_nom')[4:].upper()
        if nomJeu in dicoJeux.keys():
            row.setValue('tab_sqlfrom', dicoJeux[nomJeu])
            rows.updateRow(row)
        if nomJeu in dicoVues.keys():
            row.setValue('tab_sqlfrom', ','.join(dicoVues[nomJeu]))
            rows.updateRow(row)
    del rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass


