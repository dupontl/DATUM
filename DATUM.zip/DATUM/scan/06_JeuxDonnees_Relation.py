#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         06_JeuxDonnees_Relation.py
# Objectif:    Propriétés sur la liste des classes de relation définies
#              avec un jeu de données
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    tableSDE = Glob().ZZZ_TDB_tablesde


    #Temps scan
    s1 = datetime.now()

    #Initialisation du champ 'tab_relation' dans SIG.ZZZ_TDB_tablesde
    rows = arcpy.UpdateCursor(tableSDE)
    for row in rows:
        row.setValue('tab_relation', None)
        rows.updateRow(row)
    del row, rows


    #Requête sql sur la table "GDB_Items" pour créer liste des jeux de données
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select Name from SDE.GDB_Items where PhysicalName like ('SIG.%')"
    sql_return = egdb_conn.execute(sql)


    #Si sql_return est une liste alors lecture des lignes
    Dico = {} #dico pour enregistrer Dico[NomTable] = chaine(NomRelation)
    if isinstance(sql_return, __builtins__.list):

        for row in sql_return:
            fc = baseSDE + '//' + row[0]
            desc = arcpy.Describe(fc)

            #recherche dans sql les tables de relation
            if desc.dataType == 'RelationshipClass':

                #Si NomTable déjà enregistrer alors ajout NomRelation
                #Enregistrement de la table Destination
                if desc.destinationClassNames[0] in Dico:
                    oldVal =  Dico[desc.destinationClassNames[0]]
                    newVal = row[0] + ',' + oldVal
                    Dico[desc.destinationClassNames[0]] = newVal

                else:
                    Dico[desc.destinationClassNames[0]] = row[0]

                #Enregistrement de la table Origine
                if desc.originClassNames[0] in Dico:
                    oldVal =  Dico[desc.originClassNames[0]]
                    newVal = row[0] + ',' + oldVal
                    Dico[desc.originClassNames[0]] = newVal

                else:
                    Dico[desc.originClassNames[0]] = row[0]


    #Enregistrement des infos dans SIG.ZZZ_TDB_tablesde
    cursor = arcpy.UpdateCursor(tableSDE)

    for row in cursor:
        #Recherche si row est dans Dico
        if row.getValue('tab_nom') in Dico:
            row.setValue('tab_relation', str(Dico[row.getValue('tab_nom')]))
            cursor.updateRow(row)

    del row, cursor

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass



