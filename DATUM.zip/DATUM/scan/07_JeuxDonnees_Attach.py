#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         07_JeuxDonnees_Attach.py
# Objectif:    Propriété sur la liste des pièces jointes associée
#              à un jeu de données
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde

    #Temps scan
    s1 = datetime.now()

    #Initialisation du champ 'tab_attach' dans SIG.ZZZ_TDB_tablesde
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        row.setValue('tab_attach', None)
        rows.updateRow(row)
    del row, rows

    #Requête sql sur la table "GDB_Items" pour créer liste des jeux de données
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select Name from SDE.GDB_Items where PhysicalName like ('SIG.%__ATTACH')"
    sql_return = egdb_conn.execute(sql)

    listAttach = [x[0][:-8] for x in sql_return] #liste des jeux de données avec pièces jointes


    if isinstance(sql_return, __builtins__.list):
        rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
        for row in rows:
            if row.getValue('tab_nom') in listAttach:
                row.setValue('tab_attach', 'Oui')
                rows.updateRow(row)
        del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass

