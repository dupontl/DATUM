#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         08_JeuxDonnees_CoordAlti.py
# Objectif:    Propriété sur les coordonnées altimétriques des jeux de données
#
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde

    #Temps scan
    s1 = datetime.now()

    #Réinitialisation du champ "tab_coord_alt" de ZZZ_TDB_tablesde
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
            row.setValue('tab_coord_alt', '')
            rows.updateRow(row)
    del row, rows

    #sql sur les FEATURES de la table "GEOMETRY_COLUMNS" pour créer liste des jeux de données
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

    sql="select SDE.ST_GEOMETRY_COLUMNS.TABLE_NAME,  SDE.ST_SPATIAL_REFERENCES.DEFINITION \
        from SDE.ST_GEOMETRY_COLUMNS, SDE.ST_SPATIAL_REFERENCES \
        where SDE.ST_SPATIAL_REFERENCES.SRID=SDE.ST_GEOMETRY_COLUMNS.SRID"

    sql_return = egdb_conn.execute(sql)

    dicoCoord = {}
    if isinstance(sql_return, __builtins__.list):
        for row in sql_return:
            sysAlti = ''
            listSR = row[1].split(',')
            for sr in listSR:
                if 'VERTCS' in sr:
                    sysAlti = sr.split('"')[1]
            dicoCoord[row[0]] = sysAlti

    #Mise à jour du champ "tab_coord_alt"
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)

    for row in rows:
        jeu = row.getValue('tab_nom')[4:].upper()
        if jeu in dicoCoord.keys():
            row.setValue('tab_coord_alt', dicoCoord[jeu])
            rows.updateRow(row)
        if row.getValue('tab_type')=='Vue':
            row.setValue('tab_coord_alt', 'n/a')
            rows.updateRow(row)
    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass


