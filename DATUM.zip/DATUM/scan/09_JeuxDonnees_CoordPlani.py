#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         09_JeuxDonnees_CoordPlani.py
# Objectif:    Propriété sur les coordonnées planimétrique des jeux de données
#
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    arcpy.env.workspace = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde

    #Temps scan
    s1 = datetime.now()

    #Réinitialisation des champs "tab_coord_pla" et "tab_coord-alt" de ZZZ_TDB_tablesde
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
            row.setValue('tab_coord_pla', '')
            rows.updateRow(row)
    del row, rows

    #Liste des jeux de données et recherche sys. géo
    listFeatures = arcpy.ListFeatureClasses()
    listRasters = arcpy.ListRasters()

    listJeux = listFeatures + listRasters

    dicoGeo = {}
    for jeu in listJeux:
        desc = arcpy.Describe(jeu)
        sysGeo = desc.spatialReference
        dicoGeo[jeu] = sysGeo.name

    #Mise à jour de DATUM
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)

    for row in rows:
        jeu = row.getValue('tab_nom')
        if jeu in dicoGeo.keys():
            row.setValue('tab_coord_pla', dicoGeo[jeu])
            rows.updateRow(row)
        if row.getValue('tab_type')=='Vue':
            row.setValue('tab_coord_pla', 'n/a')
            rows.updateRow(row)
    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass




