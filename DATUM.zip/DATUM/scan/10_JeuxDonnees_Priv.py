#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         10_JeuxDonnees_Priv.py
# Objectif:    Propriété sur la liste des privilèges des jeux de données
#
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde

    #Temps scan
    s1 = datetime.now()

    #Connexion à la base ArcSDE
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

    #Données de la table oracle "USER_TAB_PRIV"
    sql="select * from USER_TAB_PRIVS"
    tableUserPriv = egdb_conn.execute(sql)

    #Liste des jeux de données de la table "USER_TAB_PRIV"
    sql="select distinct TABLE_NAME from USER_TAB_PRIVS"
    sql_return = egdb_conn.execute(sql)
    listTableSde =[x[0] for x in sql_return]

    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)

    #dico de valeurs binaires pour additionner les privilèges
    dicoType = {'SELECT':1000, 'INSERT':100, 'UPDATE':10, 'DELETE':1}
    #Somme (binaire) des privilèges
    dicoCasPriv = {1:'D', 10:'U', 11:'U-D', 100:'I', 101:'I-D', 110:'I-U', 111:'I-U-D',
                    1000:'S', 1001:'S-D', 1010:'S-U', 1100:'S-I', 1011:'S-U-D', 1101:'S-I-D', 1110:'S-I-U', 1111:'S-I-U-D'}

    for row in rows:
        nomJeu = row.getValue('tab_nom')[4:].upper()
        if nomJeu in listTableSde:
            #sql des privilèges sur un jeu de données
            sql="select GRANTEE, PRIVILEGE from USER_TAB_PRIVS \
                where GRANTEE<>'SDE' and TABLE_NAME='{}'".format(nomJeu)
            sql_return = egdb_conn.execute(sql)

            #dico en sortie : dicojeuPriv = {u'PIG': 'S-I-U', u'UIG': 'S'}
            if isinstance(sql_return, __builtins__.list):
                dicojeuPriv = {}
                for i in sql_return:
                    if i[0] not in dicojeuPriv.keys():
                        dicojeuPriv[i[0]] = dicoType[i[1]]
                    else:
                        dicojeuPriv[i[0]] = dicojeuPriv[i[0]] + dicoType[i[1]] #calcul somme binaire

                #chaine en sortie : PIG(S-I-U),UIG(S)
                chaine = ''
                for key in sorted(dicojeuPriv.keys()):
                    chaine = chaine +  key + '(' + dicoCasPriv[dicojeuPriv[key]] + '),'

                chaine = chaine[:-1]
                row.setValue('tab_priv', chaine)
                rows.updateRow(row)

    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass







