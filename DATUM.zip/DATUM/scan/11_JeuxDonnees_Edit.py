#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         11_JeuxDonnees_Edit.py
# Objectif:    Propriété sur l’éditeur de suivi des jeux de données
#
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

##from param_scan import *

try:
    #Temps scan
    s1 = datetime.now()

    #Paramètres
    arcpy.env.workspace = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde

    #réinitialisation du champ 'tab_edit' de la table "ZZZ_TDB_tablesde"
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        row.setValue('tab_edit', '')
        rows.updateRow(row)
    del row, rows


    #Recherche "suivi de l'éditeur" dans les jeux de données
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)

    listRaster = arcpy.ListRasters() #pas de suivi de l'éditeur pour raster

    for row in rows:
        jeuPath = arcpy.env.workspace + '//' + row.getValue('tab_nom')
        desc = arcpy.Describe(jeuPath)
        if row.getValue('tab_nom').upper() not in listRaster:
            if desc.editorTrackingEnabled:
                row.setValue('tab_edit', 'oui')
                rows.updateRow(row)

    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass






