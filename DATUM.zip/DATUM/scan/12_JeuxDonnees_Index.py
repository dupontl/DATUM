#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         12_JeuxDonnees_Index.py
# Objectif:    Propriété sur les index spatial et attributaires
#              des jeux de données
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

##from param_scan import *

try:
    #Temps scan
    s1 = datetime.now()

    #Paramètres
    arcpy.env.workspace = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde
    ##elimIndex = ['SHAPE', 'OBJECTID'] #index exclus (index spatial et objectid)

    #réinitialisation du champ 'tab_edit' de la table "ZZZ_TDB_tablesde"
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        row.setValue('tab_index', '')
        rows.updateRow(row)
    del row, rows

    #Liste des index
    dicoIndex = {}
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)

    for row in rows:
        jeuPath = arcpy.env.workspace + '//' + row.getValue('tab_nom')
        indexes = arcpy.ListIndexes(jeuPath)

        lst = []
        if isinstance(indexes, __builtins__.list):
            for index in indexes:
    ##            if index.fields[0].name not in elimIndex:
                lst.append(index.fields[0].name)
        lst.reverse() #SHAPE en premier dans la liste
        row.setValue('tab_index', ','.join(lst))
        rows.updateRow(row)

    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass

