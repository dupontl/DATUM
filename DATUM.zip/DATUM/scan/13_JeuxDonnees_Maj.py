#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         13_JeuxDonnees_Maj.py
# Objectif:    Propriété sur la date de mise à jour effective des jeux de
#              données. Dans un premier temps, recherche date modif de la
#              structure de la table sur "ALL_TAB_MODIFICATIONS" avec le
#              champ "TIMESTAMP", puis dans "ALL_OBJECTS" avec le champ
#              "LAST_DDL_TIME" si "TIMESTAMP" absent, avec recherche sur
#              le champ de date de modif des entités si le suivi de
#              l'éditeur est activé
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
#
# Mise à jour: 17/08/2018 / Anthony Vergne / Université de La Rochelle - LUPSIG
# Modification des requêtes SQL, conversion des dates en string, ajout de
# la date du TIMESTAMP comme date de modification prioritaire.
#
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    baseSDEprod = Glob().baseSDEprod
    arcpy.env.workspace = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde

    #Temps scan
    s1 = datetime.now()

    #création dico des jeux de données
    dicoJeux = {row.getValue('TAB_NOM')[4:].upper():(row.getValue('TAB_NOM'),row.getValue('TAB_DATEMODIF')) for row
                in arcpy.SearchCursor(ZZZ_TDB_tablesde)}

    # Recherche date de la dernière modification de chaque table
    # de SIG_prod_SIG dans les tables système Oracle
    # ALL_TAB_MODIFICATIONS et ALL_OBJECTS
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDEprod)

    # Execution des requêtes
    sql_ATM="select TABLE_NAME, " \
            "to_char((TIMESTAMP), 'YYYY-MM-DD HH24:MI:SS') " \
            "from ALL_TAB_MODIFICATIONS " \
            "where TABLE_OWNER = 'SIG'"

    sql_AO="select OBJECT_NAME, " \
           "to_char((LAST_DDL_TIME), 'YYYY-MM-DD HH24:MI:SS')" \
           "from ALL_OBJECTS " \
           "where OWNER = 'SIG' and OBJECT_TYPE = 'TABLE'"
    # to_char() transforme date en str, sinon LAST_DDL_TIME et TIMESTAMP == '' depuis ArcGIS 10.5

    sql_ATM = egdb_conn.execute(sql_ATM)
    sql_AO = egdb_conn.execute(sql_AO)

    #recherche date dans suivi éditeur (si activé)
    listRaster = [x[4:] for x in arcpy.ListRasters()] #pas de suivi de l'éditeur pour raster

    # SI valeur de TIMESTAMP :
    for rowSQL in sql_ATM:
        if rowSQL[0] in dicoJeux.keys():
            date_ATM = datetime.strptime(rowSQL[1], '%Y-%m-%d %H:%M:%S')  #date 'string' reformée en type 'date'
            if rowSQL[0] not in listRaster:
                desc = arcpy.Describe(rowSQL[0])
                if desc.editorTrackingEnabled:
                    rows = arcpy.SearchCursor(rowSQL[0])
                    for row in rows:
                        if row.getValue(desc.editedAtFieldName)!= None:
                            if row.getValue(desc.editedAtFieldName) > date_ATM:
                                date_ATM = row.getValue(desc.editedAtFieldName)
                    del rows

            #enr. nouvelle date dans dico
            dicoJeux[rowSQL[0]] =(dicoJeux[rowSQL[0]][0], date_ATM)

    # SI NON, mais valeur de LAST_DDL_TIME :
    for rowSQL in sql_AO:
        if rowSQL[0] in dicoJeux.keys():
            date_AO = datetime.strptime(rowSQL[1], '%Y-%m-%d %H:%M:%S') #date 'string' reformée en type 'date'
            if rowSQL[0] not in listRaster:
                # recherche date modif si éditeur de suivi est activé
                desc = arcpy.Describe(rowSQL[0])
                if desc.editorTrackingEnabled:
                    rows = arcpy.SearchCursor(rowSQL[0])
                    for row in rows:
                        if row.getValue(desc.editedAtFieldName) != None:
                            if row.getValue(desc.editedAtFieldName) > date_AO:
                                date_AO = row.getValue(desc.editedAtFieldName)
                    del rows

            # enr. nouvelle date dans dico si plus récente que TIMESTAMP
            if dicoJeux[rowSQL[0]][1] == None:
                dicoJeux[rowSQL[0]] = (dicoJeux[rowSQL[0]][0], date_AO)
            elif dicoJeux[rowSQL[0]][1] != None and date_AO > dicoJeux[rowSQL[0]][1]:
                dicoJeux[rowSQL[0]] = (dicoJeux[rowSQL[0]][0], date_AO)

    #Enregistrement de la date dans la table ZZZ_TDB_tablesde
    dicoRec= {dicoJeux[x][0]:dicoJeux[x][1] for x in dicoJeux.keys()} #dico pour enr. date dans DATUM

    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)

    for row in rows:
        if row.getValue('TAB_NOM') in dicoRec.keys():
            row.setValue('TAB_DATEMODIF', dicoRec[row.getValue('TAB_NOM')])
            rows.updateRow(row)
    del rows


    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass