#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         14_JeuxDonnees_MajSuivi.py
# Objectif:    Propriétés sur la date butoir effective de mise à jour et sur
#              la fréquence de mise à jour des métadonnées. Définition du
#              statut de mise à jour dans la table ZZZ_TDB_TABLESDE.
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
#
# Mise à jour: 17/08/2018 / Anthony Vergne / Université de La Rochelle - LUPSIG
# Ajout du calcul du délai de mise à jour pour les données en mise à jour
# 'continue', si inférieur à la variable définie dans param_scan.py, alors
# la donnée est considérée comme étant à jour.
#
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    ZZZ_TDB_metadonnees = Glob().ZZZ_TDB_metadonnees
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde
    tableDSITMeta = Glob().tableDSITMeta
    delai_maj_str = Glob().delai_maj_str

    #Temps scan
    s1 = datetime.now()

    #Planification : fréquence de màj convertie en jours
    dicoPlanif = {u'quotidienne': u'continue', u'hebdomadaire': u'continue', u'mensuelle': 31, u'bimensuelle': 62, \
                  u'trimestrielle': 93, u'biannuelle': 183, u'annuelle': 366, u'tous les 2 ans': 732, \
                  u'tous les 3 ans': 1098, u'tous les 4 ans': 1464, u'tous les 5 ans': 1830, \
                  u'tous les 10 ans': 3660, u'continue': u'continue', u'si nécessaire': u'non planifiée', \
                  u'irrégulière': u'non planifiée', u'non planifiée': u'non planifiée', u'inconnue': u'non planifiée', \
                  u'figée': u'figée'}

    #Réinitialisation
    arcpy.DeleteRows_management(ZZZ_TDB_metadonnees)

    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        row.setValue('tab_maj_statut', '')
        rows.updateRow(row)
    del row, rows


    #Création d'un dico de la table ZZZ_TDB_tablesde ('tab_meta_id' : 'tab_datemodif')
    dicoSDE = {}
    rows = arcpy.SearchCursor(ZZZ_TDB_tablesde)
    for row in rows:
        if row.getValue('tab_meta_id') != None:
            dicoSDE[row.getValue('tab_meta_id')] = row.getValue('tab_datemodif')

    del row, rows


    #Création d'un dico de la table tableDSITMeta ('PKB72' : 'FREQU')
    dicoDSITMeta = {}
    rows = arcpy.SearchCursor(tableDSITMeta)

    for row in rows:
        dicoDSITMeta[row.getValue('PKB72')] = row.getValue('FREQU')

    del row, rows

    #Création de la table ZZZ_TDB_metadonnees
    rows = arcpy.InsertCursor(ZZZ_TDB_metadonnees)

    for i, metaKey in enumerate(dicoDSITMeta.keys()):
        row = rows.newRow()
        row.setValue('meta_id', i)
        row.setValue('meta_pkB72', metaKey)

        if dicoDSITMeta[metaKey] != None: # si fréquence MàJ renseignée
            row.setValue('meta_maj_freq', dicoDSITMeta[metaKey])
            if isinstance(dicoPlanif[dicoDSITMeta[metaKey]], __builtins__.int ): #si dans dicoPlanif
                if metaKey in dicoSDE: #si présent dans la table ZZZ_TDB_tablesde
                    if dicoSDE[metaKey] != None: #si date de modification
                        #date butoire pour prochaine maj
                        date_butoir = dicoSDE[metaKey] + timedelta(days = dicoPlanif[dicoDSITMeta[metaKey]])
                        row.setValue('meta_maj_date', date_butoir)

        rows.insertRow(row)

    del row, rows

    #Mise à jour de la table ZZZ_TDB_tablesde (champ 'tab_maj_statut')
    rows = arcpy.SearchCursor(ZZZ_TDB_metadonnees)
    dicoStatutMaJ = {}
    maj_invalide = {u'si nécessaire', u'maj invalide', u'irrégulière', u'non planifiée', u'inconnue', None}

    for row in rows:
        now = datetime.now()

        # Récupération du TIMESTAMP calculé dans scan n°13 ou date màj MD
        last_modif = row.getValue('meta_jeudatemodif')

        if row.getValue('meta_maj_freq') == u'figée':
            dicoStatutMaJ[row.getValue('meta_PKB72')] = u'Figée'

        if row.getValue('meta_maj_freq') in maj_invalide:
            dicoStatutMaJ[row.getValue('meta_PKB72')] = None

        if row.getValue('meta_maj_freq') == u'continue' and last_modif != None:
            # reconversion du Glob().delai_maj_str au format timedelta
            delai_maj = datetime.strptime(delai_maj_str, '%d')
            delai_maj = timedelta(days=delai_maj.day, hours=delai_maj.hour, minutes=delai_maj.minute, \
                                  seconds=delai_maj.second, microseconds=delai_maj.microsecond)

            # Calcul de l'écart entre la date de dernière modification et la date du jour
            laps = now - datetime.strptime(last_modif, '%Y-%m-%d %H:%M:%S')

            if laps < delai_maj:
                dicoStatutMaJ[row.getValue('meta_PBK72')] = u'-'
            else:
                dicoStatutMaJ[row.getValue('meta_PKB72')] = u'Mise à jour à faire'

        date_maj = row.getValue('meta_maj_date')
        if date_maj != None:
            if date_maj - now > timedelta(0, 0, 0):
                dicoStatutMaJ[row.getValue('meta_PKB72')] = u'-'
            else:
                dicoStatutMaJ[row.getValue('meta_PKB72')] = u'Mise à jour à faire'

    del row, rows

    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        nomJeu = row.getValue('tab_nom')
        if row.getValue('tab_meta_id') in dicoStatutMaJ:
            row.setValue('tab_maj_statut', dicoStatutMaJ[row.getValue('tab_meta_id')])

        elif row.getValue('tab_meta_id') not in dicoStatutMaJ and row.getValue('tab_meta_id') != None:
            if row.getValue('tab_type') == 'Vue': #Exception sur les vues
                row.setValue('tab_maj_statut', u'n/a')
            elif '_ATTACH' in nomJeu: #Exception sur les pièces jointes
                row.setValue('tab_maj_statut', u'n/a')
            else:
                row.setValue('tab_maj_statut', u'Non planifiée')
        rows.updateRow(row)

    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass







