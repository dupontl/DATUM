#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         15_JeuxDonnees_Vers.py
# Objectif:    Propriété sur le versionnement des jeux de données
#
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------


#Paramètres
##from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde

    #Initialisation du champ 'tab_vers' dans SIG.ZZZ_TDB_tablesde
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        row.setValue('tab_vers', '')
        rows.updateRow(row)
    del row, rows


    #Temps scan
    s1 = datetime.now()

    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

    #sql sur les tables ArcSDE dont le versionnement ou l'archivage est actif
    sql="select distinct SDE.TABLE_REGISTRY.TABLE_NAME, SDE.TABLE_REGISTRY.IMV_VIEW_NAME \
        from SDE.TABLE_REGISTRY \
        where SDE.TABLE_REGISTRY.IMV_VIEW_NAME IS NOT NULL"

    sql_return = egdb_conn.execute(sql)

    listVers = [x[0] for x in sql_return]

    #Mise à jour du champ 'tab_vers' de la table ZZZ_TDB_tablesde
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    if isinstance(listVers, __builtins__.list):
        for row in rows:
            jeuNom = row.getValue('tab_nom')[4:].upper()
            if jeuNom in listVers:
                row.setValue('tab_vers', 'oui')
                rows.updateRow(row)
        del row, rows


    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass

