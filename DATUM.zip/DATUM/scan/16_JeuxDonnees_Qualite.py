#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         16_JeuxDonnees_Qualite.py
# Objectif:    Définition des 8 alertes et calcul du niveau de qualité
#              des jeux de données
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
##from param_scan import *

try:
    ZZZ_TDB_tablesde = Glob().ZZZ_TDB_tablesde
    Nomenclature = Glob().Nomenclature
    arcpy.env.workspace = Glob().baseSDEprod
    NivQual = Glob().NivQual
    dirJson = Glob().dirJson

    #Temps scan
    s1 = datetime.now()

    #Initialisation dico des indicateurs (clé : nom du jeu)
    rows = arcpy.SearchCursor(ZZZ_TDB_tablesde)
    dicoInd = {}

    for row in rows:
        dicoInd[row.getValue('tab_nom')] = ''
    del row, rows

    #-------NIVEAU DE QUALITE J01---------#

    for nom in dicoInd.keys():
        indi = ''
        if nom[4:7].isupper() == False:
            indi = 'J01'
        if nom[7:8] != '_':
            indi = 'J01'
        if nom[8:11].isupper() == False:
            indi = 'J01'
        if nom[11:12] != '_':
            indi = 'J01'
        if indi == 'J01':
            dicoInd[nom] = 'J01'

    #-------NIVEAU DE QUALITE J02---------#

    classeur = xlrd.open_workbook(Nomenclature)

    # Récupération du nom de toutes les feuilles sous forme de liste
    nom_des_feuilles = classeur.sheet_names()

    # Récupération de la première feuille
    feuille = classeur.sheet_by_name(nom_des_feuilles[0])

    listRang = []
    for l in range (3,feuille.nrows):
        rang =  feuille.cell_value(l, 5)
        if (rang != ''):
            if (len(rang) == 12):
                listRang.append(rang[0:8])
            else:
                log.warning('Nomenclature à adapter : ligne {}'.format(l+1))

    for nomJeu in dicoInd.keys():
        if nomJeu[4:12] not in listRang:
            if dicoInd[nomJeu] == '':
                dicoInd[nomJeu] = 'J02'
            else:
                dicoInd[nomJeu] = dicoInd[nomJeu] + ',J02'

    #-------NIVEAU DE QUALITE J03---------#

    rows = arcpy.SearchCursor(ZZZ_TDB_tablesde)
    i = 0
    for row in rows:
        nomJeu = row.getValue('tab_nom')
        if row.getValue('tab_priv') != None:
            if 'UIG(S)' not in row.getValue('tab_priv'):
                if nomJeu in dicoInd.keys():
                    if dicoInd[nomJeu] == '':
                        dicoInd[nomJeu] = 'J03'
                    else:
                        dicoInd[nomJeu] = dicoInd[nomJeu] + ',J03'
        else:
            i = i + 1
            if nomJeu in dicoInd.keys():
                if dicoInd[nomJeu] == '':
                    dicoInd[nomJeu] = 'J03'
                else:
                    dicoInd[nomJeu] = dicoInd[nomJeu] + ',J03'
    del row, rows

    #-------NIVEAU DE QUALITE J04---------#

    test=u"abcdefghijklmnopqrstuvwxyz_-0123456789"
    listErrAccent = []

    #Recherche dans tables
    listFeatures = arcpy.ListFeatureClasses()
    listTables = arcpy.ListTables()

    listJeux = listFeatures + listTables


    for fc in listJeux:
        fields = arcpy.ListFields(fc)

        for field in fields:
            for l in field.name:
                ut = l.encode('utf-8')
                try :
                    ut.lower() not in test
                except:
                    listErrAccent.append(fc)

    #Recherche dans features (point, polyligne, polygone,...)

    listErrAccent = __builtins__.list(set(listErrAccent)) #suppression doublon

    for nomJeu in listErrAccent:
        if nomJeu in dicoInd.keys():
            if dicoInd[nomJeu] == '':
                dicoInd[nomJeu] = 'J04'
            else:
                dicoInd[nomJeu] = dicoInd[nomJeu] + ',J04'

    #-------NIVEAU DE QUALITE J05---------#

    rows = arcpy.SearchCursor(ZZZ_TDB_tablesde)
    listFeatures = arcpy.ListFeatureClasses()

    for row in rows:
        nomJeu =  row.getValue('tab_nom')
        if nomJeu in listFeatures:
            if row.getValue('tab_type') != 'Vue':
                if 'SHAPE' not in row.getValue('tab_index'): #Nom de l'index spatial
                    if 'FORME' not in row.getValue('tab_index'): #Autre nom possible
                        if nomJeu in dicoInd.keys():
                            if dicoInd[nomJeu] == '':
                                dicoInd[nomJeu] = 'J05'
                            else:
                                dicoInd[nomJeu] = dicoInd[nomJeu] + ',J05'
    del row, rows


    #-------NIVEAU DE QUALITE J06---------#

    rows = arcpy.SearchCursor(ZZZ_TDB_tablesde)
    i = 0
    for row in rows:
        nomJeu =  row.getValue('tab_nom')
        if row.getValue('tab_meta_id') == None:
            if row.getValue('tab_nom') in dicoInd.keys():
                i = i + 1
                if dicoInd[nomJeu] == '':
                    dicoInd[nomJeu] = 'J06'
                else:
                    dicoInd[nomJeu] = dicoInd[nomJeu] + ',J06'
    del row, rows

    #-------NIVEAU DE QUALITE J07---------#

    rows = arcpy.SearchCursor(ZZZ_TDB_tablesde)
    for row in rows:
        nomJeu =  row.getValue('tab_nom')
        if row.getValue('tab_maj_statut') == u'Mise à jour à faire':
            if row.getValue('tab_nom') in dicoInd.keys():
                if dicoInd[nomJeu] == '':
                    dicoInd[nomJeu] = 'J07'
                else:
                    dicoInd[nomJeu] = dicoInd[nomJeu] + ',J07'

    del row, rows

    #-------NIVEAU DE QUALITE J08---------#

    rows = arcpy.SearchCursor(ZZZ_TDB_tablesde)

    for row in rows:
        listFrom = []
        if row.getValue('tab_type') == 'Vue': # filtrer sur les vues (dans colonne 'sql_from', existe aussi la liste des vues / jeu de données)
            if row.getValue('tab_sqlfrom') != None:
                sqlfrom = row.getValue('tab_sqlfrom').replace('SIG.', '') #ttes les tables sans 'SIG.'
                listFrom = sqlfrom.split(',')

                listFrom = [('SIG.' + x.upper()) for x in listFrom] #transform en MAJ
                listJeuxSDE = [x.upper() for x in dicoInd.keys()]#transform en MAJ

                indi = ''
                for nomJeu in listFrom:
                    if nomJeu not in listJeuxSDE:
                        indi = 'J08'

                if indi == 'J08':
                    if dicoInd[row.getValue('tab_nom')] == '':
                        dicoInd[row.getValue('tab_nom')] = 'J08'
                    else:
                        dicoInd[row.getValue('tab_nom')] = dicoInd[row.getValue('tab_nom')] + ',J08'

    del row, rows

    #-------------------------------------#
    #RAZ des champs 'tab_qualite' et 'tab_qual_ind'
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        row.setValue('tab_qualite', '')
        row.setValue('tab_qual_ind', None)
        rows.updateRow(row)
    del row, rows

    #Enregistrement du champ 'TAB_QUALITE'
    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        if row.getValue('tab_nom') in dicoInd.keys():
            row.setValue('tab_qualite', dicoInd[row.getValue('tab_nom') ])
            rows.updateRow(row)

    del row, rows

    #Enregistrement du champ 'TAB_QUAL_IND' / fichier réf niveau qualité (data/Niveaux_qualite.xlsx)
    dicoNivQual = {}
    classeur = xlrd.open_workbook(NivQual)
    nom_des_feuilles = classeur.sheet_names()
    feuille = classeur.sheet_by_name(nom_des_feuilles[0])

    for l in range (2,feuille.nrows):
        dicoNivQual[feuille.cell_value(l, 0)] = [feuille.cell_value(l, 1), feuille.cell_value(l, 2), feuille.cell_value(l, 3)]

    rows = arcpy.UpdateCursor(ZZZ_TDB_tablesde)
    for row in rows:
        qualGlob = 0
        if row.getValue('tab_qualite') != None:
            niveauQual = row.getValue('tab_qualite').split(',')
            for niv in niveauQual:
                if qualGlob < dicoNivQual[niv][2]:
                    qualGlob = dicoNivQual[niv][2]
            row.setValue('tab_qual_ind', qualGlob)
            rows.updateRow(row)
    del row, rows


    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass




