#-*-coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         17_Fichier_Lyr.py
# Objectif:    Définition des 4 propriétés et des 8 alertes des fichiers Lyr
#              les dossiers scannés sont dans les paramètres (liste)
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

try:
    #Paramètres
    from param_scan import *
    dossiers = [r'J:\Données SIG', r'H:\Données SIG']

    arcpy.env.workspace = Glob().baseSDEprod
    baseSDE = Glob().baseSDEprod
    dirJson = Glob().dirJson
    NivQual = Glob().NivQual


    tempoFile = 'ZZZ_TDB_Temp'
    datumLyr = Glob().ZZZ_TDB_fichierlyr
    config_keyword = ""

    #Temps scan
    s1 = datetime.now()

    if arcpy.Exists(tempoFile):
        arcpy.Delete_management(tempoFile)

    #Initialisation de la table DATUM sur les fichiers lyr (Créer - Supprimer - Renommer)
    if arcpy.Exists(datumLyr):
        arcpy.CreateTable_management(arcpy.env.workspace, tempoFile, datumLyr, config_keyword)
        arcpy.Delete_management(datumLyr)
        arcpy.Rename_management(tempoFile, datumLyr.split('.')[-1])


    #Création de la table Datum sur les fichiers lyr
    rows  = arcpy.InsertCursor(datumLyr)

    for dirScan in dossiers:
        dirScan = dirScan.decode('utf-8')

        for root, dirs, files in os.walk(dirScan):
            #lecture d'un fichier
            for fichier in files:
                fic = os.path.join(root, fichier)
                #sélection fichier lyr
                if fic[-3:] == 'lyr':
                    try:
                        lyr = arcpy.mapping.Layer(fic)
                    except ValueError: #impossible de charger la couche
                                nivQual.append('L2')
                    else:
                        #lecture des couches
                        for couche in arcpy.mapping.ListLayers(lyr):
                            rec = 0 #init enr. dans DATUM
                            nivQual = [] #cf. niveaux de qualité définis
                            if couche.isFeatureLayer: #si feature
                                rec = 1
                                attribCouche = ''
                                infos = (couche.name, couche.datasetName, couche.dataSource.split('\\')[-2])

                                #sur les droits (autres que SIG_prod_UIG)
                                if root[0:2] == 'J:':
                                    if 'SIG_prod_SIG' in couche.dataSource.split('\\')[-2]:
                                        nivQual.append('L06')
                                    elif 'SIG_prod_PIG' in couche.dataSource.split('\\')[-2]:
                                     nivQual.append('L06')

                                #source de données cassée
                                if couche.isBroken:
                                    nivQual.append('L01')

                                try:
                                #Création liste des champs de la couche
                                    listField = []
                                    fields = arcpy.ListFields(couche.dataSource)
                                    for field in fields:
                                        listField.append(field.name.lower())
                                except IOError: #source via un compte utilisateur
                                    if 'L01' not in nivQual:
                                        nivQual.append('L03')

                                else:
                                    #Test sur réf. dans étiquette
                                    errLabel = []
                                    if couche.supports("LABELCLASSES"):
                                        if couche.showLabels:
                                            for lblClass in couche.labelClasses:
                                                if lblClass.showClassLabels:

                                                    #recherche champs dans expression
                                                    expChamps = []
                                                    pos1, pos2 = 0, 0
                                                    for i, l in enumerate(lblClass.expression):
                                                        if l == '[':
                                                            pos1 = i
                                                        elif l == ']':
                                                            pos2 = i
                                                            if (pos1, pos2) != (0,0):
                                                                expChamps.append(lblClass.expression[pos1+1:pos2].lower())

                                                    expChamps = [x.split('.')[-1].lower() for x in expChamps] #cas des jointures, en sortie = liste des champs

                                                    if len(set(expChamps) - set(listField)): #comparaison ensemble
                                                        nivQual.append('L04')

                                    #Test sur réf. champ du symbole
                                    if couche.symbologyType != 'OTHER':
                                        if len(couche.symbology.valueField.split('.')) == 3:#existance de jointure attributaire
                                            attribCouche = couche.symbology.valueField.split('.')[0] + '.' + couche.symbology.valueField.split('.')[1]
                                            if attribCouche != couche.datasetName:
                                                try:
                                                    fields = arcpy.ListFields(baseSDE + '\\' + attribCouche) #ajout nom des champs
                                                    for field in fields:
                                                        listField.append(field.name.lower())
                                                except:
                                                    #Problème dans la jointure attributaire !!!!
                                                    nivQual.append('XXX')
                                                    pass

                                        champ = couche.symbology.valueField.split('.')[-1].lower() #cas des jointures, prend le nom du champ

                                        if champ not in listField:
                                            nivQual.append('L05')

                            if couche.isRasterLayer: #si raster
                                rec = 1
                                infos = (couche.name, couche.datasetName, couche.dataSource.split('\\')[-2])

                                #sur les droits (autres que SIG_prod_UIG)
                                if root[0:2] == 'J:':
                                    if 'SIG_prod_SIG' in couche.dataSource.split('\\')[-2]:
                                        nivQual.append('L06')
                                    elif 'SIG_prod_PIG' in couche.dataSource.split('\\')[-2]:
                                        nivQual.append('L06')

                                #source de données cassée
                                if couche.isBroken:
                                    nivQual.append('L01')


                            #Enregistrement des infos dans DATUM (table fichierlyr)
                            if rec == 1:
                                row = rows.newRow()
                                row.setValue('lyr_fic', fichier)
                                row.setValue('lyr_couche', infos[0])
                                row.setValue('lyr_source', infos[1])
                                row.setValue('lyr_basesde', infos[2])
                                row.setValue('lyr_join', attribCouche)
                                row.setValue('lyr_qualite', ','.join(nivQual))
                                row.setValue('lyr_path', root)

                                rows.insertRow(row)

    del row, rows

    #Enregistrement du champ 'LYR_QUAL_IND' / fichier réf niveau qualité (data/Niveaux_qualite.xlsx)
    dicoNivQual = {}
    classeur = xlrd.open_workbook(NivQual)
    nom_des_feuilles = classeur.sheet_names()
    feuille = classeur.sheet_by_name(nom_des_feuilles[0])

    for l in range (2,feuille.nrows):
            dicoNivQual[feuille.cell_value(l, 0)] = [feuille.cell_value(l, 1), feuille.cell_value(l, 2), feuille.cell_value(l, 3)]

    rows = arcpy.UpdateCursor(datumLyr)
    for row in rows:
        qualGlob = 0
        if row.getValue('lyr_qualite') != None:
            niveauQual = row.getValue('lyr_qualite').split(',')
            for niv in niveauQual:
                if qualGlob < dicoNivQual[niv][2]:
                    qualGlob = dicoNivQual[niv][2]
            row.setValue('lyr_qual_ind', qualGlob)
            rows.updateRow(row)
    del row, rows


    #Création du fichier Json (lyr_tableau.json)
    dico = {}
    sous_dico = {}
    fields =  arcpy.ListFields(datumLyr)

    ensFields = set([x.name for x in fields])

    sup = set(['OBJECTID', 'LYR_FIC', 'LYR_COUCHE'])
    listFields = __builtins__.list(ensFields - sup)

    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = 'SELECT DISTINCT LYR_FIC FROM SIG.ZZZ_TDB_fichierlyr \
           ORDER BY LYR_FIC ASC'
    listLyr = egdb_conn.execute(sql)

    if isinstance(listLyr, __builtins__.list):
        for lyr in listLyr:
            sous_dico = {}
            suf = 1 #suffixe nom de couche si doublon

            if chr(39) in lyr[0]: #pour sql oracle quote -> double quote
                strLyr = lyr[0].replace("'","''")
            else:
                strLyr = lyr[0]
            sql = "SELECT LYR_COUCHE FROM SIG.ZZZ_TDB_fichierlyr WHERE LYR_FIC='{}' ORDER BY LYR_COUCHE ASC".format(strLyr.encode('utf8'))
            listCouche = egdb_conn.execute(sql)

            if isinstance(listCouche, __builtins__.list):
                for couche in listCouche:
                    if chr(39) in couche[0]: #pour sql oracle quote -> double quote
                        strCou = couche[0].replace("'","''")
                    else:
                        strCou = couche[0]
                    sql = "SELECT {} FROM SIG.ZZZ_TDB_fichierlyr \
                            WHERE LYR_COUCHE='{}' AND LYR_FIC='{}'".format(','.join(listFields), strCou.encode('utf8'), strLyr.encode('utf8'))
                    listInfo = egdb_conn.execute(sql)

                    for info in listInfo:
                        data = []
                        for i, val in enumerate(info):
                            if val == None:
                                val = ''
                            if type(val) == int: #pour lyr_qual_ind
                                val = str(val)
                            data.append(str(listFields[i]) + '|' + val)

                    #création suffixe si doublon couche
                    if couche[0] in sous_dico.keys():
                        sous_dico[couche[0]+' ('+str(suf)+')'] = data
                        suf += 1
                    else:
                        sous_dico[couche[0]] = data

            #si résultat requête comporte une seule couche
            if isinstance(listCouche, __builtins__.unicode):
                if chr(39) in listCouche: #pour sql oracle quote -> double quote
                    strCou = listCouche.replace("'","''")
                else:
                    strCou = listCouche
                sql = "SELECT {} FROM SIG.ZZZ_TDB_fichierlyr \
                        WHERE LYR_COUCHE='{}' AND LYR_FIC='{}'".format(','.join(listFields), strCou.encode('utf8'), strLyr.encode('utf8'))
                listInfo = egdb_conn.execute(sql)
                for info in listInfo:
                    data = []
                    for i, val in enumerate(info):
                        if val == None:
                            val = ''
                        if type(val) == int: #pour lyr_qual_ind
                            val = str(val)
                        data.append(str(listFields[i]) + '|' + val)
                sous_dico[listCouche] = data

            dico[lyr[0]] = sous_dico


    with open(dirJson + '\lyr_tableau.json', 'w') as outfile:
            json.dump(dico, outfile)
    outfile.close

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass







