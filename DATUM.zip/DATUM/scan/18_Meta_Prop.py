#-*- coding: utf-8 -*-
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         18_Meta_Prop.py
# Objectif:    Définition des 10 propriétés sur les fiches des métadonnées
#
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
#
# Mise à jour: 17/08/2018 / Anthony Vergne / Université de La Rochelle - LUPSIG
# Modification des requêtes SQL, conversion des dates en string, ajout de la date
# de dernière modification et du contact e-mail dans la table ZZZ_TDB_METADONNNES.
#
# Développement python / arcpy
#-------------------------------------------------------------------------------

try:
    #Paramètres
##    from param_scan import *

    jeuDatum = Glob().ZZZ_TDB_tablesde
    MetaDSIT = Glob().tableDSITMeta
    metaDATUM = Glob().ZZZ_TDB_metadonnees

    connexSDE = Glob().connexSDE

    s1 = datetime.now()

    # récupération TIMESTAMP et LAST_DDL_TIME == dernière date màj des jeux de données dans
    # toutes les bases ArcSDE
    listSDE = os.listdir(connexSDE)
    dicoDateModif = {}
    for base in listSDE:
        if 'prod_SIG' in base: #scan sur les 'prod_SIG'
            pathBase = connexSDE + '\\' + base
            egdb_conn = arcpy.ArcSDESQLExecute(pathBase)
            # Execution de la requête
            sql_ATM = "select TABLE_NAME, " \
                      "to_char((TIMESTAMP), 'YYYY-MM-DD HH24:MI:SS') " \
                      "from ALL_TAB_MODIFICATIONS " \
                      "where TABLE_OWNER = 'SIG'"

            sql_AO = "select OBJECT_NAME, " \
                     "to_char((LAST_DDL_TIME), 'YYYY-MM-DD HH24:MI:SS')" \
                     "from ALL_OBJECTS " \
                     "where OWNER = 'SIG' and OBJECT_TYPE = 'TABLE'"
            # to_char() transforme date en str, sinon TIMESTAMP == '' depuis ArcGIS 10.5

            sql_AO = egdb_conn.execute(sql_AO)
            if isinstance(sql_AO, __builtins__.list):
                for row in sql_AO:
                    dicoDateModif[row[0]]=(row[1], base)

            sql_ATM = egdb_conn.execute(sql_ATM)
            if isinstance(sql_ATM, __builtins__.list):
                for row in sql_ATM:
                    dicoDateModif[row[0]]=(row[1], base)

    #Complément avec la base prod SIG (en prenant en compte les dates éditeur de suivi calculées dans 13_JeuxDonnees_Maj.py)
    dicoJeu = {row.getValue('TAB_NOM')[4:].upper():row.getValue('TAB_DATEMODIF') for row in arcpy.SearchCursor(jeuDatum)}

    for jeu in dicoJeu.keys():
        dicoDateModif[jeu] = (dicoJeu[jeu], 'SIG_prod_SIG.sde')


    #Récupération des données de la table DSIT
    dicoDSITMeta = {}
    rows = arcpy.SearchCursor(MetaDSIT)
    for row in rows:
        dicoDSITMeta[row.getValue('PKB72')] = (row.getValue('TITRE'), row.getValue('ANMJD'), row.getValue('MOMJD'),
                                               row.getValue('NUMCOUCHE'), row.getValue('EMAIL'))
    del row, rows

    #Mise à jour de la table méta de DATUM
    rows = arcpy.UpdateCursor(metaDATUM)
    for row in rows:
        if row.getValue('meta_PKB72') in dicoDSITMeta.keys():
            if dicoDSITMeta[row.getValue('meta_PKB72')][0] != None:
                row.setValue('meta_titre', dicoDSITMeta[row.getValue('meta_PKB72')][0])
            else:
                row.setValue('meta_titre', '')

            if dicoDSITMeta[row.getValue('meta_PKB72')][1] != None \
                and dicoDSITMeta[row.getValue('meta_PKB72')][2] != None:
                row.setValue('meta_maj_fiche', dicoDSITMeta[row.getValue('meta_PKB72')][1]
                             + dicoDSITMeta[row.getValue('meta_PKB72')][2])
            else:
                 row.setValue('meta_maj_fiche', '')

            if dicoDSITMeta[row.getValue('meta_PKB72')][3] != None:
                row.setValue('meta_numcouche', dicoDSITMeta[row.getValue('meta_PKB72')][3])
            else:
                row.setValue('meta_numcouche', '')

            if dicoDSITMeta[row.getValue('meta_PKB72')][4] != None:
                row.setValue('meta_email', dicoDSITMeta[row.getValue('meta_PKB72')][4])
            else:
                row.setValue('meta_email', '')

            if row.getValue('meta_PKB72').upper() in dicoDateModif.keys():
                row.setValue('meta_jeudatemodif', dicoDateModif[row.getValue('meta_PKB72').upper()][0])
                row.setValue('meta_source', dicoDateModif[row.getValue('meta_PKB72').upper()][1])
            else:
                row.setValue('meta_jeudatemodif', None)
                row.setValue('meta_source', None)

            rows.updateRow(row)

    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass