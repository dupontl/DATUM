#-*- coding: utf-8 -*-
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         19_Meta_Regles.py
# Objectif:    Définition des 12 alertes sur les fiches des métadonnées
#
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

try:
    #Paramètres
##    from param_scan import *

    tableDSITMeta = Glob().tableDSITMeta
    tableDSITVign = Glob().tableDSITVign

    metaDATUM = Glob().ZZZ_TDB_metadonnees
    jeuDATUM = Glob().ZZZ_TDB_tablesde

    Nomenclature = Glob().Nomenclature
    NivQual =  Glob().NivQual

    baseSDE = Glob().baseSDEprod
    connexSDE = Glob().connexSDE

    s1 = datetime.now()

    # ---------------------------------------REGLE M01-----------------------------------#

    #fonction pour lister jeux de données dans une base ArcSDE
    def scanSDE(baseSDE):
        #init
        listJeux = []
        arcpy.env.workspace = baseSDE

        listRaster = arcpy.ListRasters()
        if isinstance(listRaster, __builtins__.list):
            listJeux = listJeux + listRaster

        listFeature = arcpy.ListFeatureClasses()
        if isinstance(listFeature, __builtins__.list):
            listJeux = listJeux + listFeature

        listTable = arcpy.ListTables()
        if isinstance(listFeature, __builtins__.list):
            listJeux = listJeux + listTable

        return listJeux

    #Liste des métadonnées (nom fiche : PKB72)
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "SELECT META_PKB72 FROM SIG.ZZZ_TDB_metadonnees"
    sql_return = egdb_conn.execute(sql)
    fiches = {x[0].lower():x[0] for x in sql_return} #en minuscule
    notInSDE = set(fiches.keys()) #init de l'ensemble de jeux hors baseSDE

    #init dico sur le niveau de qualité
    dicoInd = {x[0]:'' for x in sql_return}

    #liste des bases ArcSDE
    listSDE = os.listdir(connexSDE)

    for base in listSDE:
        if 'prod_SIG' in base: #scan sur les 'prod_SIG'
            path = connexSDE + '\\' + base
            listJeux =  [x.split('.')[1].lower() for x in scanSDE(path)] #en minuscule sans prefixe (ex: 'SIG.')
            notInSDE = notInSDE - set(listJeux) #comparaison par ensemble 'set'

    #écriture de la règle M01
    for nom in __builtins__.list(notInSDE):
        if dicoInd[fiches[nom]] == '':
            dicoInd[fiches[nom]] = 'M01'
        else:
            dicoInd[fiches[nom]] = dicoInd[fiches[nom]] + ',M01'

    # ---------------------------------------REGLE M02-----------------------------------#

    # 12 champs scannés
    dicoChamps =    {'TITRE':u'Titre', 'FKB74': u'Domaine', 'ANMJD': u'Année mise à jour', 'MOMJD': u'Mois de mise à jour', \
                    'DESCR':u'Description','PRODU': u'Organisme producteur', 'CONTA': u'Contact', 'FREQU': u'Fréquence de mise à jour'}

    dicoChpVide = {}

    #Init. table métadonnées DATUM
    rows = arcpy.UpdateCursor(metaDATUM)

    for row in rows:
        row.setValue('meta_chpvide', '')
    del row, rows

    # Recherche des champs nuls
    for champ in dicoChamps.keys():
        rows = arcpy.SearchCursor(tableDSITMeta)
        for row in rows:
            if row.getValue(champ) == None:
                if row.getValue('PKB72') in dicoChpVide.keys():
                    dicoChpVide[row.getValue('PKB72')] = dicoChpVide[row.getValue('PKB72')]+','+ champ
                else:
                    dicoChpVide[row.getValue('PKB72')] = champ

            #exception sur FKCOORD = 0 => pas de sys. coord.
            if champ == 'FKCOORD':
                if row.getValue(champ) == 0:
                    if row.getValue('PKB72') in dicoChpVide.keys():
                        dicoChpVide[row.getValue('PKB72')] = dicoChpVide[row.getValue('PKB72')]+','+ champ
                    else:
                        dicoChpVide[row.getValue('PKB72')] = champ

        del row, rows

    # Mise à jour table métadonnées dans DATUM
    rows = arcpy.UpdateCursor(metaDATUM)
    for row in rows:
        if row.getValue('meta_PKB72') in dicoChpVide.keys():
            row.setValue('meta_chpvide', '|'.join([dicoChamps[x] for x in dicoChpVide[row.getValue('meta_PKB72')].split(',')])) #par ex "Description|Observation"
            #règle M2
            if dicoInd[row.getValue('meta_PKB72')] == '':
                dicoInd[row.getValue('meta_PKB72')] = 'M02'
            else:
                dicoInd[row.getValue('meta_PKB72')] = dicoInd[row.getValue('meta_PKB72')] + ',M02'
        rows.updateRow(row)
    del row, rows

    # ---------------------------------------REGLE M3-----------------------------------#

    rows = arcpy.UpdateCursor(metaDATUM)
    for row in rows:
        if row.getValue('meta_maj_freq') != u'figée': # écarter fréquence 'figée'
            if row.getValue('meta_jeudatemodif') != None: #écarter date non renseignée
                dateModif = row.getValue('meta_jeudatemodif').strftime('%Y%m')
                if dateModif != row.getValue('meta_maj_fiche'):
                    if dicoInd[row.getValue('meta_PKB72')] == '':
                        dicoInd[row.getValue('meta_PKB72')] = 'M03'
                    else:
                        dicoInd[row.getValue('meta_PKB72')] = dicoInd[row.getValue('meta_PKB72')] + ',M03'
    del row, rows

    # ---------------------------------------REGLE M4-----------------------------------#

    #Recherche infos dans le fichier de nomenclature
    classeur = xlrd.open_workbook(Nomenclature)
    nom_des_feuilles = classeur.sheet_names()
    feuille = classeur.sheet_by_name(nom_des_feuilles[0])

    dicoNomen = {}
    for l in range (3,feuille.nrows):
        if feuille.cell_value(l, 2) != '':
                numCou = feuille.cell_value(l, 2)
                pref = feuille.cell_value(l, 5)
                dicoNomen[numCou] = pref[0:7]

    #Recherche correspondance Numéro couche / nomenclature
    rows = arcpy.SearchCursor(metaDATUM)

    for row in rows:
        if row.getValue('meta_numcouche') != None:
            try:
                if dicoNomen[int(row.getValue('meta_numcouche')[:4])] !=  row.getValue('meta_PKB72')[:7]:

                    if dicoInd[row.getValue('meta_PKB72')] == '':
                        dicoInd[row.getValue('meta_PKB72')] = 'M04'
                    else:
                        dicoInd[row.getValue('meta_PKB72')] = dicoInd[row.getValue('meta_PKB72')] + ',M04'

            except KeyError:

                if dicoInd[row.getValue('meta_PKB72')] == '':
                        dicoInd[row.getValue('meta_PKB72')] = 'M04'
                else:
                    dicoInd[row.getValue('meta_PKB72')] = dicoInd[row.getValue('meta_PKB72')] + ',M04'

    # ---------------------------------------REGLE M5, M6, M7, M8, M9 , M11 et M12-----------------------------------#

    rows = arcpy.SearchCursor(tableDSITMeta)

    for row in rows:
        # Règle M5
        if row.getValue('DIFIN') == 'o':
            if row.getValue('ACWMS') == None: # flux WMS
                if row.getValue('ACWFS') == None: # flux WFS
                    if row.getValue('ACKML') == None: # flux KML
                        if row.getValue('ACCHA') == None: # téléchargement
                            if row.getValue('ACCDO') == None: # flux ArcGIS FeatureServer
                                if row.getValue('ACMAP') == None: # flux ArcGIS MapServer

                                    if dicoInd[row.getValue('PKB72')] == '':
                                        dicoInd[row.getValue('PKB72')] = 'M05'
                                    else:
                                        dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M05'

        # Règle M6
        if row.getValue('DIFIN') == 'o' or row.getValue('DIFCP') == 'o': # Diffusions "interne" et "Cartes&Plans"
            if row.getValue('LYRFI') == None:

                if dicoInd[row.getValue('PKB72')] == '':
                    dicoInd[row.getValue('PKB72')] = 'M06'
                else:
                    dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M06'

            elif row.getValue('LYRFI')[0] != 'J':

                if dicoInd[row.getValue('PKB72')] == '':
                    dicoInd[row.getValue('PKB72')] = 'M06'
                else:
                    dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M06'

        # Règle M7
        if row.getValue('DIFRS') == 'o': #Diffusion interne
            if row.getValue('LYRFI') == None:

                if dicoInd[row.getValue('PKB72')] == '':
                    dicoInd[row.getValue('PKB72')] = 'M07'
                else:
                    dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M07'


            elif row.getValue('LYRFI')[0] != 'J':

                if dicoInd[row.getValue('PKB72')] == '':
                    dicoInd[row.getValue('PKB72')] = 'M07'
                else:
                    dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M07'

        # Règle M8
        if row.getValue('NUMCOUCHE') != None: #Numéro de couche
            if row.getValue('ACWMS') == None: # flux WMS
                    if row.getValue('ACWFS') == None: # flux WFS
                        if row.getValue('ACKML') == None: # flux KML
                            if row.getValue('ACCHA') == None: # téléchargement
                                if row.getValue('ACCDO') == None: # flux ArcGIS FeatureServer
                                    if row.getValue('ACMAP') == None: # flux ArcGIS MapServer

                                        if dicoInd[row.getValue('PKB72')] == '':
                                            dicoInd[row.getValue('PKB72')] = 'M08'
                                        else:
                                            dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M08'

        # Règle M9
        if row.getValue('MCLES') == None:
            if dicoInd[row.getValue('PKB72')] == '':
                dicoInd[row.getValue('PKB72')] = 'M09'
            else:
                dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M09'

        # Règle M11
        if row.getValue('EMAIL')==None and row.getValue('TELEP')==None:
            if dicoInd[row.getValue('PKB72')] == '':
                dicoInd[row.getValue('PKB72')] = 'M11'
            else:
                dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M11'

        # Règle M12
        if row.getValue('FKB73') == None: #nom du lot
            if dicoInd[row.getValue('PKB72')] == '':
                dicoInd[row.getValue('PKB72')] = 'M12'
            else:
                dicoInd[row.getValue('PKB72')] = dicoInd[row.getValue('PKB72')] + ',M12'



    # ---------------------------------------REGLE M10-----------------------------------#

    #Recherche des fiches avec vignette graphique (table UDU.MYB81)

    listVign = [x.getValue('PKBLB') for x in arcpy.SearchCursor(tableDSITVign)]

    fiches = __builtins__.list(set(dicoInd.keys()) - set(listVign))

    for fiche in fiches:
        if dicoInd[fiche] == '':
            dicoInd[fiche] = 'M10'
        else:
            dicoInd[fiche] = dicoInd[fiche] + ',M10'



    # ---------------------------------------REGLE M13-----------------------------------#
    listHorsPlanif=[u'maj invalide', u'si nécessaire', u'irrégulière', u'non planifiée', u'inconnue', None]

    rows = arcpy.SearchCursor(metaDATUM)
    for row in rows:
        if row.getValue('meta_maj_freq') in listHorsPlanif:
            if row.getValue('meta_PKB72') in dicoInd.keys():
                if dicoInd[row.getValue('meta_PKB72')] == '':
                    dicoInd[row.getValue('meta_PKB72')] = 'M13'
                else:
                    dicoInd[row.getValue('meta_PKB72')] = dicoInd[row.getValue('meta_PKB72')] + ',M13'

    del row, rows

    # ---------------MISE A JOUR DES INDICES DE LA TABLE DATUM DES METAS--------------------#

    #Enregistrement des champs 'META_QUALITE' et 'META_QUAL_IND' / fichier réf niveau qualité (data/Niveaux_qualite.xlsx)
    dicoNivQual = {}
    classeur = xlrd.open_workbook(NivQual)
    nom_des_feuilles = classeur.sheet_names()
    feuille = classeur.sheet_by_name(nom_des_feuilles[0])

    for l in range (2,feuille.nrows):
            dicoNivQual[feuille.cell_value(l, 0)] = [feuille.cell_value(l, 1), feuille.cell_value(l, 2), feuille.cell_value(l, 3)]

    rows = arcpy.UpdateCursor(metaDATUM)
    for row in rows:
        row.setValue('meta_qualite', dicoInd[row.getValue('meta_PKB72')])
        qualGlob = 0
        if dicoInd[row.getValue('meta_PKB72')] != '':
            niveauQual = dicoInd[row.getValue('meta_PKB72')].split(',')
            for niv in niveauQual:
                if qualGlob < dicoNivQual[niv][2]:
                    qualGlob = dicoNivQual[niv][2]
            row.setValue('meta_qual_ind', qualGlob)
        rows.updateRow(row)
    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass