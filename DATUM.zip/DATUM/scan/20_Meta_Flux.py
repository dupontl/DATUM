#-*- coding: utf-8 -*-
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         20_Meta_Flux.py
# Objectif:    Propriété sur les flux définis dans les fiches des métadonnées
#              variables sur les tests : boucle & seconde
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

##from param_scan import *

try:
    #Paramètres
    baseDSIT = Glob().baseDSIT
    baseSDE = Glob().baseSDEprod
    metaDatum = Glob().ZZZ_TDB_metadonnees

    tableDSITMeta = Glob().tableDSITMeta

    #Liste des métadonnées (nom fiche : PKB72)
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "SELECT META_PKB72 FROM SIG.ZZZ_TDB_metadonnees"
    sql_return = egdb_conn.execute(sql)

    #init dico pour enregistrer les pb sur les flux
    dicoInd = {x[0]:'' for x in sql_return}

    #Temps scan
    s1 = datetime.now()

    #méthode pour tester la connection d'un flux
    def connectFlux(url,s):
        try:
            urllib2.urlopen(url, timeout=s)
            return True
        except:
            return False


    #Dico sur les flux dicoFlux[nom fiche] = (MapServer, FeatureServer)
    egdb_conn = arcpy.ArcSDESQLExecute(baseDSIT)
    sql = "SELECT PKB72, ACCHA, ACMAP, ACCDO, ACWMS, ACWFS, ACKML FROM UDU.MYB72"
    sql_return = egdb_conn.execute(sql)
    dicoFlux = {x[0]:(x[1], x[2], x[3], x[4], x[5], x[6]) for x in sql_return}


    typeFlux = ['Zip', 'MapServer','FeatureServer','WMS','WFS','KML']

    boucle = 3
    seconde = 1

    for num, flux in enumerate(typeFlux):

        listFlux = [dicoFlux[x][num] for x in dicoFlux.keys() if dicoFlux[x][num]!=None]

        nb = 0
        noFlux = []
        for i in range(boucle):
            #Test des flux MapServer
            err = []
            for url in listFlux:
                test = connectFlux(url,seconde)
                if test == False:
                    err.append(url)
            noFlux.append(err)

        #init ensemble sur toutes les erreurs de flux
        tp = []
        for i, lst in enumerate(noFlux):
            for j, url in enumerate(lst):
                tp.append(url)

        tp = set(tp)

        #erreurs présentes sur les n boucles
        for i, lst in enumerate(noFlux):
            tp = tp.intersection(set(lst))

        result = []
        for val in tp:
            listFiche = [c for c, v in dicoFlux.items() if v[num]==val]
            if isinstance(listFiche, __builtins__.list):
                for fiche in listFiche:
                    if dicoInd[fiche] == '':
                        dicoInd[fiche] = flux
                    else:
                        dicoInd[fiche] = dicoInd[fiche] + ',' + flux

    #Mise à jour de la table Datum sur les pb de flux
    rows = arcpy.UpdateCursor(metaDatum)
    for row in rows:
        if row.getValue('meta_PKB72') in dicoInd.keys():
            row.setValue('meta_pb_flux', dicoInd[row.getValue('meta_PKB72')])
        rows.updateRow(row)
    del row, rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass

