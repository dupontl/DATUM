#-*- coding: utf-8 -*-
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         22_Maj_TableVues.py
# Objectif:    Mise à jour de la table des vues avec la définition
#              des requêtes SQL
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

from param_scan import *

try:
    #Temps scan
    s1 = datetime.now()

    #paramètres
    ZZZ_VUES_SDE = Glob().ZZZ_VUES_SDE
    defVue = Glob().ZZZ_TDB_defvues
    jeuDatum = Glob().ZZZ_TDB_tablesde

    #liste des vues enregistrées dans DATUM
    listVues = [row.getValue('TAB_NOM')[4:].upper() for row in arcpy.SearchCursor(jeuDatum) if row.getValue('TAB_TYPE')=='Vue']

    #dico des vues enregistrées dans table système oracle
    dicoDef = {row.getValue('VIEW_NAME'):row.getValue('CMD') for row in arcpy.SearchCursor(defVue)}


    #Liste des vues enregistrée dans SIG.ZZZ_TDB_DEFVUES
    listDefVues = [row.getValue('NOM_VUE').upper() for row in arcpy.SearchCursor(ZZZ_VUES_SDE)]

    #MàJ de SIG.ZZZ_VUES_SDE si vue est définie
    rows = arcpy.UpdateCursor(ZZZ_VUES_SDE)
    for row in rows:
        if row.getValue('NOM_VUE').upper() in listVues:
            row.setValue('COMMANDE', dicoDef[row.getValue('NOM_VUE').upper()])
            rows.updateRow(row)
    del row, rows

    #comparaison d'ensemble pour lister les nouvelles vues
    listNewVues = __builtins__.list(set(listVues) - set(listDefVues))

    #Insertion ligne dans SIG.ZZZ_VUES_SDE si nouvelle vue
    if isinstance(listNewVues, __builtins__.list):
        rows = arcpy.InsertCursor(ZZZ_VUES_SDE)
        for vue in listNewVues:
            row = rows.newRow()
            row.setValue('NOM_VUE', vue)
            row.setValue('COMMANDE', dicoDef[vue])
            rows.insertRow(row)

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass



