#-*- coding: utf-8 -*-
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         23_Domaines.py
# Objectif:    Mise à jour de la liste des domaines et des relations (clés
#              étrangères) entre les jeux de données et les domaines
#
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
# Développement python / arcpy
#-------------------------------------------------------------------------------

try:
##    from param_scan import *

    #paramètres
    tableSDE = Glob().ZZZ_TDB_tablesde
    domaine = Glob().ZZZ_TDB_domaine
    tabledomaine = Glob().ZZZ_TDB_tabledomaine
    arcpy.env.workspace = Glob().baseSDEprod


    #Temps scan
    s1 = datetime.now()

    #réinitialisation des tables ZZZ_TDB_***
    arcpy.DeleteRows_management(domaine)
    arcpy.DeleteRows_management(tabledomaine)

    #liste des jeux de données
    listJeux = [(row.getValue('tab_id'), row.getValue('tab_nom')) for row in arcpy.SearchCursor(tableSDE)]

    #liste des domaines dans la base SDE
    Doms = arcpy.da.ListDomains()
    listDom = []
    listDom = [i.name for i in Doms]
    listDom = sorted(listDom)

    rows = arcpy.InsertCursor(domaine)
    for i, dom in enumerate(listDom):
        row = rows.newRow()
        row.setValue('dom_id', i)
        row.setValue('dom_nom', dom)
        rows.insertRow(row)
    del row, rows

    #Recherche domaine dans chaque champ des jeux de données
    rows = arcpy.InsertCursor(tabledomaine)
    i = 0
    for jeu in listJeux:
        jeuPath = arcpy.env.workspace + '/' + jeu[1]
        fields = arcpy.ListFields(jeuPath)

        for field in fields:
            if field.domain != '':
                row = rows.newRow()
                row.setValue('tabdom_id', i)
                row.setValue('tabdom_tab_id', jeu[0]) #id du jeu de donnée
                row.setValue('tabdom_dom_id', listDom.index(field.domain))
                rows.insertRow(row)
                del row
                i += 1
    del rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    writeLogs()
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    pass