#-*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, absolute_import, nested_scopes, generators, division, with_statement
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         24_Services_Bases.py
# Objectif:    Récupérer la liste des services web ArcGIS. Le scan met à jour
#              la table ZZZ_TDB_serviceweb en supprimant les services inexistants
#              et en ajoutant les nouveaux. Récupère aussi leur statut.
#
# Auteur:      Anthony Vergne / Université de La Rochelle - LUPSIG
#
# Création:    17/08/2018
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    tableSw = Glob().ZZZ_TDB_serviceweb
    baseSDE = Glob().baseSDEprod
    path = Glob().dirServices

    # Temps scan
    s1 = datetime.now()

    # réinitialisation de la table ZZZ_TDB_SERVICEWEB
    arcpy.DeleteRows_management(tableSw)

    listeSw = []
    dicoStatut = {}

    # Création d'un dictionnaire de services web avec dossier source
    listDossiers = os.listdir(path)
    for dossier in listDossiers:
        if dossier != 'System' and dossier != 'Utilities': # Exclusion des dossiers spécifiques à ESRI
            type = path+'\\'+dossier
            if os.path.isdir(type) is True:
                listDir = os.listdir(type)
                for dir in listDir:
                    service = type + '\\' + dir
                    if os.path.isdir(service) is True:
                        listFile = os.listdir(service)
                        for fic in listFile:
                            if fic[-11:] == 'Server.json':
                                with open(service+'\\'+fic) as f:
                                    data = json.load(f)
                                    listeSw.append(data["serviceName"] + '|' + dossier)

                                    if data["configuredState"] == 'STARTED':
                                        dicoStatut[data["serviceName"] + '|' + dossier]= u'Démarré'
                                    else:
                                        dicoStatut[data["serviceName"] + '|' + dossier] = u'Arrêté'

    # Enregistrement dans bdd des nouveaux services web
    listeSwDatum = []
    last_id = 0

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        listeSwDatum.append(row.getValue('sw_nom'))
        if last_id < row.getValue('sw_id'):  # récupération du dernier id
            last_id = row.getValue('sw_id')
    del rows

    listeAjout = []
    for service in listeSw:
        if service not in listeSwDatum:
            listeAjout.append(service)

    rows = arcpy.InsertCursor(tableSw)
    last_id += 1

    for i, ajout in enumerate(listeAjout):
        row = rows.newRow()
        row.setValue('sw_id', i + last_id)
        row.setValue('sw_nom', ajout)
        row.setValue('sw_statut', dicoStatut[ajout])
        rows.insertRow(row)

    del rows

    # Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree / 60)
    seconde = int(duree - minute * 60)
    log.info(u'traitement réussi (' + str(minute) + 'min ' + str(seconde) + 's)')

except:
    writeLogs()
    log.critical(sys.exc_info()[0])  # enregistrement erreur dans log
    pass