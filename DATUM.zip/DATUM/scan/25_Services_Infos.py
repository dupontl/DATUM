#-*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, absolute_import, nested_scopes, generators, division, with_statement
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         25_Services_Infos.py
# Objectif:    Récupérer la liste des processus du service, les droits d'édition,
#              le titre, l'indication de veille et le chemin du fichier source.
#              Toutes ces informations se trouvent dans le dossier du service.
#
# Auteur:      Anthony Vergne / Université de La Rochelle - LUPSIG
#
# Création:    17/08/2018
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    tableSw = Glob().ZZZ_TDB_serviceweb
    path = Glob().dirServices

    # Temps scan
    s1 = datetime.now()

    lstSwDatum = []
    dicoProc = {}
    dicoDroit = {}
    lstDroits = ['Create', 'Update', 'Delete', 'Editing']
    dicoTitre = {}
    dicoVeille = {}
    dicoSource = {}

    # Récupération des noms de SW et dossier associé dans ZZZ_TDB_serviceweb
    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        lstSwDatum.append(row.getValue('sw_nom'))

    # Accès à l'arborescence de chaque service
    for service in lstSwDatum:
        nom = service.split('|')[0]
        dossier = service.split('|')[1]
        SW = nom + '|' + dossier
        chemin = path + '\\' + dossier
        listeDir = os.listdir(chemin)

        for dir in listeDir:
            service = chemin + '\\' + dir
            if dir.startswith(nom+"."):
                listDos = os.listdir(service)
                for dos in listDos:

                    # Récupération dans JSON éponyme du type de service et des différents processus actifs
                    if dos.startswith(nom+".") and dos.endswith("Server.json"):
                        with open(service + '\\' + dos) as f:
                            data = json.load(f)
                            dicoProc[SW] = data['type']
                            dicoDroit[SW] = ''
                            for processus in data['extensions']:
                                if processus['enabled'] == 'true':
                                    if dicoProc[SW] == '':
                                        dicoProc[SW] = processus['typeName']
                                    else:
                                        dicoProc[SW] = dicoProc[SW] + ', ' + processus['typeName']

                                    # Vérification des 'capabilities' de 'FeatureServer'
                                    if dossier == 'public' and processus['typeName'] == 'FeatureServer':
                                        for droit in lstDroits:
                                            if droit in processus['capabilities']:
                                                dicoDroit[SW] = 'Editable'
                                        if processus['properties']['allowGeometryUpdates'] == 'true':
                                            dicoDroit[SW] = 'Editable'

                    # Accès au dossier 'esriinfo'
                    if dos == 'esriinfo':
                        esriinfo = service + '\\' + dos
                        listFic = os.listdir(esriinfo)
                        for fic in listFic:
                            
                            # Récupération dans 'iteminfo' du titre du service et du contenu de 'licenseInfo'
                            # Indication de veille si 'V' dans 'Contraintes d'accès et d'utilisation :'
                            if fic == 'iteminfo.json':
                                with open(esriinfo + '\\' + fic) as f:
                                    data = json.load(f)
                                    if 'snippet' in data.keys():
                                        dicoTitre[SW] = data['snippet']
                                    if 'licenseInfo' in data.keys():
                                        dicoVeille[SW] = data['licenseInfo']

                            # Récupération dans 'manifest' du chemin de la source du service
                            if fic == 'manifest':
                                manifest = esriinfo + '\\' + fic
                                listFiles = os.listdir(manifest)
                                for file in listFiles:
                                    if file == 'manifest.json':
                                        with open(manifest + '\\' + file) as f:
                                            data = json.load(f)
                                            resources = data['resources']
                                            for elt in resources:
                                                dicoSource[SW] = elt['onPremisePath']



    # Enregistrement dans bdd des différents dictionnaires:
    rows = arcpy.UpdateCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')

        if SW in dicoProc.keys():
            row.setValue('sw_processus', dicoProc[SW])

        if SW in dicoDroit.keys():
            row.setValue('sw_droit', dicoDroit[SW])

        if SW in dicoTitre.keys():
            if dicoTitre[SW] != "":
                row.setValue('sw_titre', dicoTitre[SW])

        if SW in dicoVeille.keys():
            if dicoVeille[SW] == 'V' and row.getValue('sw_statut') == u'Arrêté':
                row.setValue('sw_statut', 'En veille')

        if SW in dicoSource.keys():
            if dicoSource[SW] != "":
                if dicoSource[SW].endswith('.mxd') or dicoSource[SW].endswith('.tbx'):
                    row.setValue('sw_source', dicoSource[SW])
                else:
                    row.setValue('sw_source', dicoSource[SW] + '.loc')
            else:
                row.setValue('sw_source', 'Inconnue')
        rows.updateRow(row)
        del row
    del rows

    # Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree / 60)
    seconde = int(duree - minute * 60)
    log.info(u'traitement réussi (' + str(minute) + 'min ' + str(seconde) + 's)')

except:
    writeLogs()
    log.critical(sys.exc_info()[0])  # enregistrement erreur dans log
    pass