#-*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, absolute_import, nested_scopes, generators, division, with_statement
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         26_Services_SourceInfo.py
# Objectif:    Déterminer si la source du serviec web est toujours présente.
#              Récupérer la date de création et celle de modification de la
#              source (et non pas celles du service).
#
# Auteur:      Anthony Vergne / Université de La Rochelle - LUPSIG
#
# Création:    17/08/2018
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    tableSw = Glob().ZZZ_TDB_serviceweb
    path = Glob().dirServices

    # Temps scan
    s1 = datetime.now()

    dicoSwDatum = {}
    dicoSrcPres = {}
    dicoCrea = {}
    dicoModif = {}

    # Récupération des noms de SW et dossier correspondant, puis de sa source
    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        dicoSwDatum[row.getValue('sw_nom')] = row.getValue('sw_source')

    # Vérification de la présence de la source du service
    for key in dicoSwDatum.keys():
        if dicoSwDatum[key] != None:
            if os.path.isfile(dicoSwDatum[key]):
                dicoSrcPres[key] = "-"

                # Récupération des dates de création et de modification:
                dicoCrea[key] = time.strftime("%Y/%m/%d", time.localtime(os.path.getctime(dicoSwDatum[key])))
                dicoModif[key] = time.strftime("%Y/%m/%d", time.localtime(os.path.getmtime(dicoSwDatum[key])))

            elif '.sde' in dicoSwDatum[key]:
                dicoSrcPres[key] = "Inaccessible"
            elif dicoSwDatum[key].startswith('C:\\') or dicoSwDatum[key].startswith('D:\\'):
                dicoSrcPres[key] = "Inaccessible"
            elif dicoSwDatum[key].startswith('\\\dit.cb\dfs\\v505'):
                dicoSrcPres[key] = u"Inaccessible"
            else:
                dicoSrcPres[key] = "Non"

    # Enregistrement dans bdd des dicoSrcPres (et créateur), date de création, date de màj:
    rows = arcpy.UpdateCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        if SW in dicoSrcPres.keys():
            if dicoSrcPres[SW] != None:
                row.setValue('sw_src_presente', dicoSrcPres[SW])
        if SW in dicoCrea.keys():
            if dicoCrea[SW] != None:
                row.setValue('sw_src_creation', dicoCrea[SW])
        if SW in dicoModif.keys():
            if dicoModif[SW] != None:
                row.setValue('sw_src_maj', dicoModif[SW])
        rows.updateRow(row)
        del row
    del rows

    # Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree / 60)
    seconde = int(duree - minute * 60)
    log.info(u'traitement réussi (' + str(minute) + 'min ' + str(seconde) + 's)')

except:
    writeLogs()
    log.critical(sys.exc_info()[0])  # enregistrement erreur dans log
    pass