#-*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, absolute_import, nested_scopes, generators, division, with_statement
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         27_Service_Couches.py
# Objectif:    Etablir la liste des couches présentes dans les .mxd à l'origine
#              des services de type MapServer et retrouver leur Jeu source.
#              Déterminer si certaines de ces couches n'ont plus de source.
#              Enregistrements dans ZZZ_TDB_COUCHE et ZZZ_TDB_COUCHESERVICE
#
# Auteur:      Anthony Vergne / Université de La Rochelle - LUPSIG
#
# Création:    17/08/2018
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    tableSw = Glob().ZZZ_TDB_serviceweb
    tblCouche = Glob().ZZZ_TDB_couche
    coucheSW = Glob().ZZZ_TDB_coucheservice
    tableSDE = Glob().ZZZ_TDB_tablesde

    # Temps scan
    s1 = datetime.now()

    # réinitialisation des tables ZZZ_TDB_***
    arcpy.DeleteRows_management(tblCouche)
    arcpy.DeleteRows_management(coucheSW)

    # Récupération : nom, dossier et l'id du service // chemin  et état de la source
    dicoSwDatum = {}
    dicoLien = {}
    lstCouche = []
    i = 1

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        dicoSwDatum[row.getValue('sw_nom')] = \
                row.getValue('sw_source'), row.getValue('sw_src_presente'), row.getValue('sw_id')

    # Production d'une liste de toutes les couches présentes dans les services avec ID uniques
    for key in sorted(dicoSwDatum.keys()):
        source = dicoSwDatum[key][0]
        if source != None:
            if source.endswith('.mxd') and dicoSwDatum[key][1] == '-':
                # if source.startswith('K:') or source.startswith('M:'):
                #     # Exception pour les volumes inaccessibles pour le compte SIG
                #     print(source, u"Inaccessible")
                # if source == "H:\AGS\Prod\\Urbanisme\GPB_URB_Intra_InstructionDIA.mxd":
                #     pass # Cette couche provoquait une erreur windows
                # else:
                # print(source)
                mxd = arcpy.mapping.MapDocument(source)
                layers = arcpy.mapping.ListLayers(mxd)
                for layer in layers:
                    if layer.supports("dataSource"):
                        dataSource = ''.join(layer.dataSource.split('\\')[-1:])
                        lstCouche.append(layer.name + '|' + str(i) + '|' + str(dicoSwDatum[key][2]) + '|' + dataSource)
                        i += 1
                # Compte des couches ayant des liens cassés
                nb_lien_abs = len(arcpy.mapping.ListBrokenDataSources(mxd))
                dicoLien[key] = nb_lien_abs



    # Enregistrement dans bdd de la liste des couches de tous les .mxd accessibles:
    rows = arcpy.InsertCursor(tblCouche)
    for couche in lstCouche:
        row = rows.newRow()
        row.setValue('cou_nom', couche.split('|')[0])
        row.setValue('cou_id', couche.split('|')[1])
        rows.insertRow(row)
        del row
    del rows

    # Mise en relation des couches avec leur JD de source selon le .mxd d'origine

    # liste des jeux de données
    lstJeu = [(row.getValue('tab_id'), row.getValue('tab_nom')) for row in arcpy.SearchCursor(tableSDE)]

    # Remplissage de la table ZZZ_TDB_couchesw
    rows = arcpy.InsertCursor(coucheSW)
    i = 1
    for couche in lstCouche:
        for jeu in lstJeu:
            # print(couche.split('|')[3], '//', jeu[1])
            if couche.split('|')[3] == jeu[1]:
                row=rows.newRow()
                row.setValue('cosw_id', i)
                row.setValue('cosw_cou_id', couche.split('|')[1])
                row.setValue('cosw_tab_id', jeu[0])
                row.setValue('cosw_sw_id', couche.split('|')[2])
                rows.insertRow(row)
                del row
                i += 1
    del rows

    # Ajout du nombre de liens cassés (par service) dans bdd
    rows = arcpy.UpdateCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        if SW in dicoLien.keys():
            if dicoLien[SW] != 0:
                row.setValue('sw_nb_lien_abs', dicoLien[SW])
                rows.updateRow(row)
                del row
    del rows

    # Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree / 60)
    seconde = int(duree - minute * 60)
    log.info(u'traitement réussi (' + str(minute) + 'min ' + str(seconde) + 's)')

except:
    writeLogs()
    log.critical(sys.exc_info()[0])  # enregistrement erreur dans log
    pass
