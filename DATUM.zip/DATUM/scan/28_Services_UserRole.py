#-*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, absolute_import, nested_scopes, generators, division, with_statement
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         28_Services_UserRole.py
# Objectif:    Récupérer la liste des users et le rôle correspondant dans les
#              JSON du dossier 'users-roles'. Ces informations sont associées
#              aux services ayant un fichier .sec dans les dossiers de services.
#
# Auteur:      Anthony Vergne / Université de La Rochelle - LUPSIG
#
# Création:    17/08/2018
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    tableSw = Glob().ZZZ_TDB_serviceweb
    userRole = Glob().ZZZ_TDB_user_role
    roleService = Glob().ZZZ_TDB_roleservice
    path = Glob().dirServices
    security = Glob().dirRoles

    # Temps scan
    s1 = datetime.now()

    # réinitialisation des tables ZZZ_TDB_***
    try:
        arcpy.DeleteRows_management(userRole)
        arcpy.DeleteRows_management(roleService)
    except RuntimeError:
        print('Erreur lors de la réinitialisation de la table')

    dicoUserRole = {}
    dicoRole = {}
    i = 0
    y = 1

    # Récupération de la liste des users et des rôles associés, avec production d'id
    listDossiers = os.listdir(security)
    for dossier in listDossiers:
        categorie = security+'\\'+dossier
        if dossier == 'user-roles':
            lstFic = os.listdir(categorie)
            for fic in lstFic:
                if fic.endswith('.json'):
                    with open(categorie+'\\'+fic) as f:
                        data = json.load(f)
                        for role in data['roles']:
                            user = data['username'].split('\\')[1]
                            i += 1
                            # Nettoyage des caractères spéciaux dans les rôles
                            accents = {'a': [u'à', u'ã', u'á', u'â'],
                                       'e': [u'é', u'è', u'ê', u'ë'],
                                       'i': [u'î', u'ï'],
                                       'u': [u'ù', u'ü', u'û'],
                                       'o': [u'ô', u'ö'],
                                       'c': [u'ç']}
                            for (char, accented_chars) in accents.iteritems():
                                for accented_char in accented_chars:
                                    role = role.replace(accented_char, char)

                            dicoUserRole[user + '|' + str(i)] = role

                            if role not in dicoRole.keys():
                                dicoRole[role] = y
                                y += 1

    # Enregistrement dans bdd des users, roles et id respectives

    rows = arcpy.InsertCursor(userRole)
    i = 1

    for key in dicoUserRole.keys():
        row = rows.newRow()
        row.setValue('usr_id', i)
        row.setValue('usr_user_id', key.split('|')[1])
        row.setValue('usr_user_nom', key.split('|')[0])
        for role in dicoRole.keys():
            if role == dicoUserRole[key]:
                row.setValue('usr_role_id', dicoRole[role])
                row.setValue('usr_role_nom', role)
        rows.insertRow(row)
        del row
        i += 1

    del rows

    # Mise en relation des infos sur le rôle avec chaque service

    dicoSwDatum = {}
    dicoRoleDatum = {}
    dicoRoleService = {}
    id = 1

    # Récupération des noms de SW et dossier associé dans ZZZ_TDB_serviceweb
    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        dicoSwDatum[row.getValue('sw_nom')] = row.getValue('sw_id')

    # Récupération des noms de rôles et id associé dans ZZZ_TDB_user_role
    rows = arcpy.SearchCursor(userRole)
    for row in rows:
        dicoRoleDatum[row.getValue('usr_role_nom')] = row.getValue('usr_role_id')

    # Accès à l'arborescence de chaque dossier de services
    for service in dicoSwDatum.keys():
        nom = service.split('|')[0]
        dossier = service.split('|')[1]
        SW = nom + '|' + dossier
        chemin = path + '\\' + dossier
        listeDir = os.listdir(chemin)

        for dir in listeDir:
            service = chemin + '\\' + dir
            if dir.startswith(dossier + '.' + nom + '.') and dir.endswith('Server.sec'):
                tree = ET.parse(service)
                root = tree.getroot()
                for elt in root.iter('permission'):
                    role = elt.attrib
                    if role['isAllowed'] == "true":

                        # Nettoyage des caractères spéciaux dans les rôles
                        accents = {'a': [u'à', u'ã', u'á', u'â'],
                                   'e': [u'é', u'è', u'ê', u'ë'],
                                   'i': [u'î', u'ï'],
                                   'u': [u'ù', u'ü', u'û'],
                                   'o': [u'ô', u'ö'],
                                   'c': [u'ç']}
                        for (char, accented_chars) in accents.iteritems():
                            for accented_char in accented_chars:
                                role['principal'] = role['principal'].replace(accented_char, char)

                        if role['principal'] in dicoRoleDatum.keys(): # Ecarter les rôles sans utilisateurs
                            dicoRoleService[id] = SW, role['principal']
                            id += 1

    # Remplissage de la table ZZZ_TDB_roleservice
    rows = arcpy.InsertCursor(roleService)
    for id in dicoRoleService.keys():
        row = rows.newRow()
        row.setValue('rose_id', id)
        # print(dicoSwDatum[dicoRoleService[id][0]])
        row.setValue('rose_sw_id', dicoSwDatum[dicoRoleService[id][0]])
        # print(dicoRoleDatum[dicoRoleService[id][1]])
        row.setValue('rose_usr_role_id', dicoRoleDatum[dicoRoleService[id][1]])
        rows.insertRow(row)
        del row
    del rows

    # Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree / 60)
    seconde = int(duree - minute * 60)
    log.info(u'traitement réussi (' + str(minute) + 'min ' + str(seconde) + 's)')

except:
    writeLogs()
    log.critical(sys.exc_info()[0])  # enregistrement erreur dans log
    pass