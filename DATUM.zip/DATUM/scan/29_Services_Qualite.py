#-*- coding: utf-8 -*-
from __future__ import print_function, unicode_literals, absolute_import, nested_scopes, generators, division, with_statement
#!/usr/bin/env python
#-------------------------------------------------------------------------------
# Nom:         29_Services_Qualite.py
# Objectif:    Définition des 7 alertes et calcul du niveau de qualité
#              des services web
#
# Auteur:      Anthony Vergne / Université de La Rochelle - LUPSIG
#
# Création:    17/08/2018
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    tableSw = Glob().ZZZ_TDB_serviceweb
    Nomenclature = Glob().Nomenclature
    NivQual = Glob().NivQual
    path = Glob().dirServices

    #Temps scan
    s1 = datetime.now()

    #Initialisation dico des indicateurs (clé : 'nom | dossier' du service)
    rows = arcpy.SearchCursor(tableSw)
    dicoInd = {}

    for row in rows:
        dicoInd[row.getValue('sw_nom')] = ''
        del row
    del rows

    #-------NIVEAU DE QUALITE S01---------#

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        indi = ''
        if row.getValue('sw_statut') == u'Arrêté':
            indi = 'S01'
        if indi == 'J01':
            dicoInd[SW] = 'J01'
        del row
    del rows

    #-------NIVEAU DE QUALITE S02---------#

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        if row.getValue('sw_nb_lien_abs') != None:
            if dicoInd[SW] == '':
                dicoInd[SW] = 'S02'
            else:
                dicoInd[SW] = dicoInd[SW] + ',S02'
        del row
    del rows

    #-------NIVEAU DE QUALITE S03---------#

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        if row.getValue('sw_droit') != None:
            if dicoInd[SW] == '':
                dicoInd[SW] = 'S03'
            else:
                dicoInd[SW] = dicoInd[SW] + ',S03'
        del row
    del rows

    #-------NIVEAU DE QUALITE S04---------#

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        if row.getValue('sw_src_presente') == 'Non':
            if dicoInd[SW] == '':
                dicoInd[SW] = 'S04'
            else:
                dicoInd[SW] = dicoInd[SW] + ',S04'
        del row
    del rows

    #-------NIVEAU DE QUALITE S05---------#

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        nom = SW.split('|')[0]
        dossier = SW.split('|')[1]
        chemin = path + '\\' + dossier
        listeDir = os.listdir(chemin)

        if dossier == 'public':
            for dir in listeDir:
                if dir.startswith(dossier + '.' + nom + '.') and dir.endswith('Server.sec'):
                    if dicoInd[SW] == '':
                        dicoInd[SW] = 'S05'
                    else:
                        dicoInd[SW] = dicoInd[SW] + ',S05'
        del row
    del rows


    #-------NIVEAU DE QUALITE S06---------#

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        if row.getValue('sw_titre') == None:
            if dicoInd[SW] == '':
                dicoInd[SW] = 'S06'
            else:
                dicoInd[SW] = dicoInd[SW] + ',S06'
        del row
    del rows

    #-------NIVEAU DE QUALITE S07---------#

    rows = arcpy.SearchCursor(tableSw)
    for row in rows:
        if row.getValue('sw_statut') == u'Démarré':

            SW = row.getValue('sw_nom')
            nom = SW.split('|')[0]
            dossier = SW.split('|')[1]
            chemin = path + '\\' + dossier
            listeDir = os.listdir(chemin)

            if dossier == 'public':
                for dir in listeDir:
                    service = chemin + '\\' + dir
                    if dir.startswith(nom + "."):
                        listDos = os.listdir(service)
                        for dos in listDos:
                            if dos == 'esriinfo':
                                esriinfo = service + '\\' + dos
                                listFic = os.listdir(esriinfo)
                                for fic in listFic:
                                    if fic == 'iteminfo.json':
                                        with open(esriinfo + '\\' + fic) as f:
                                            data = json.load(f)
                                            if 'licenseInfo' in data.keys():
                                                if data['licenseInfo'] == 'V':
                                                    if dicoInd[SW] == '':
                                                        dicoInd[SW] = 'S07'
                                                    else:
                                                        dicoInd[SW] = dicoInd[SW] + ',S07'
        del row
    del rows

    #-------------------------------------#
    #RAZ des champs 'sw_qualite' et 'sw_qual_ind'
    rows = arcpy.UpdateCursor(tableSw)
    for row in rows:
        row.setValue('sw_qualite', '')
        row.setValue('sw_qual_ind', None)
        rows.updateRow(row)
        del row
    del rows

    #Enregistrement du champ 'SW_QUALITE'
    rows = arcpy.UpdateCursor(tableSw)
    for row in rows:
        SW = row.getValue('sw_nom')
        if SW in dicoInd.keys():
            row.setValue('sw_qualite', dicoInd[SW])
            rows.updateRow(row)
        del row
    del rows

    #Enregistrement du champ 'SW_QUAL_IND' / fichier réf niveau qualité (data/Niveaux_qualite.xlsx)
    dicoNivQual = {}
    classeur = xlrd.open_workbook(NivQual)
    nom_des_feuilles = classeur.sheet_names()
    feuille = classeur.sheet_by_name(nom_des_feuilles[0])

    for l in range (2, feuille.nrows):
        dicoNivQual[feuille.cell_value(l, 0)] = [feuille.cell_value(l, 1), feuille.cell_value(l, 2), feuille.cell_value(l, 3)]

    rows = arcpy.UpdateCursor(tableSw)
    for row in rows:
        qualGlob = 0
        if row.getValue('sw_qualite') != None:
            niveauQual = row.getValue('sw_qualite').split(',')
            for niv in niveauQual:
                if qualGlob < dicoNivQual[niv][2]:
                    qualGlob = dicoNivQual[niv][2]
            row.setValue('sw_qual_ind', qualGlob)
            rows.updateRow(row)
        del row
    del rows

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')

except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass




