#-*- coding: utf-8 -*-
#!/usr/bin/env python

#-------------------------------------------------------------------------------
# Nom:         FIN.py
# Objectif:    Création des fichiers Json, de l’export Excel et des fichiers
#              sur les historisations.
#              !!! ATTENTION, CE SCAN DOIT ETRE TOUJOURS LE DERNIER !!!
#
# Auteur:      Nicolas Mahé / Université de La Rochelle - LUPSIG
#
# Création:    21/08/2017
#
# Mise à jour: 17/08/2018 / Anthony Vergne / Université de La Rochelle - LUPSIG
# Ajout de production des JSON pour les services web ArcGIS, les jeux de données
# publiés et les couples rôle-utilisateurs. Intégration des données sur les
# services web dans l'historique global et les dernières évolutions de qualité.
#
# Développement python / arcpy
#-------------------------------------------------------------------------------

#Paramètres
from param_scan import *

try:
    baseSDE = Glob().baseSDEprod
    baseDSIT = Glob().baseDSIT

    jeuxDatum = Glob().ZZZ_TDB_tablesde
    metaDatum = Glob().ZZZ_TDB_metadonnees
    swDatum = Glob().ZZZ_TDB_serviceweb
    archive = Glob().ZZZ_TDB_archive
    dirJson = Glob().dirJson
    exportXls = Glob().exportXls
    NivQual = Glob().NivQual

    #Temps scan
    s1 = datetime.now()

    # ---------------------------- METADONNEES ------------------------------------------------------#
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    fields = arcpy.ListFields(metaDatum)

    #Dictionnaire d'archivage => dicoMeta[nom du champ]=lignes du champ (une liste)
    dicoMeta = {}

    for field in fields:
        sql = "SELECT {} FROM SIG.ZZZ_TDB_metadonnees ORDER BY META_PKB72 ASC".format(field.name)
        sql_return = egdb_conn.execute(sql)
        rec = [x[0] for x in sql_return]
        dicoMeta[field.name] = rec

    # Nom des contacts
    egdb_conn = arcpy.ArcSDESQLExecute(baseDSIT)
    sql = "SELECT CONTA FROM UDU.MYB72 ORDER BY PKB72 ASC"
    sql_return = egdb_conn.execute(sql)
    rec = [x[0] for x in sql_return]
    dicoMeta['MYB72_CONTA'] = rec

    # DEBUT : Conversion des dates de META_JEUDATEMODIF de la table au format string :
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

    # Récupération des dates ou 'None' si absence de date
    sql = "SELECT to_char((META_JEUDATEMODIF), 'YYYY-MM-DD HH24:MI:SS') \
          FROM SIG.ZZZ_TDB_METADONNEES \
          ORDER BY META_PKB72 ASC"
    sql_date = egdb_conn.execute(sql)

    listDate = []
    for rowSQL in sql_date:
        # print(rowSQL[0])
        if rowSQL[0] == None:
            rowSQL[0] = 'None'  # conversion de 'None Type' en 'str' pour export excel
        listDate.append(rowSQL[0])

    dicoMeta['META_JEUDATEMODIF'] = [x for x in listDate]
    # FIN : Conversion des dates de META_JEUDATEMODIF au format string

    #Création fichier Json de la table ZZZ_TDB_metadonnees
    with open(dirJson + '\\meta_tableau.json', 'w') as outfile:
        json.dump(dicoMeta, outfile)
        outfile.close()

    # ---------------------------- JEUX DE DONNEES ------------------------------------------------------#
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    fields = arcpy.ListFields(jeuxDatum)

    #Dictionnaire d'archivage => dicoJeux[nom du champ]=lignes du champ (une liste)
    dicoJeu = {}

    for field in fields:
        sql = "SELECT {} FROM SIG.ZZZ_TDB_tablesde ORDER BY TAB_NOM ASC".format(field.name)
        sql_return = egdb_conn.execute(sql)
        rec = [x[0] for x in sql_return]
        dicoJeu[field.name] = rec

    # DEBUT :  Fichiers Lyr associés à un jeu de données
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

    sql="SELECT LYR_FIC, LYR_SOURCE FROM SIG.ZZZ_TDB_fichierlyr, SIG.ZZZ_TDB_tablesde \
        WHERE TAB_NOM=LYR_SOURCE AND SUBSTR(LYR_PATH,0,1)='J'"
    sql_lyr = egdb_conn.execute(sql)

    #Liste des sources comportant des fichiers lyr
    listSource = __builtins__.list(set([x[1] for x in sql_lyr]))

    #Liste des jeux de données
    sql = "SELECT TAB_NOM FROM SIG.ZZZ_TDB_tablesde ORDER BY TAB_NOM ASC"
    sql_jeu = egdb_conn.execute(sql)

    listJeux = [x[0] for x in sql_jeu]
    listLyr = []
    for jeu in listJeux:
        if jeu in listSource:
            listLyr.append(__builtins__.list(set([x[0] for x in sql_lyr if x[1]==jeu])))
        else:
            if 'ATTACH' in jeu:
                listLyr.append('n/a')
            else:
                listLyr.append('')

    dicoJeu['FIC_LYR'] = [x for x in listLyr]
    # FIN :  Fichiers Lyr associés à un jeu de données

    # DEBUT : Conversion des dates de TAB_DATEMODIF de la table au format string :
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

    # Récupération des dates ou 'None' si absence de date
    sql = "SELECT to_char((TAB_DATEMODIF), 'YYYY-MM-DD HH24:MI:SS') \
          FROM SIG.ZZZ_TDB_TABLESDE \
          ORDER BY TAB_NOM ASC"
    sql_date = egdb_conn.execute(sql)

    listDate = []
    for rowSQL in sql_date:
        if rowSQL[0] == None:
            rowSQL[0] = 'None' #conversion de 'None Type' en 'str' pour export excel
        listDate.append(rowSQL[0])

    dicoJeu['TAB_DATEMODIF'] = [x for x in listDate]
    # FIN : Conversion des dates de TDB_TABLESDE au format string

    #Création fichier Json de la table ZZZ_TDB_tablesde
    with open(dirJson + '\\sde_tableau.json', 'w') as outfile:
        json.dump(dicoJeu, outfile)
        outfile.close()

    #Ajout des données dans la table d'archivage
    rows = arcpy.InsertCursor(archive)
    row = rows.newRow()
    row.setValue('ARC_DATE', datetime.now())
    row.setValue('ARC_TABLESDE', json.dumps(dicoJeu))
    rows.insertRow(row)
    del row, rows


    # ---------------------------- DOMAINES --------------------------------------------------------------#
    #Export Json du dictionnaire JEU = [DOM]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct tab_id,tab_nom \
        from SIG.ZZZ_TDB_tablesde, SIG.ZZZ_TDB_tabledomaine \
        where tab_id = tabdom_tab_id"

    listData = egdb_conn.execute(sql)
    dicoData = {}

    for data in listData:
        sql = "select dom_nom from SIG.ZZZ_TDB_tabledomaine, SIG.ZZZ_TDB_domaine \
            where tabdom_tab_id = {} and tabdom_dom_id = dom_id".format(data[0])

        sql_return = egdb_conn.execute(sql)

        if isinstance(sql_return, __builtins__.list):
            dicoData[data[1]] = [x[0] for x in sql_return]
        else:
            dicoData[data[1]] = [sql_return]

    with open(dirJson + '\sde_dicoJeu_Dom.json', 'w') as outfile:
        json.dump(dicoData, outfile)
    outfile.close()

    #Export Json du dictionnaire DOM = [JEU]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct dom_id,dom_nom \
            from SIG.ZZZ_TDB_domaine, SIG.ZZZ_TDB_tabledomaine \
            where dom_id = tabdom_dom_id"

    listDom = egdb_conn.execute(sql)
    dicoDom = {}

    for dom in listDom:
        sql = "select tab_nom from SIG.ZZZ_TDB_tabledomaine, SIG.ZZZ_TDB_tablesde \
            where tabdom_dom_id = {} and tabdom_tab_id = tab_id".format(dom[0])

        sql_return = egdb_conn.execute(sql)

        if isinstance(sql_return, __builtins__.list):
            dicoDom[dom[1]] = [x[0] for x in sql_return]
        else:
            dicoDom[dom[1]] = [sql_return]

    with open(dirJson + '\sde_dicoDom_Jeu.json', 'w') as outfile:
                json.dump(dicoDom, outfile)
    outfile.close()

    # ---------------------------- SERVICES WEB ------------------------------------------------------#
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    fields = arcpy.ListFields(swDatum)

    # Dictionnaire d'archivage => dicoSw[nom du champ]=lignes du champ (une liste)
    dicoSw = {}

    for field in fields:
        sql = "SELECT {} FROM SIG.ZZZ_TDB_serviceweb ORDER BY SW_NOM ASC".format(field.name)
        sql_return = egdb_conn.execute(sql)
        rec = [x[0] for x in sql_return]
        dicoSw[field.name] = rec

        # DEBUT : Conversion des dates de création et de mise à jour de la source du service au format string :
        egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)

        # Récupération des dates ou 'None' si absence de date
        sql = "SELECT to_char((sw_src_creation), 'YYYY-MM-DD'), \
              to_char((sw_src_maj), 'YYYY-MM-DD')\
              FROM SIG.ZZZ_TDB_serviceweb \
              ORDER BY SW_NOM ASC"
        sql_date = egdb_conn.execute(sql)

        lstDate = []
        lstMaj = []
        for rowSQL in sql_date:
            if rowSQL[0] == None:
                rowSQL[0] = 'None'  # conversion de 'None Type' en 'str' pour export excel
            lstDate.append(rowSQL[0])

            if rowSQL[1] == None:
                rowSQL[1] = 'None'  # conversion de 'None Type' en 'str' pour export excel
            lstMaj.append(rowSQL[1])

        dicoSw['SW_SRC_CREATION'] = [x for x in lstDate]
        dicoSw['SW_SRC_MAJ'] = [x for x in lstMaj]
        # FIN : Conversion des dates de ZZZ_TDB_SERVICEWEB au format string

    # Création fichier Json de la table ZZZ_TDB_serviceweb
    with open(dirJson + '\\service_tableau.json', 'w') as outfile:
        json.dump(dicoSw, outfile)
        outfile.close()

    # Export Json du dictionnaire SW = [Couche]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct sw_id, sw_nom \
        from SIG.ZZZ_TDB_serviceweb, SIG.ZZZ_TDB_coucheservice \
        where sw_id = cosw_sw_id"

    listSw = egdb_conn.execute(sql)
    dicoSw = {}

    for service in listSw:
        sql = "select cou_nom from SIG.ZZZ_TDB_coucheservice, SIG.ZZZ_TDB_couche \
            where cosw_sw_id = {} and cosw_cou_id = cou_id".format(service[0])

        sql_return = egdb_conn.execute(sql)

        if isinstance(sql_return, __builtins__.list):
            dicoSw[service[1]] = [x[0] for x in sql_return]
        else:
            dicoSw[service[1]] = [sql_return]

    with open(dirJson + '\service_dicoSw_Couche.json', 'w') as outfile:
        json.dump(dicoSw, outfile)
    outfile.close()

    # Export Json du dictionnaire SW = [JEU]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct sw_id, sw_nom \
        from SIG.ZZZ_TDB_serviceweb, SIG.ZZZ_TDB_coucheservice \
        where sw_id = cosw_sw_id"

    listeSw = egdb_conn.execute(sql)
    dicoSw = {}

    for service in listeSw:
        sql = "select distinct tab_nom from SIG.ZZZ_TDB_coucheservice, SIG.ZZZ_TDB_tablesde \
            where cosw_sw_id = {} and cosw_tab_id = tab_id".format(service[0])

        sql_return = egdb_conn.execute(sql)

        if isinstance(sql_return, __builtins__.list):
            dicoSw[service[1]] = [x[0] for x in sql_return]
        else:
            dicoSw[service[1]] = [sql_return]

    with open(dirJson + '\service_dicoSw_Jeu.json', 'w') as outfile:
        json.dump(dicoSw, outfile)
    outfile.close()

    # Export Json du dictionnaire JEU = [Sw]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct tab_id, tab_nom \
        from SIG.ZZZ_TDB_tablesde, SIG.ZZZ_TDB_coucheservice \
        where tab_id = cosw_tab_id"

    lstJeuSW = egdb_conn.execute(sql)
    dicoJeuSw = {}

    for jeu in lstJeuSW:
        sql = "select sw_nom from SIG.ZZZ_TDB_coucheservice, SIG.ZZZ_TDB_serviceweb \
        where cosw_tab_id = {} and cosw_sw_id = sw_id".format(jeu[0])

        sql_return = egdb_conn.execute(sql)

        if isinstance(sql_return, __builtins__.list):
            dicoJeuSw[jeu[1]] = [x[0] for x in sql_return]
        else:
            dicoJeuSw[jeu[1]] = [sql_return]

    with open(dirJson + '\service_dicoJeu_Sw.json', 'w') as outfile:
        json.dump(dicoJeuSw, outfile)
    outfile.close()

    # ---------------------------- USERS // ROLES ---------------------------------------------------------#
    # Export Json du dictionnaire SW = [User]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct sw_id, sw_nom \
               from SIG.ZZZ_TDB_serviceweb, SIG.ZZZ_TDB_roleservice \
               where sw_id = rose_sw_id"

    listData = egdb_conn.execute(sql)
    dicoData = {}

    for data in listData:
        sql = "select distinct usr_user_nom \
                   from SIG.ZZZ_TDB_roleservice, SIG.ZZZ_TDB_user_role \
                   where rose_sw_id = {} and rose_usr_role_id = usr_role_id".format(data[0])

        sql_return = egdb_conn.execute(sql)

        if isinstance(sql_return, __builtins__.list):
            dicoData[data[1]] = [x[0] for x in sql_return]
        else:
            dicoData[data[1]] = [sql_return]

    with open(dirJson + '\service_dicoSw_User.json', 'w') as outfile:
        json.dump(dicoData, outfile)
    outfile.close()

    # Export Json du dictionnaire Role = [User]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct usr_role_id, usr_role_nom from SIG.ZZZ_TDB_user_role"

    listData = egdb_conn.execute(sql)
    dicoData = {}

    for data in listData:
        sql = "select usr_user_nom from SIG.ZZZ_TDB_user_role \
        where usr_role_id = {} order by usr_role_id".format(data[0])

        sql_return = egdb_conn.execute(sql)


        if isinstance(sql_return, __builtins__.list):
            dicoData[data[1]] = [x[0] for x in sql_return]
        else:
            dicoData[data[1]] = [sql_return]

    with open(dirJson + '\service_dicoRole_User.json', 'w') as outfile:
        json.dump(dicoData, outfile)
    outfile.close()

    # Export Json du dictionnaire SW = [Role]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct sw_id, sw_nom \
        from SIG.ZZZ_TDB_serviceweb, SIG.ZZZ_TDB_roleservice \
        where sw_id = rose_sw_id"

    listData = egdb_conn.execute(sql)
    dicoData = {}

    for data in listData:
        sql = "select distinct usr_role_nom \
            from SIG.ZZZ_TDB_roleservice, SIG.ZZZ_TDB_user_role \
            where rose_sw_id = {} and rose_usr_role_id = usr_role_id".format(data[0])

        sql_return = egdb_conn.execute(sql)

        if isinstance(sql_return, __builtins__.list):
            dicoData[data[1]] = [x[0] for x in sql_return]
        else:
            dicoData[data[1]] = [sql_return]

    with open(dirJson + '\service_dicoSw_Role.json', 'w') as outfile:
        json.dump(dicoData, outfile)
    outfile.close()

    # Export Json du dictionnaire Role = [SW]
    egdb_conn = arcpy.ArcSDESQLExecute(baseSDE)
    sql = "select distinct usr_role_id, usr_role_nom \
            from SIG.ZZZ_TDB_user_role, SIG.ZZZ_TDB_roleservice \
            where usr_role_id = rose_usr_role_id"

    listRole = egdb_conn.execute(sql)
    dicoRole = {}

    for role in listRole:
        sql = "select sw_nom from SIG.ZZZ_TDB_roleservice, SIG.ZZZ_TDB_serviceweb \
            where rose_usr_role_id = {} and rose_sw_id = sw_id".format(role[0])

        sql_return = egdb_conn.execute(sql)

        if isinstance(sql_return, __builtins__.list):
            dicoRole[role[1]] = [x[0] for x in sql_return]
        else:
            dicoRole[role[1]] = [sql_return]

    with open(dirJson + '\service_dicoRole_Sw.json', 'w') as outfile:
        json.dump(dicoRole, outfile)
    outfile.close()

    # ----------------------------NIVEAUX DE QUALITE--------------------------------------------------------------#
    #Création fichier Json du fichier excel "Niveaux_qualite.xlsx"
    dicoNivQual = {}
    classeur = xlrd.open_workbook(NivQual)
    nom_des_feuilles = classeur.sheet_names()
    feuille = classeur.sheet_by_name(nom_des_feuilles[0])

    for l in range (2,feuille.nrows):
        dicoNivQual[feuille.cell_value(l, 0)] = [feuille.cell_value(l, 1), feuille.cell_value(l, 2), feuille.cell_value(l, 3)]

    with open(dirJson + '\\def_qualite.json', 'w') as outfile:
        json.dump(dicoNivQual, outfile)
        outfile.close()

    # ----------------------------EXPORT EXCEL--------------------------------------------------------------#
    #Export excel de la table ZZZ_TDB_tablesde
    book = Workbook()
    feuil1 = book.add_sheet('Feuil1')

    for col, champ in enumerate(sorted(dicoJeu.keys())):
        #entête
        feuil1.write(0,col,champ)
        for row, valeur in enumerate(dicoJeu[champ]):
            feuil1.write(row + 1,col,valeur)
    book.save(exportXls)


    # -------  CREATION DES FICHIERS HISTO_JEU_DETAIL.JSON et HISTO_GLOBAL.JSON-------

    # -------  data sur les jeux de données

    #Ouverture fichier jeux de données
    js =open(dirJson + '//sde_tableau.json')
    date = datetime.fromtimestamp(os.stat(dirJson + '//sde_tableau.json').st_mtime).strftime("%Y%m")
    dataJeu = json.load(js)
    js.close()

    #Calcul nombre total de jeux de données
    totalJeu = len([x for x in dataJeu['TAB_QUALITE']]) #total

    #Calcul pourcentage "Données à jour"
    a = len([x for x in dataJeu['TAB_MAJ_STATUT'] if x == u'Mise \xe0 jour \xe0 faire'])
    jeu_Maj = len([x for x in dataJeu['TAB_MAJ_STATUT'] if x == u'-' or x == u'Figée'])
    c = len([x for x in dataJeu['TAB_MAJ_STATUT'] if x == u'Non planifi\xe9e'])

    #Calcul pourcentage "Lyr existant"
    jeu_without_NA = totalJeu - len([x for x in dataJeu['FIC_LYR'] if x == 'n/a']) #on retire du total les 'n/a'
    jeu_Lyr = len([x for x in dataJeu['FIC_LYR'] if x != ''])

    #Calcul pourcentage "Métadonnées présentes"
    lstNoNone = [x for x in dataJeu['TAB_QUALITE'] if x != None] #filtre les champs nuls
    jeu_Meta = totalJeu - len([x for x in lstNoNone if x.find('J06')!=-1]) #Métadonnées présentes

    # -------  data sur les métadonnées -----------

    #Ouverture fichier métadonnées
    js =open(dirJson + '//meta_tableau.json')
    dataMeta = json.load(js)
    js.close()

    #Calcul nombre total de métadonnées
    totalMeta = len([x for x in dataMeta['META_QUALITE']])
    lstNoNone = [x for x in dataMeta['META_QUALITE'] if x != None] #filtre les champs nuls

    # -------  data sur les fichiers lyr -----------

    #Ouverture fichier lyr
    js =open(dirJson + '//lyr_tableau.json')
    dataLyr = json.load(js)
    js.close()

    dicoLyr = {}
    listQual = []
    for lyr in dataLyr.keys():
        qualLyr = []
        for couche in dataLyr[lyr]:
            qualLyr.append(dataLyr[lyr][couche][-1].split('|')[1])
        dicoLyr[lyr]=qualLyr

    #Calcul nombre total de lyr
    ficLyr = [','.join(dicoLyr[x]) for x in dicoLyr.keys()]
    totalLyr = len(ficLyr)

    # -------  data sur les services web -----------

    # Ouverture service web
    js = open(dirJson + '//service_tableau.json')
    dataSw = json.load(js)
    js.close()

    # Calcul nombre total de services web
    totalSw = len([x for x in dataSw['SW_QUALITE']])
    # print(totalSw)

    #Ouverture du fichier json sur l'historique jeu - méta - lyr - service
    if os.path.isfile(dirJson + '//histo_global.json') == True:
        js =open(dirJson + '//histo_global.json')
        dicoHistGlobal = json.load(js)
        js.close()
    else:
        dicoHistGlobal = {}

    dicoHistGlobal[date] = [totalJeu, totalMeta, totalLyr, totalSw] #record info dans dico

    #Ecriture du fichier
    with open(dirJson + '\histo_global.json', 'w') as outfile:
            json.dump(dicoHistGlobal, outfile)
    outfile.close()

    #Ouverture du fichier json sur l'historique jeu (Total, Données à jour, Lyr existant, métadonnées présentes)
    if os.path.isfile(dirJson + '//histo_jeu_detail.json') == True:
        js =open(dirJson + '//histo_jeu_detail.json')
        dicoHistJeu = json.load(js)
        js.close()
    else:
        dicoHistJeu = {}

    dicoHistJeu[date] = [totalJeu, jeu_Maj, jeu_Lyr, jeu_Meta] #record info dans dico

    #Ecriture du fichier
    with open(dirJson + '\histo_jeu_detail.json', 'w') as outfile:
            json.dump(dicoHistJeu, outfile)
    outfile.close()

    # -------  CREATION DU FICHIER HISTO_JOUR.JSON    --------------

    num = 0
    dicoHisto = {}
    s1 = datetime.now()
    date = s1.strftime("%d/%m/%Y")
    numDate = s1.strftime("%Y%m%d")

    #Ouverture du fichier json sur l'historique
    if os.path.isfile(dirJson + '//histo_jour.json') == True:
        js =open(dirJson + '//histo_jour.json')
        dicoHisto = json.load(js)
        js.close()
    else:
        dicoHisto = {}

    #Sur les fichiers lyr....

    #Ouverture des fichiers Json sur les lyr
    js =open(dirJson + '//lyr_tableau.json')
    lyr_new = json.load(js)
    js.close()

    js =open(dirJson + '//lyr_tableau_old.json')
    lyr_old = json.load(js)
    js.close()

    newData = {}
    oldData = {}

    #Enregistrement des niveaux de qualité (0,1,2,3) du dernier scan
    pos = 1
    for lyr in lyr_new.keys():
        max = 0
        for val in lyr_new[lyr].values():
            indice = val[pos].split('|')[1]
            if indice != '':
                if int(indice) > max:
                    max = int(indice)
        newData[lyr] = ('lyr', max)

    #Enresgistrement des niveaux de qualité (0,1,2,3) du précédent scan
    pos = 1
    for lyr in lyr_old.keys():
        max = 0
        for val in lyr_old[lyr].values():
            indice = val[pos].split('|')[1]
            if indice != '':
                if int(indice) > max:
                    max = int(indice)
        oldData[lyr] = ('lyr', max)

    for data in oldData.keys():
        if data in newData.keys(): #elle peut avoir disparue!
            if oldData[data][1] > newData[data][1]:
                dicoHisto[numDate + str(num).zfill(3)] = (date, 'Fichier lyr', data, newData[data][1], 1)
                num += 1
            elif oldData[data][1] < newData[data][1]:
                dicoHisto[numDate + str(num).zfill(3)] = (date, 'Fichier lyr', data, newData[data][1], -1)
                num += 1
    #...Fin fichiers lyr

    #Sur les métadonnées...

    #Ouverture des fichiers Json sur les métadonnées
    js =open(dirJson + '//meta_tableau.json')
    meta_new = json.load(js)
    js.close()

    js =open(dirJson + '//meta_tableau_old.json')
    meta_old = json.load(js)
    js.close()

    newData = {}
    oldData = {}

    for i, val in enumerate(meta_new['META_PKB72']):
        if meta_new['META_QUAL_IND'][i] != None:
            newData[val] = int(meta_new['META_QUAL_IND'][i])
        else:
            newData[val] = 0

    for i, val in enumerate(meta_old['META_PKB72']):
        if meta_old['META_QUAL_IND'][i] != None:
            oldData[val] = int(meta_old['META_QUAL_IND'][i])
        else:
            oldData[val] = 0

    for data in oldData.keys():
        if data in newData.keys(): #elle peut avoir disparue!
            if oldData[data] > newData[data]:
                dicoHisto[numDate + str(num).zfill(3)] = (date, u'Métadonnées', data, newData[data], 1)
                num += 1
            elif oldData[data] < newData[data]:
                dicoHisto[numDate + str(num).zfill(3)] = (date, u'Métadonnées', data, newData[data], -1)
                num += 1
    #...Fin métadonnées

    #Sur les jeux de données...

    #Ouverture des fichiers Json sur les jeux de données
    js =open(dirJson + '//sde_tableau.json')
    jeu_new = json.load(js)
    js.close()

    js =open(dirJson + '//sde_tableau_old.json')
    jeu_old = json.load(js)
    js.close()

    newData = {}
    oldData = {}

    for i, val in enumerate(jeu_new['TAB_NOM']):
        if jeu_new['TAB_QUAL_IND'][i] != None:
            newData[val] = int(jeu_new['TAB_QUAL_IND'][i])
        else:
            newData[val] = 0

    for i, val in enumerate(jeu_old['TAB_NOM']):
        if jeu_old['TAB_QUAL_IND'][i] != None:
            oldData[val] = int(jeu_old['TAB_QUAL_IND'][i])
        else:
            oldData[val] = 0

    for data in oldData.keys():
        if data in newData.keys(): #elle peut avoir disparue!
            if oldData[data] > newData[data]:
                dicoHisto[numDate + str(num).zfill(3)] = (date, u'Jeux de données', data, newData[data], 1)
                num += 1
            elif oldData[data] < newData[data]:
                dicoHisto[numDate + str(num).zfill(3)] = (date, u'Jeux de données', data, newData[data], -1)
                num += 1
    #...Fin jeux de données

    # Sur les services web....

    # Ouverture des fichiers Json sur les services
    js = open(dirJson + '//service_tableau.json')
    service_new = json.load(js)
    js.close()

    js = open(dirJson + '//service_tableau_old.json')
    service_old = json.load(js)
    js.close()

    newData = {}
    oldData = {}

    for i, val in enumerate(service_new['SW_NOM']):
        if service_new['SW_QUAL_IND'][i] != None:
            newData[val] = int(service_new['SW_QUAL_IND'][i])
        else:
            newData[val] = 0

    for i, val in enumerate(service_old['SW_NOM']):
        if service_old['SW_QUAL_IND'][i] != None:
            oldData[val] = int(service_old['SW_QUAL_IND'][i])
        else:
            oldData[val] = 0

    for data in oldData.keys():
        if data in newData.keys():  # elle peut avoir disparue!
            if oldData[data] > newData[data]:
                print(data, u"amélioration")
                dicoHisto[numDate + str(num).zfill(3)] = (date, 'Service Web', data, newData[data], 1)
                num += 1
            elif oldData[data] < newData[data]:
                print(data, u"régression")
                dicoHisto[numDate + str(num).zfill(3)] = (date, 'Service Web', data, newData[data], -1)
                num += 1
    # ...Fin services web

    #Limiter le fichier json à 'max'
    nb = len(dicoHisto.keys())
    max = 500 #limite nombre de ligne dans le fichier json

    if nb > max:
        listHisto = sorted(dicoHisto.keys())
        for i in range(nb-max):
            del dicoHisto[listHisto[i]] #suppression des + anciens

    #Ecriture historique dans histo_jour.json
    # définition ----->  n° : (date, type, nom, indice, tendance)
    with open(dirJson + '\histo_jour.json', 'w') as outfile:
        json.dump(dicoHisto, outfile)
    outfile.close()

    #Enregistrement dans log
    s2 = datetime.now()
    duree = (s2 - s1).total_seconds()
    minute = int(duree/60)
    seconde = int(duree-minute*60)
    log.info(u'traitement réussi ('+str(minute)+'min '+str(seconde)+'s)')


except:
    log.critical(sys.exc_info()[0]) #enregistrement erreur dans log
    writeLogs()
    pass
